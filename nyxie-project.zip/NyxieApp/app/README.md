
## 3.12 – Nuit des lucioles décalée + 2 nouveaux mini-jeux (étape G)
- L'événement dure maintenant du 20 au 26 novembre 2026 (modifiable dans `Events.kt`).
- Attrape-lucioles : 25 s, on ne peut attraper les lucioles que lorsqu'elles brillent ; les dorées valent 4 points ; de plus en plus de lucioles.
- Bulles magiques : 25 s, enchaîner la même couleur fait monter le combo (jusqu'à x5).
- Records enregistrés (sauvegardes compatibles), phrases de fin selon le score, quêtes « jouer » et lucioles d'événement comptabilisées.
