package com.lumina.nyxie

import java.time.LocalDate

// ---------------------------------------------------------------------------
// Événements saisonniers : entièrement locaux (horloge de l'appareil), sans réseau.
// Ajouter un événement = ajouter un EventDef dans Events.all.
// ---------------------------------------------------------------------------

class EventReward(
    val at: Int,
    val id: String,
    val glyph: String,
    val label: String,
    val coins: Int = 0,
    val gems: Int = 0,
    val item: String? = null,
)

class EventDef(
    val id: String,
    val name: String,
    val glyph: String,
    val tagline: String,
    val tokenName: String,
    val start: LocalDate,
    val end: LocalDate,          // dernier jour inclus
    val rewards: List<EventReward>,
    val dailyCap: Int = 12,      // lucioles gagnées au maximum par jour via les soins et les jeux
    val dailyBonus: Int = 3,     // bonus de première visite de la journée
) {
    val maxAt: Int get() = rewards.maxOf { it.at }
}

object Events {
    val fireflies = EventDef(
        id = "ev_fireflies_2026",
        name = "Nuit des lucioles",
        glyph = "🪲",
        tagline = "Des lucioles dansent autour de Nyxie. Prends soin d'elle pour les rassembler !",
        tokenName = "lucioles",
        start = LocalDate.of(2026, 11, 20),
        end = LocalDate.of(2026, 11, 26),
        rewards = listOf(
            EventReward(10, "r10", "💰", "30 pièces", coins = 30),
            EventReward(25, "r25", "🌌", "Ambiance Nuit des lucioles", item = "amb_glowfest"),
            EventReward(45, "r45", "👑", "Couronne de lucioles", item = "acc_fireflycrown"),
            EventReward(70, "r70", "💎", "2 gemmes", gems = 2),
            EventReward(100, "r100", "🎨", "Thème Lueur", item = "theme_glow"),
        ),
    )

    val all = listOf(fireflies)

    fun active(day: LocalDate = LocalDate.now()): EventDef? =
        all.firstOrNull { !day.isBefore(it.start) && !day.isAfter(it.end) }

    fun byId(id: String): EventDef? = all.firstOrNull { it.id == id }

    fun daysLeft(e: EventDef, day: LocalDate = LocalDate.now()): Int =
        (java.time.temporal.ChronoUnit.DAYS.between(day, e.end).toInt() + 1).coerceAtLeast(0)
}

/** Nouveau jour d'événement : réinitialise le plafond du jour et donne le bonus de première visite. */
fun GameState.eventDay(): GameState {
    val e = Events.active() ?: return this
    var s = this
    if (s.evId != e.id) s = s.copy(evId = e.id, evCount = 0, evClaimed = emptySet(), evDayKey = "", evDayGain = 0)
    val today = todayStr()
    if (s.evDayKey != today) s = s.copy(evDayKey = today, evDayGain = 0, evCount = s.evCount + e.dailyBonus)
    return s
}

/** Une lucioles de plus pour un soin ou une partie (dans la limite du jour). */
fun GameState.eventTick(): GameState {
    val e = Events.active() ?: return this
    val s = eventDay()
    if (s.evDayGain >= e.dailyCap) return s
    return s.copy(evCount = s.evCount + 1, evDayGain = s.evDayGain + 1)
}

fun GameState.withEventReward(r: EventReward): GameState =
    copy(
        coins = coins + r.coins,
        gems = gems + r.gems,
        owned = if (r.item != null) owned + r.item else owned,
        evClaimed = evClaimed + r.id,
    )
