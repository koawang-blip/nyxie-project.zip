package com.lumina.nyxie

import java.util.Calendar

// ---------------------------------------------------------------------------
// Banque de phrases préprogrammées (aucune IA générative).
// Chaque phrase peut déclencher un petit tic d'animation déjà existant.
// ---------------------------------------------------------------------------

/** Numéros des tics d'animation de la scène (identiques à NyxieScene). */
object Tic {
    const val NONE = 0
    const val CURIOUS = 1
    const val GIGGLE = 2
    const val SLOWBLINK = 3
    const val YAWN = 4
    const val LOOK = 5
    const val SHAKE = 6
    const val PROUD = 7
    const val SULK = 8
}

/** Demande d'animation envoyée du ViewModel vers la scène (l'id change à chaque demande). */
class TicCmd(val kind: Int, val id: Long)

class Line(val text: String, val tic: Int = Tic.NONE)

private fun l(t: String, tic: Int = Tic.NONE) = Line(t, tic)

object Lines {
    val HUNGRY = listOf(
        l("Mon ventre gargouille un peu…", Tic.SLOWBLINK),
        l("Tu aurais quelque chose de bon à manger ?", Tic.CURIOUS),
        l("Mon ventre fait des bruits bizarres…", Tic.LOOK),
        l("J'ai un petit creux, tu sais…", Tic.SLOWBLINK),
        l("Hmm… ça sentirait pas bon, quelque part ?", Tic.CURIOUS),
        l("Je rêve d'une bonne friandise…", Tic.SULK),
        l("Je commence à avoir vraiment faim.", Tic.SULK),
        l("Un petit quelque chose à grignoter ?", Tic.CURIOUS),
        l("Mon estomac chante tout seul, écoute !", Tic.SHAKE),
        l("Si tu as des gourmandises, je suis preneuse…", Tic.LOOK),
    )

    val TIRED = listOf(
        l("Je suis un peu fatiguée…", Tic.YAWN),
        l("Un petit dodo me ferait du bien.", Tic.YAWN),
        l("*bâille* Je tombe de sommeil…", Tic.YAWN),
        l("Mes yeux se ferment tout seuls…", Tic.SLOWBLINK),
        l("Ouh là… j'ai les paupières lourdes.", Tic.SLOWBLINK),
        l("On ferait pas une petite sieste ensemble ?", Tic.YAWN),
        l("Je pourrais m'endormir debout…", Tic.YAWN),
        l("La lune m'appelle pour me coucher…", Tic.SLOWBLINK),
        l("Hmm… encore un petit moment et je ronfle.", Tic.YAWN),
        l("Mes ailes sont toutes molles ce soir.", Tic.SLOWBLINK),
    )

    val LONELY = listOf(
        l("Tu m'as manqué…", Tic.SULK),
        l("Un câlin, s'il te plaît ?", Tic.LOOK),
        l("Tu es là ? J'aimerais un câlin…", Tic.SULK),
        l("Je me sens un peu toute seule…", Tic.SULK),
        l("Tu veux bien rester un peu avec moi ?", Tic.LOOK),
        l("J'ai besoin de ta présence aujourd'hui.", Tic.SLOWBLINK),
        l("Je t'attendais, tu sais…", Tic.SULK),
        l("Une petite caresse me ferait du bien.", Tic.CURIOUS),
        l("Reste avec moi encore un peu, d'accord ?", Tic.SLOWBLINK),
        l("Je compte sur toi pour me réchauffer le cœur.", Tic.SULK),
    )

    val HAPPY = listOf(
        l("Nyxie est heureuse de te voir !", Tic.GIGGLE),
        l("Hihi, je suis bien avec toi.", Tic.GIGGLE),
        l("Je pourrais danser toute la nuit !", Tic.PROUD),
        l("Tout est parfait en ce moment.", Tic.PROUD),
        l("J'ai le cœur qui pétille !", Tic.GIGGLE),
        l("Tu sais quoi ? Je suis super contente !", Tic.GIGGLE),
        l("Hihi, j'ai envie de sautiller partout !", Tic.GIGGLE),
        l("Je me sens brillante comme une étoile.", Tic.PROUD),
        l("Avec toi, chaque jour est une fête.", Tic.PROUD),
        l("Regarde comme mes plumes brillent !", Tic.PROUD),
        l("Je crois que je souris toute seule…", Tic.GIGGLE),
        l("C'est une journée magnifique, non ?", Tic.PROUD),
        l("Mon cœur fait des petits bonds de joie.", Tic.GIGGLE),
        l("Tu es mon compagnon préféré. Chut, c'est un secret.", Tic.GIGGLE),
    )

    val CALM = listOf(
        l("Il fait doux ici…", Tic.SLOWBLINK),
        l("Tu veux jouer un peu ?", Tic.CURIOUS),
        l("Raconte-moi ta journée !", Tic.CURIOUS),
        l("Tu sais, j'aime beaucoup nos petits moments.", Tic.SLOWBLINK),
        l("On est bien, ici, tous les deux.", Tic.SLOWBLINK),
        l("J'écoute le silence… c'est apaisant.", Tic.LOOK),
        l("Je me demande ce que tu penses en ce moment.", Tic.CURIOUS),
        l("Prenons le temps de ne rien faire, juste un peu.", Tic.SLOWBLINK),
        l("J'aime quand tout est calme comme ça.", Tic.SLOWBLINK),
        l("Hum, je réfléchis à des choses importantes…", Tic.LOOK),
        l("Tu veux qu'on invente une histoire ?", Tic.CURIOUS),
        l("Je crois que j'ai entendu quelque chose…", Tic.LOOK),
        l("Ça sent bon la nuit d'été.", Tic.CURIOUS),
        l("Je compte mes plumes. Il m'en manque… non, elles y sont toutes !", Tic.GIGGLE),
        l("Dis, tu crois que les nuages ont un goût ?", Tic.CURIOUS),
        l("Parfois je me demande à quoi rêvent les étoiles.", Tic.LOOK),
        l("Quelle jolie petite vie, la nôtre.", Tic.SLOWBLINK),
        l("Hmm, hmm… je fredonne une chanson sans paroles.", Tic.PROUD),
    )

    val DREAMY = listOf(
        l("Regarde, la lune est magnifique ce soir.", Tic.LOOK),
        l("Je me demande ce qu'il y a au-delà des étoiles…", Tic.LOOK),
        l("Un jour, j'irai toucher une comète.", Tic.CURIOUS),
        l("Chaque étoile est une petite lanterne, tu crois ?", Tic.LOOK),
        l("J'ai rêvé d'un jardin qui flotte dans le ciel.", Tic.SLOWBLINK),
        l("La lune me donne de la force.", Tic.PROUD),
        l("Si je fais un vœu, tu m'aides à le garder secret ?", Tic.CURIOUS),
        l("Les étoiles filantes, ce sont des messages, non ?", Tic.LOOK),
        l("J'aimerais voler jusqu'au bout de l'arc-en-ciel.", Tic.CURIOUS),
        l("Dans mes rêves, tout brille un peu plus fort.", Tic.SLOWBLINK),
    )

    val MORNING = listOf(
        l("Bonjour, soleil ! Enfin… bonjour, toi.", Tic.GIGGLE),
        l("Une nouvelle journée, c'est tout frais !", Tic.PROUD),
        l("Le matin, tout est plein de promesses.", Tic.CURIOUS),
        l("As-tu bien dormi ? Moi, comme un nuage.", Tic.SLOWBLINK),
        l("J'ai hâte de voir ce qu'on va faire aujourd'hui !", Tic.GIGGLE),
    )

    val EVENING = listOf(
        l("Le ciel change de couleur, regarde !", Tic.LOOK),
        l("Bientôt les premières étoiles…", Tic.CURIOUS),
        l("Le soir, j'aime bien me blottir près de toi.", Tic.SLOWBLINK),
        l("La journée a filé, tu ne trouves pas ?", Tic.LOOK),
        l("C'est l'heure où la magie se réveille.", Tic.PROUD),
    )

    val NIGHT = listOf(
        l("Chut… la nuit murmure.", Tic.LOOK),
        l("Les lucioles doivent danser dehors, quelque part.", Tic.CURIOUS),
        l("Il est tard… mais je veille avec toi.", Tic.SLOWBLINK),
        l("La nuit est ma meilleure amie.", Tic.PROUD),
        l("On entend presque les étoiles respirer.", Tic.LOOK),
    )

    val PLAYFUL = listOf(
        l("Devine ce que je pense… non, je ne dis rien !", Tic.GIGGLE),
        l("Attrape-moi si tu peux !", Tic.SHAKE),
        l("J'ai une idée farceuse… mais je ne te dirai pas laquelle.", Tic.GIGGLE),
        l("Hop ! Tu as vu mon petit saut ?", Tic.PROUD),
        l("Je parie que tu ne peux pas me faire rire. Hihi.", Tic.GIGGLE),
        l("Bouh ! Je t'ai fait peur ? Non ?", Tic.SHAKE),
        l("Je vais faire semblant de dormir… tu vois, je suis très crédible.", Tic.SLOWBLINK),
        l("Chatouille, chatouille… hihihi !", Tic.GIGGLE),
        l("Et si on faisait un concours de grimaces ?", Tic.CURIOUS),
        l("J'ai caché un secret quelque part. Devine où !", Tic.LOOK),
    )

    val PET = listOf(
        l("Hihii ! J'adore quand tu me caresses ! ♥"),
        l("Encore un peu, c'est tellement doux…"),
        l("Ça chatouille, mais j'aime ça !"),
        l("Mmmh… je me sens toute légère."),
        l("Tu es la meilleure personne du monde !"),
        l("Oh oui, juste là, c'est parfait…"),
        l("Mes plumes frissonnent de bonheur !"),
        l("Tu as des mains si douces."),
        l("Ronron… enfin, un truc comme ça."),
        l("Je pourrais rester comme ça toute la nuit."),
        l("Hihi, tu me fais rougir !"),
        l("Encore, encore, encore !"),
        l("Mon cœur bat plus vite quand tu fais ça."),
        l("Merci pour la tendresse ♥"),
    )

    val EAT = listOf(
        l("Nom nom nom… merci !"),
        l("Mmh, j'en reprendrais bien un autre !"),
        l("Quel délice, vraiment !"),
        l("Mon ventre te dit merci !"),
        l("Hmm, c'est exactement ce qu'il me fallait."),
        l("Miam miam ! Tu me gâtes."),
        l("Ça fond sur la langue, c'est magique !"),
        l("Je vais en rêver cette nuit…"),
        l("Tu connais mes goûts mieux que moi !"),
        l("Une vraie gourmandise ! Merci ♥"),
    )

    val EAT_FULL = listOf(
        l("Je n'ai vraiment plus faim, merci !"),
        l("Oh non, je vais exploser si je mange encore !"),
        l("Mon ventre est tout rond, regarde !"),
        l("Plus une miette de place, promis."),
        l("Merci, mais je suis rassasiée ♥"),
    )

    val BATH = listOf(
        l("Splish splash ! Un bain de lune, quel bonheur !"),
        l("L'eau est délicieuse, plouf !"),
        l("Des bulles partout ! Hihi !"),
        l("Je suis toute propre et toute douce."),
        l("Ça sent bon la lavande des étoiles."),
        l("Ouh, ça tourbillonne ! J'adore !"),
        l("Plic ploc, je chante sous l'eau."),
        l("Merci, je me sens toute neuve !"),
    )

    val BRUSH = listOf(
        l("Mes petites plumes brillent à nouveau !"),
        l("Ah, c'était emmêlé là… merci !"),
        l("Ça démange agréablement, continue !"),
        l("Je suis toute lisse maintenant."),
        l("Tu brosses comme un artiste !"),
        l("Oh, je brille comme une étoile !"),
        l("Mmh, quel bien-être…"),
        l("Plus une plume de travers !"),
    )

    val PLAY = listOf(
        l("On joue ! On joue ! Attrape-moi !"),
        l("Youhou ! C'est trop amusant !"),
        l("Encore une partie, s'il te plaît !"),
        l("Prête ? Partez !"),
        l("J'adore jouer avec toi !"),
        l("Je vais tout donner, tu vas voir !"),
        l("Que le meilleur gagne… c'est-à-dire moi !"),
        l("Hihi, c'est parti pour l'aventure !"),
    )

    val TOO_TIRED = listOf(
        l("Je suis trop fatiguée pour jouer… Un petit dodo ?", Tic.YAWN),
        l("Mes ailes ne veulent plus bouger… demain, d'accord ?", Tic.YAWN),
        l("J'aimerais bien, mais je n'en peux plus…", Tic.SLOWBLINK),
        l("Même mes yeux sont fatigués. Repos d'abord !", Tic.YAWN),
    )

    val STARS_GOOD = listOf(
        l("{n} étoiles attrapées ! Incroyable !"),
        l("{n} étoiles ! Je suis éblouie !"),
        l("Waouh, {n} étoiles dans mon panier !"),
        l("Quelle pluie magnifique : {n} étoiles !"),
        l("{n} ! Tu es une championne des étoiles !"),
        l("Mon record a pris un coup de neuf avec {n} !"),
        l("{n} étoiles, ça mérite une danse !"),
        l("Hihi, j'en ai plein les mains : {n} étoiles !"),
    )

    val STARS_OK = listOf(
        l("{n} étoiles attrapées ! Bien joué !"),
        l("Pas mal du tout : {n} étoiles !"),
        l("{n} étoiles, c'est un joli petit butin."),
        l("On a bien rigolé, {n} étoiles !"),
        l("{n} étoiles ! On fera encore mieux la prochaine fois."),
    )

    val STARS_LOW = listOf(
        l("Oups, seulement {n}… elles allaient trop vite !"),
        l("{n} étoiles… on se rattrape à la prochaine ?"),
        l("Pas grave, {n} c'est déjà un début !"),
        l("Elles se sont cachées ! Seulement {n}."),
        l("{n}… je suis sûre qu'on peut faire mieux, ensemble."),
        l("Même les étoiles ont besoin d'un peu de repos : {n}."),
    )

    val MEMORY_GOOD = listOf(
        l("Bravo, en {n} coups ! Quelle mémoire !"),
        l("Seulement {n} coups ! Tu es un génie !"),
        l("{n} coups, c'est presque trop beau !"),
        l("Mes yeux n'ont rien vu venir : {n} coups !"),
        l("Mémoire d'éléphant… avec des ailes ! {n} coups."),
        l("Je suis impressionnée, {n} coups !"),
    )

    val MEMORY_OK = listOf(
        l("Bravo, en {n} coups !"),
        l("{n} coups, joli travail d'équipe !"),
        l("On a trouvé toutes les paires en {n} coups."),
        l("{n} coups ! Un peu de pratique et ce sera parfait."),
    )

    val MEMORY_LONG = listOf(
        l("Ouf, en {n} coups ! Mais on y est arrivés."),
        l("{n} coups… c'était un vrai casse-tête !"),
        l("Elles étaient bien cachées, ces paires ! {n} coups."),
        l("Quel marathon, {n} coups ! On réessaie ?"),
        l("Patience et persévérance : {n} coups."),
    )

    val REUNION_SHORT = listOf(
        l("Te revoilà ! Tu m'as manqué…", Tic.GIGGLE),
        l("Oh, tu es déjà de retour !", Tic.GIGGLE),
        l("Coucou toi ! Ça fait plaisir.", Tic.PROUD),
        l("Je pensais justement à toi !", Tic.CURIOUS),
        l("Ah, enfin ! Je commençais à m'ennuyer un peu.", Tic.GIGGLE),
        l("Tu reviens vite, c'est adorable.", Tic.PROUD),
    )

    val REUNION_LONG = listOf(
        l("Tu étais parti un moment… mais je suis si contente !", Tic.GIGGLE),
        l("Te voilà enfin ! J'ai compté les étoiles en t'attendant.", Tic.PROUD),
        l("Tu m'as tellement manqué, j'ai fait plein de rêves.", Tic.SLOWBLINK),
        l("Ça fait une éternité ! Raconte tout !", Tic.CURIOUS),
        l("J'ai gardé quelque chose pour toi pendant ton absence.", Tic.GIGGLE),
        l("Oh, c'est toi ! Je savais que tu reviendrais.", Tic.PROUD),
    )

    val WAKE = listOf(
        l("Hmm… déjà réveillée ? *bâille*", Tic.YAWN),
        l("Mmmh… cinq minutes de plus…", Tic.YAWN),
        l("Oh, tu es là… *s'étire*", Tic.YAWN),
        l("Bonjour… ou bonsoir ? Je ne sais plus.", Tic.SLOWBLINK),
        l("*bâille* J'ai fait un si joli rêve.", Tic.YAWN),
        l("Je me réveille tout doucement…", Tic.SLOWBLINK),
    )

    val WOKE_RESTED = listOf(
        l("Bien dormi ! Je suis en pleine forme !", Tic.PROUD),
        l("Quelle belle nuit ! Je me sens pétillante.", Tic.GIGGLE),
        l("Rechargée à bloc, prête pour la journée !", Tic.PROUD),
        l("J'ai rêvé de toi, je crois. Hihi.", Tic.GIGGLE),
    )

    val GOING_TO_BED = listOf(
        l("Bonne nuit… zzz"),
        l("Dors bien aussi… zzz"),
        l("À demain, mon étoile… zzz"),
        l("Je ferme les yeux… tout doucement… zzz"),
        l("Fais de beaux rêves… zzz"),
    )

    val NOT_SLEEPY = listOf(
        l("Je n'ai pas sommeil du tout !", Tic.SHAKE),
        l("Dormir ? Mais je suis pleine d'énergie !", Tic.SHAKE),
        l("Pas maintenant, j'ai trop envie de m'amuser !", Tic.GIGGLE),
        l("Mes yeux sont grands ouverts, regarde !", Tic.CURIOUS),
    )

    val EQUIP = listOf(
        l("Oh, c'est joli !", Tic.PROUD),
        l("Ça me va bien, non ?", Tic.PROUD),
        l("Hihi, je me sens toute belle !", Tic.GIGGLE),
        l("Un vrai petit coup de style !", Tic.PROUD),
        l("Tu as du goût, toi ♥", Tic.GIGGLE),
        l("Regarde comme ça brille !", Tic.PROUD),
        l("J'adore, merci !", Tic.GIGGLE),
        l("Je me sens pleine de magie avec ça.", Tic.PROUD),
    )

    val LEVEL_UP = listOf(
        l("Je grandis ! Niveau {n} !", Tic.PROUD),
        l("Niveau {n} ! Je me sens plus forte !", Tic.PROUD),
        l("Hihi, niveau {n} ! Merci pour tout ♥", Tic.GIGGLE),
        l("Encore un cap franchi : niveau {n} !", Tic.PROUD),
        l("Mes ailes poussent ! Niveau {n} !", Tic.GIGGLE),
        l("Niveau {n}… on forme une belle équipe.", Tic.PROUD),
    )

    val QUEST_DONE = listOf(
        l("Mission accomplie ! Tu peux récupérer ta récompense !", Tic.PROUD),
        l("Une quête de terminée, bravo !", Tic.PROUD),
        l("On est efficaces, tous les deux !", Tic.GIGGLE),
        l("Hop, une de plus de faite !", Tic.PROUD),
    )

    val ACTIVITY_DONE = listOf(
        l("Activité terminée ! +{n} pièces"),
        l("Voilà, c'est fait ! +{n} pièces"),
        l("Quelle belle aventure ! +{n} pièces"),
        l("J'ai tout donné ! +{n} pièces"),
    )

    val PHOTO = listOf(
        l("Souris ! Cheese… enfin, un truc comme ça !", Tic.GIGGLE),
        l("Je prends ma plus belle pose !", Tic.PROUD),
        l("Clic ! On est magnifiques !", Tic.GIGGLE),
        l("Un souvenir de plus pour notre album.", Tic.PROUD),
    )

    /** Heure -> catégorie de moment de la journée (ou null). */
    private fun timeBank(): List<Line>? {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return when (h) {
            in 6..10 -> MORNING
            in 17..20 -> EVENING
            in 21..23, in 0..4 -> NIGHT
            else -> null
        }
    }

    /** Choix de la catégorie de phrases spontanées selon l'état de Nyxie. */
    fun idleBank(s: GameState): List<Line> {
        if (s.hunger < 0.25f) return HUNGRY
        if (s.energy < 0.2f) return TIRED
        if (s.affection < 0.25f) return LONELY
        val roll = kotlin.random.Random.nextInt(100)
        val time = timeBank()
        return when {
            roll < 18 && time != null -> time
            roll < 36 && s.mood > 0.65f -> HAPPY
            roll < 50 -> PLAYFUL
            roll < 64 -> DREAMY
            roll < 70 && s.hunger < 0.5f -> HUNGRY
            roll < 76 && s.energy < 0.45f -> TIRED
            else -> CALM
        }
    }

    /** Phrase quand on touche Nyxie pour discuter (plus orientée « état »). */
    fun talkBank(s: GameState): List<Line> = when {
        s.hunger < 0.3f -> HUNGRY
        s.energy < 0.25f -> TIRED
        s.affection < 0.3f -> LONELY
        else -> if (kotlin.random.Random.nextBoolean() && s.mood > 0.6f) HAPPY else (CALM + DREAMY)
    }
}

/** Mémoire anti-répétition : évite de redire les dernières phrases d'une catégorie. */
class LinePicker {
    private val recent = HashMap<List<Line>, ArrayDeque<String>>()
    private var last: String? = null

    fun pick(bank: List<Line>): Line {
        val hist = recent.getOrPut(bank) { ArrayDeque() }
        val keep = (bank.size / 2).coerceIn(1, 8)
        var cand = bank.filter { it.text !in hist && it.text != last }
        if (cand.isEmpty()) cand = bank.filter { it.text != last }.ifEmpty { bank }
        val chosen = cand.random()
        hist.addLast(chosen.text)
        while (hist.size > keep) hist.removeFirst()
        last = chosen.text
        return chosen
    }
}
