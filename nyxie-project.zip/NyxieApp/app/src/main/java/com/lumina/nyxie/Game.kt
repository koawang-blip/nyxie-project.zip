package com.lumina.nyxie

import android.content.Context
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

// ---------------------------------------------------------------------------
// Écrans, réactions, objets
// ---------------------------------------------------------------------------

enum class Screen(val label: String) {
    HOME("Accueil"),
    QUESTS("Quêtes"),
    PHOTO("Mode photo"),
    CHAT("Discussion"),
    CARE("Soins"),
    GAMES("Jeux"),
    STYLE("Personnalisation"),
    GALLERY("Galerie"),
    BAG("Inventaire"),
    EVOLUTION("Évolution"),
    SETTINGS("Paramètres"),
}

/** Ce que Nyxie est en train de faire (anime son visage et les particules). */
enum class Reaction { NONE, EAT, PET, PLAY, TALK, GIFT, ACTIVITY }

enum class ItemKind { FOOD, TOY, TONIC, ACCESSORY, THEME, AMBIANCE }

data class Item(
    val id: String,
    val name: String,
    val kind: ItemKind,
    val price: Int,
    val useGems: Boolean = false,
    val hunger: Float = 0f,
    val energy: Float = 0f,
    val affection: Float = 0f,
    val xp: Int = 0,
    val glyph: String,
    val desc: String,
    /** Emplacement des accessoires : head, face, neck ou aura. */
    val slot: String = "",
    /** Rareté explicite ; sinon déduite du prix. */
    val rarityOverride: Rarity? = null,
    /** Monnaie explicite (événements, achats réels à venir) ; sinon pièces ou gemmes. */
    val currencyOverride: Currency? = null,
    /** Disponibilité : toujours, lié à un événement, ou en édition limitée. */
    val availability: Availability = Availability.ALWAYS,
    /** Identifiant de l'événement qui propose cet objet (null = boutique normale). */
    val eventId: String? = null,
) {
    val currency: Currency get() = currencyOverride ?: if (useGems) Currency.GEMS else Currency.COINS
    val rarity: Rarity
        get() = rarityOverride ?: when (currency) {
            Currency.GEMS -> if (price < 5) Rarity.RARE else if (price < 8) Rarity.EPIC else Rarity.LEGENDARY
            else -> if (price <= 50) Rarity.COMMON else if (price <= 150) Rarity.RARE else if (price <= 250) Rarity.EPIC else Rarity.LEGENDARY
        }
    val categoryLabel: String
        get() = when (kind) {
            ItemKind.FOOD -> "Nourriture"
            ItemKind.TONIC -> "Boisson"
            ItemKind.TOY -> "Jouet"
            ItemKind.ACCESSORY -> when (slot) {
                "head" -> "Accessoire – tête"
                "face" -> "Accessoire – visage"
                "neck" -> "Accessoire – cou"
                else -> "Aura"
            }
            ItemKind.THEME -> "Thème"
            ItemKind.AMBIANCE -> "Ambiance"
        }
}

enum class Rarity(val label: String, val color: Long) {
    COMMON("Commun", 0xFFB8B0D0),
    RARE("Rare", 0xFF6FB6FF),
    EPIC("Épique", 0xFFC58BFF),
    LEGENDARY("Légendaire", 0xFFFFC857),
}

/** Les trois sortes de monnaie sont clairement séparées ; l'argent réel n'est pas encore utilisé. */
enum class Currency(val label: String, val glyph: String, val how: String) {
    COINS("Pièces", "", "Gagnées en jouant, en prenant soin de Nyxie et avec les quêtes."),
    GEMS("Gemmes", "", "Récompenses rares : coffre du jour, quêtes bonus, grandes retrouvailles."),
    EVENT("Jetons d'événement", "🎟️", "Gagnés gratuitement pendant un événement."),
    REAL_MONEY("Achat réel", "💳", "Paiement en argent réel (pas encore disponible)."),
}

enum class Availability(val label: String) {
    ALWAYS("Toujours disponible"),
    EVENT("Pendant l'événement"),
    LIMITED("Édition limitée"),
}

data class ActivityDef(
    val id: String,
    val name: String,
    val glyph: String,
    val durationSec: Int,
    val energyDelta: Float,
    val affection: Float,
    val xp: Int,
    val coins: Int,
    val line: String,
)

object Catalog {
    val items: List<Item> = listOf(
        // ---- Nourriture
        Item("berry", "Baie lunaire", ItemKind.FOOD, 15, hunger = 0.20f, xp = 4, glyph = "🫐",
            desc = "Une petite baie sucrée qui brille la nuit."),
        Item("apple", "Pomme de lune", ItemKind.FOOD, 20, hunger = 0.22f, xp = 5, glyph = "🍎",
            desc = "Croquante et un peu argentée."),
        Item("cookie", "Cookie étoilé", ItemKind.FOOD, 30, hunger = 0.28f, affection = 0.03f, xp = 6, glyph = "🍪",
            desc = "Des pépites de poussière d'étoile."),
        Item("cake", "Gâteau étoilé", ItemKind.FOOD, 40, hunger = 0.35f, affection = 0.05f, xp = 8, glyph = "🧁",
            desc = "Un régal pour les grandes occasions."),
        Item("icecream", "Glace comète", ItemKind.FOOD, 45, hunger = 0.30f, affection = 0.08f, xp = 9, glyph = "🍦",
            desc = "Fraîche, avec une traînée scintillante."),
        Item("soup", "Soupe de nuage", ItemKind.FOOD, 55, hunger = 0.45f, energy = 0.05f, xp = 10, glyph = "🍲",
            desc = "Chaude, douce et réconfortante."),
        Item("fish", "Poisson cristal", ItemKind.FOOD, 70, hunger = 0.55f, energy = 0.05f, xp = 12, glyph = "🐟",
            desc = "Un vrai festin, très nourrissant."),
        Item("pie", "Tarte aux fraises", ItemKind.FOOD, 85, hunger = 0.60f, affection = 0.06f, xp = 16, glyph = "🥧",
            desc = "Sa gourmandise préférée."),
        Item("feast", "Festin royal", ItemKind.FOOD, 150, hunger = 1.0f, energy = 0.10f, affection = 0.10f, xp = 30,
            glyph = "🍱", desc = "Un repas complet qui rassasie pour de bon."),
        Item("lollipop", "Sucette scintillante", ItemKind.FOOD, 20, hunger = 0.15f, affection = 0.06f, xp = 4, glyph = "🍭",
            desc = "Un sucre qui pétille sur la langue."),
        Item("grapes", "Grappes de rosée", ItemKind.FOOD, 18, hunger = 0.2f, xp = 4, glyph = "🍇",
            desc = "Des grains frais couverts de rosée."),
        Item("peach", "Pêche de brume", ItemKind.FOOD, 22, hunger = 0.24f, xp = 5, glyph = "🍑",
            desc = "Douce et parfumée comme un matin brumeux."),
        Item("popcorn", "Pop-corn d'étoiles", ItemKind.FOOD, 28, hunger = 0.22f, affection = 0.04f, xp = 5, glyph = "🍿",
            desc = "Il éclate en petites étincelles."),
        Item("salad", "Salade fleurie", ItemKind.FOOD, 33, hunger = 0.3f, xp = 6, glyph = "🥗",
            desc = "Fraîche, croquante et pleine de pétales."),
        Item("donut", "Beignet arc-en-ciel", ItemKind.FOOD, 38, hunger = 0.3f, affection = 0.05f, xp = 7, glyph = "🍩",
            desc = "Un glaçage multicolore."),
        Item("choco", "Chocolat étoilé", ItemKind.FOOD, 42, hunger = 0.28f, affection = 0.07f, xp = 8, glyph = "🍫",
            desc = "Fond doucement et réchauffe le cœur."),
        Item("pancake", "Crêpes de minuit", ItemKind.FOOD, 48, hunger = 0.38f, affection = 0.04f, xp = 9, glyph = "🥞",
            desc = "Dorées, avec un filet de miel."),
        Item("sushi", "Perles marines", ItemKind.FOOD, 52, hunger = 0.4f, xp = 9, glyph = "🍙",
            desc = "De petites boules de riz parfumées."),
        Item("pudding", "Flan de rêve", ItemKind.FOOD, 58, hunger = 0.38f, affection = 0.08f, xp = 11, glyph = "🍮",
            desc = "Un dessert qui tremble de bonheur."),
        Item("dumpling", "Raviolis nuageux", ItemKind.FOOD, 60, hunger = 0.46f, xp = 10, glyph = "🥟",
            desc = "Moelleux, fumants et délicieux."),
        Item("pizza", "Pizza des constellations", ItemKind.FOOD, 65, hunger = 0.5f, xp = 11, glyph = "🍕",
            desc = "Garnie d'étoiles de fromage."),
        Item("cheese", "Fondue lunaire", ItemKind.FOOD, 75, hunger = 0.52f, energy = 0.03f, xp = 12, glyph = "🧀",
            desc = "Un bain de fromage fondant."),
        Item("banquet", "Banquet des étoiles", ItemKind.FOOD, 220, hunger = 1.0f, energy = 0.15f, affection = 0.15f, xp = 45, glyph = "🎂",
            desc = "Le repas des grandes fêtes : tout y est !"),
        // ---- Boissons et toniques
        Item("tea", "Thé apaisant", ItemKind.TONIC, 35, energy = 0.22f, affection = 0.05f, xp = 5, glyph = "🍵",
            desc = "Une tisane tiède pour se détendre."),
        Item("nectar", "Nectar des rêves", ItemKind.TONIC, 50, energy = 0.35f, xp = 6, glyph = "🍯",
            desc = "Redonne de l'énergie."),
        Item("potion", "Potion d'éclat", ItemKind.TONIC, 3, useGems = true, hunger = 0.25f, energy = 0.25f,
            affection = 0.25f, xp = 15, glyph = "🧪", desc = "Un peu de tout, en une gorgée."),
        Item("elixir", "Élixir stellaire", ItemKind.TONIC, 6, useGems = true, hunger = 0.15f, energy = 0.60f,
            xp = 20, glyph = "🌟", desc = "Une énergie à toute épreuve."),
        Item("growth", "Potion de croissance", ItemKind.TONIC, 5, useGems = true, hunger = 0.05f, energy = 0.05f,
            affection = 0.05f, xp = 60, glyph = "🔮", desc = "Beaucoup d'expérience d'un coup."),
        Item("starwater", "Eau d'étoile", ItemKind.TONIC, 12, energy = 0.1f, xp = 2, glyph = "💧",
            desc = "Claire et rafraîchissante."),
        Item("milk", "Lait de lune", ItemKind.TONIC, 28, energy = 0.18f, affection = 0.03f, xp = 4, glyph = "🥛",
            desc = "Doux et crémeux, parfait avant le dodo."),
        Item("lemonade", "Limonade pétillante", ItemKind.TONIC, 32, energy = 0.2f, xp = 4, glyph = "🥤",
            desc = "Des bulles qui chatouillent le nez."),
        Item("juice", "Jus de comète", ItemKind.TONIC, 40, energy = 0.26f, xp = 5, glyph = "🧃",
            desc = "Un jus vitaminé et brillant."),
        Item("cocoa", "Chocolat chaud", ItemKind.TONIC, 45, energy = 0.28f, affection = 0.08f, xp = 6, glyph = "☕",
            desc = "Une tasse bien chaude et réconfortante."),
        Item("dew", "Rosée enchantée", ItemKind.TONIC, 4, useGems = true, hunger = 0.1f, energy = 0.15f, affection = 0.3f, xp = 25, glyph = "🫧",
            desc = "Rend Nyxie toute câline."),
        Item("dawnelixir", "Élixir d'aurore", ItemKind.TONIC, 8, useGems = true, hunger = 0.4f, energy = 1.0f, affection = 0.2f, xp = 40, glyph = "🌈",
            desc = "Faim, énergie et affection d'un coup."),
        // ---- Jouets
        Item("feather", "Plume enchantée", ItemKind.TOY, 25, affection = 0.06f, energy = -0.02f, glyph = "🪶",
            desc = "Un jouet qui chatouille. Bonus de jeu."),
        Item("ball", "Balle lumineuse", ItemKind.TOY, 35, affection = 0.10f, energy = -0.04f, glyph = "🔮",
            desc = "Elle adore la poursuivre. Gros bonus de jeu."),
        Item("plush", "Peluche lune", ItemKind.TOY, 60, affection = 0.14f, energy = -0.03f, glyph = "🧸",
            desc = "Un compagnon tout doux pour les câlins."),
        Item("kite", "Cerf-volant", ItemKind.TOY, 80, affection = 0.16f, energy = -0.08f, glyph = "🪁",
            desc = "Pour courir et rire dans le vent."),
        Item("musicbox", "Boîte à musique", ItemKind.TOY, 120, affection = 0.20f, energy = 0.02f, glyph = "🎶",
            desc = "Une mélodie qui l'apaise et la ravit."),
        Item("goldball", "Balle dorée", ItemKind.TOY, 4, useGems = true, affection = 0.30f, energy = -0.05f,
            glyph = "🏅", desc = "Le jouet le plus amusant de tous."),
        Item("yarn", "Pelote magique", ItemKind.TOY, 30, affection = 0.08f, energy = -0.03f, glyph = "🧶",
            desc = "Elle roule toute seule… presque."),
        Item("bubbles", "Bulles de savon", ItemKind.TOY, 40, affection = 0.11f, energy = -0.03f, glyph = "🫧",
            desc = "À éclater une par une."),
        Item("blocks", "Cubes empilables", ItemKind.TOY, 45, affection = 0.12f, energy = -0.04f, glyph = "🧩",
            desc = "On construit, on casse, on recommence."),
        Item("puppet", "Pantin articulé", ItemKind.TOY, 90, affection = 0.17f, energy = -0.05f, glyph = "🪆",
            desc = "Un petit ami qui danse."),
        Item("drum", "Petit tambour", ItemKind.TOY, 70, affection = 0.15f, energy = -0.06f, glyph = "🥁",
            desc = "Boum boum, quel rythme !"),
        Item("lantern", "Lanterne magique", ItemKind.TOY, 100, affection = 0.18f, energy = -0.02f, glyph = "🏮",
            desc = "Elle projette des étoiles au plafond."),
        Item("telescope", "Télescope en laiton", ItemKind.TOY, 140, affection = 0.22f, energy = -0.02f, glyph = "🔭",
            desc = "Pour observer les constellations ensemble."),
        Item("discoball", "Boule à facettes", ItemKind.TOY, 160, affection = 0.24f, energy = -0.07f, glyph = "🪩",
            desc = "Une piste de danse miniature."),
        Item("rainbowkite", "Comète arc-en-ciel", ItemKind.TOY, 5, useGems = true, affection = 0.34f, energy = -0.06f, glyph = "🌈",
            desc = "Le jouet le plus magique de la boutique."),
        // ---- Accessoires : tête
        Item("acc_flower", "Fleur de lune", ItemKind.ACCESSORY, 120, glyph = "🌼", slot = "head",
            desc = "Une fleur près de l'oreille."),
        Item("acc_bow", "Nœud rose", ItemKind.ACCESSORY, 150, glyph = "🎀", slot = "head", desc = "Un nœud tout doux."),
        Item("acc_party", "Chapeau de fête", ItemKind.ACCESSORY, 140, glyph = "🥳", slot = "head",
            desc = "Pour fêter chaque petite victoire."),
        Item("acc_headband", "Serre-tête étoilé", ItemKind.ACCESSORY, 200, glyph = "⭐", slot = "head",
            desc = "Une étoile qui scintille sur le côté."),
        Item("acc_flowercrown", "Couronne de fleurs", ItemKind.ACCESSORY, 220, glyph = "💐", slot = "head",
            desc = "Des fleurs de toutes les couleurs."),
        Item("acc_witch", "Chapeau de sorcière", ItemKind.ACCESSORY, 180, glyph = "🧙", slot = "head",
            desc = "Violet, étoilé, un peu magique."),
        Item("acc_halo", "Auréole lumineuse", ItemKind.ACCESSORY, 10, useGems = true, glyph = "😇", slot = "head",
            desc = "Elle flotte doucement au-dessus de sa tête."),
        Item("acc_crown", "Couronne dorée", ItemKind.ACCESSORY, 8, useGems = true, glyph = "👑", slot = "head",
            desc = "Pour une vraie petite reine."),
        Item("acc_nightcap", "Bonnet de nuit", ItemKind.ACCESSORY, 130, glyph = "😴", slot = "head",
            desc = "Pour des rêves bien au chaud."),
        Item("acc_mushroom", "Chapeau champignon", ItemKind.ACCESSORY, 150, glyph = "🍄", slot = "head",
            desc = "Rouge à pois, tout droit sorti de la forêt."),
        Item("acc_catears", "Oreilles de chat", ItemKind.ACCESSORY, 160, glyph = "🐱", slot = "head",
            desc = "Miaou ! Un air très espiègle."),
        Item("acc_moontiara", "Diadème de lune", ItemKind.ACCESSORY, 7, useGems = true, glyph = "🌙", slot = "head",
            desc = "Un croissant d'or sur le front."),
        Item("acc_beret", "Béret d'artiste", ItemKind.ACCESSORY, 110, glyph = "🎨", slot = "head",
            desc = "Un petit air parisien."),
        Item("acc_bunnyears", "Oreilles de lapin", ItemKind.ACCESSORY, 140, glyph = "🐰", slot = "head",
            desc = "Longues, douces et très mignonnes."),
        Item("acc_leafcrown", "Couronne de feuilles", ItemKind.ACCESSORY, 125, glyph = "🌿", slot = "head",
            desc = "Tressée avec des brins de forêt."),
        // ---- Accessoires : visage
        Item("acc_cheekstars", "Étoiles de joue", ItemKind.ACCESSORY, 90, glyph = "✨", slot = "face",
            desc = "De petits autocollants brillants."),
        Item("acc_glasses", "Lunettes rondes", ItemKind.ACCESSORY, 130, glyph = "👓", slot = "face",
            desc = "Pour un air savant."),
        Item("acc_sunglasses", "Lunettes de soleil", ItemKind.ACCESSORY, 180, glyph = "🕶️", slot = "face",
            desc = "Très stylée, même la nuit."),
        Item("acc_freckles", "Taches de rousseur", ItemKind.ACCESSORY, 70, glyph = "🟤", slot = "face",
            desc = "Quelques éclats de soleil sur les joues."),
        Item("acc_monocle", "Monocle doré", ItemKind.ACCESSORY, 170, glyph = "🧐", slot = "face",
            desc = "Très distingué, avec sa petite chaîne."),
        Item("acc_heartglasses", "Lunettes cœur", ItemKind.ACCESSORY, 190, glyph = "💖", slot = "face",
            desc = "Pour voir la vie en rose."),
        Item("acc_glitter", "Paillettes", ItemKind.ACCESSORY, 80, glyph = "✨", slot = "face",
            desc = "Des éclats de lumière sur le visage."),
        Item("acc_heartcheeks", "Joues en cœur", ItemKind.ACCESSORY, 90, glyph = "💗", slot = "face",
            desc = "Deux petits cœurs maquillés."),
        Item("acc_whiskers", "Moustaches de chat", ItemKind.ACCESSORY, 60, glyph = "😺", slot = "face",
            desc = "Trois traits de chaque côté."),
        // ---- Accessoires : cou
        Item("acc_bowtie", "Nœud papillon", ItemKind.ACCESSORY, 110, glyph = "🎩", slot = "neck",
            desc = "Élégant pour les grandes soirées."),
        Item("acc_scarf", "Écharpe rayée", ItemKind.ACCESSORY, 160, glyph = "🧣", slot = "neck",
            desc = "Bien au chaud."),
        Item("acc_pearls", "Collier de perles", ItemKind.ACCESSORY, 250, glyph = "📿", slot = "neck",
            desc = "Des perles nacrées."),
        Item("acc_belltie", "Collier à clochette", ItemKind.ACCESSORY, 120, glyph = "🔔", slot = "neck",
            desc = "Ding ding ! On l'entend arriver."),
        Item("acc_garland", "Guirlande de fleurs", ItemKind.ACCESSORY, 180, glyph = "🌺", slot = "neck",
            desc = "Des fleurs fraîches autour du cou."),
        Item("acc_medallion", "Médaillon de lune", ItemKind.ACCESSORY, 240, glyph = "🌕", slot = "neck",
            desc = "Un petit pendentif précieux."),
        Item("acc_bandana", "Bandana d'aventurière", ItemKind.ACCESSORY, 95, glyph = "🧣", slot = "neck",
            desc = "Pour partir à l'aventure."),
        Item("acc_starcollar", "Collier étoile", ItemKind.ACCESSORY, 130, glyph = "⭐", slot = "neck",
            desc = "Une étoile dorée qui scintille."),
        Item("acc_ruffle", "Collerette", ItemKind.ACCESSORY, 110, glyph = "🤍", slot = "neck",
            desc = "Volants blancs très chics."),
        // ---- Auras animées
        Item("aura_bubbles", "Bulles magiques", ItemKind.ACCESSORY, 200, glyph = "🫧", slot = "aura",
            desc = "Des bulles qui montent autour d'elle."),
        Item("aura_hearts", "Cœurs flottants", ItemKind.ACCESSORY, 260, glyph = "💕", slot = "aura",
            desc = "Des petits cœurs qui s'envolent."),
        Item("aura_stars", "Étoiles en orbite", ItemKind.ACCESSORY, 6, useGems = true, glyph = "💫", slot = "aura",
            desc = "Des étoiles qui tournent autour d'elle."),
        Item("aura_petals", "Pétales en tourbillon", ItemKind.ACCESSORY, 220, glyph = "🌸", slot = "aura",
            desc = "Des pétales qui tournoient autour d'elle."),
        Item("aura_sparks", "Éclats dorés", ItemKind.ACCESSORY, 5, useGems = true, glyph = "🌟", slot = "aura",
            desc = "Des étincelles dorées qui montent."),
        // ---- Ambiances
        Item("amb_sunset", "Coucher de soleil", ItemKind.AMBIANCE, 150, glyph = "🌅", desc = "Une lumière orangée très douce."),
        Item("amb_night", "Nuit profonde", ItemKind.AMBIANCE, 150, glyph = "🌃", desc = "Un ciel bleu nuit étoilé."),
        Item("amb_petals", "Pétales de cerisier", ItemKind.AMBIANCE, 200, glyph = "🌸", desc = "Une pluie de pétales roses."),
        Item("amb_snow", "Neige légère", ItemKind.AMBIANCE, 200, glyph = "❄️", desc = "De doux flocons qui tombent."),
        Item("amb_meteor", "Étoiles filantes", ItemKind.AMBIANCE, 250, glyph = "🌠", desc = "Un ciel qui s'illumine."),
        Item("amb_fireflies", "Lucioles", ItemKind.AMBIANCE, 300, glyph = "🪲", desc = "Des lueurs dorées qui dansent."),
        Item("amb_aurora", "Aurore boréale", ItemKind.AMBIANCE, 400, glyph = "🌌", desc = "Des voiles verts et violets."),
        Item("amb_dawn", "Aube rose", ItemKind.AMBIANCE, 150, glyph = "🌄", desc = "Une lumière pastel de petit matin."),
        Item("amb_twilight", "Crépuscule violet", ItemKind.AMBIANCE, 170, glyph = "🌆", desc = "Un ciel qui bascule vers la nuit."),
        Item("amb_mist", "Brume lunaire", ItemKind.AMBIANCE, 180, glyph = "🌫️", desc = "Une brume douce qui flotte."),
        Item("amb_rain", "Pluie douce", ItemKind.AMBIANCE, 220, glyph = "🌧️", desc = "Des gouttes fines sur la nuit."),
        // ---- Objets d'événement (offerts, non vendus : visibles dans la boutique une fois obtenus)
        Item("amb_glowfest", "Nuit des lucioles", ItemKind.AMBIANCE, 0, glyph = "🪲", desc = "Des lucioles dorées et une douce lueur verte.",
            rarityOverride = Rarity.EPIC, currencyOverride = Currency.EVENT, availability = Availability.EVENT, eventId = "ev_fireflies_2026"),
        Item("acc_fireflycrown", "Couronne de lucioles", ItemKind.ACCESSORY, 0, glyph = "✨", slot = "head",
            desc = "Des feuilles et de minuscules lanternes vivantes.",
            rarityOverride = Rarity.LEGENDARY, currencyOverride = Currency.EVENT, availability = Availability.EVENT, eventId = "ev_fireflies_2026"),
        Item("theme_glow", "Thème Lueur", ItemKind.THEME, 0, glyph = "💛", desc = "Un jaune-vert lumineux comme une luciole.",
            rarityOverride = Rarity.EPIC, currencyOverride = Currency.EVENT, availability = Availability.EVENT, eventId = "ev_fireflies_2026"),
        // ---- Thèmes de couleur
        Item("theme_violet", "Thème Violet", ItemKind.THEME, 0, glyph = "🟣", desc = "Les couleurs d'origine."),
        Item("theme_rose", "Thème Rose", ItemKind.THEME, 100, glyph = "🌸", desc = "Des teintes roses et douces."),
        Item("theme_aqua", "Thème Aqua", ItemKind.THEME, 100, glyph = "🌊", desc = "Des teintes turquoise."),
        Item("theme_gold", "Thème Or", ItemKind.THEME, 150, glyph = "🟡", desc = "Des teintes dorées chaleureuses."),
        Item("theme_mint", "Thème Menthe", ItemKind.THEME, 150, glyph = "🟢", desc = "Des teintes vert menthe."),
        Item("theme_ruby", "Thème Rubis", ItemKind.THEME, 150, glyph = "🔴", desc = "Des teintes rouge profond."),
        Item("theme_sky", "Thème Ciel", ItemKind.THEME, 100, glyph = "🔵", desc = "Un bleu clair et lumineux."),
        Item("theme_lilac", "Thème Lilas", ItemKind.THEME, 100, glyph = "🪻", desc = "Un violet poudré très doux."),
        Item("theme_peach", "Thème Pêche", ItemKind.THEME, 100, glyph = "🍑", desc = "Des tons chauds et tendres."),
        Item("theme_coral", "Thème Corail", ItemKind.THEME, 120, glyph = "🪸", desc = "Un rose orangé vivant."),
        Item("theme_indigo", "Thème Indigo", ItemKind.THEME, 120, glyph = "🔷", desc = "Un bleu profond de nuit d'été."),
        Item("theme_orange", "Thème Orange", ItemKind.THEME, 150, glyph = "🟠", desc = "Énergique comme un coucher de soleil."),
        Item("theme_lime", "Thème Citron vert", ItemKind.THEME, 150, glyph = "🟢", desc = "Vif et acidulé."),
        Item("theme_silver", "Thème Argent", ItemKind.THEME, 200, glyph = "⚪", desc = "Un éclat de lune froide."),
    )
    val byId: Map<String, Item> = items.associateBy { it.id }

    val activities: List<ActivityDef> = listOf(
        ActivityDef("moon", "Contempler la lune", "🌙", 30, 0f, 0.12f, 12, 6,
            "Regardons la lune ensemble…"),
        ActivityDef("read", "Lire un grimoire", "📖", 45, -0.04f, 0.05f, 18, 10,
            "Une histoire de dragons étoilés !"),
        ActivityDef("meditate", "Méditer", "🧘", 40, 0.15f, 0.04f, 10, 4,
            "Respire doucement avec moi…"),
        ActivityDef("dance", "Danser sous les étoiles", "💃", 25, -0.08f, 0.10f, 16, 8,
            "Une petite danse, juste pour toi !"),
    )
    val activityById: Map<String, ActivityDef> = activities.associateBy { it.id }
}

data class Interaction(val kind: String, val at: Long)

data class GameState(
    val name: String = "Nyxie",
    val level: Int = 1,
    val xp: Int = 0,
    val coins: Int = 120,
    val gems: Int = 5,
    val hunger: Float = 0.75f,     // niveau de satiété : plein = pas faim
    val energy: Float = 0.9f,
    val affection: Float = 0.6f,
    val sleeping: Boolean = false,
    val inventory: Map<String, Int> = mapOf("berry" to 3, "cake" to 1, "feather" to 1, "ball" to 1),
    val owned: Set<String> = setOf("acc_none", "theme_violet"),
    val accessory: String = "acc_none",   // emplacement « tête »
    val accFace: String = "acc_none",
    val accNeck: String = "acc_none",
    val accAura: String = "acc_none",
    val ambiance: String = "amb_none",
    val theme: String = "theme_violet",
    val soundsOn: Boolean = true,
    val notifOn: Boolean = true,
    val musicOn: Boolean = true,
    val voiceOn: Boolean = false,
    val animationsOn: Boolean = true,
    val lastSeen: Long = 0L,
    val lastGift: Long = 0L,
    val totalInteractions: Int = 0,
    val interactions: List<Interaction> = emptyList(),
    val activityId: String? = null,
    val activityStart: Long = 0L,
    val bestStars: Int = 0,
    val bestMemory: Int = 0,
    val bestFireflies: Int = 0,
    val bestBubbles: Int = 0,
    val bestHide: Int = 0,
    val memories: Set<String> = emptySet(),
    val questDay: String = "",
    val questProg: Map<String, Int> = emptyMap(),
    val questDone: Set<String> = emptySet(),   // quêtes réclamées (et "bonus" pour le coffre)
    val streak: Int = 0,
    val streakDay: String = "",
    // Événement en cours : identifiant, lucioles récoltées, récompenses prises, plafond du jour
    val evId: String = "",
    val evCount: Int = 0,
    val evClaimed: Set<String> = emptySet(),
    val evDayKey: String = "",
    val evDayGain: Int = 0,
)

// ---------------------------------------------------------------------------
// Règles du jeu (fonctions pures)
// ---------------------------------------------------------------------------

fun GameState.worn(slot: String): String = when (slot) {
    "head" -> accessory
    "face" -> accFace
    "neck" -> accNeck
    "aura" -> accAura
    else -> "acc_none"
}

fun GameState.withWorn(slot: String, id: String): GameState = when (slot) {
    "head" -> copy(accessory = id)
    "face" -> copy(accFace = id)
    "neck" -> copy(accNeck = id)
    "aura" -> copy(accAura = id)
    else -> this
}

fun GameState.isEquipped(item: Item): Boolean = when (item.kind) {
    ItemKind.ACCESSORY -> worn(item.slot) == item.id
    ItemKind.THEME -> theme == item.id
    ItemKind.AMBIANCE -> ambiance == item.id
    else -> false
}

// ---------------------------------------------------------------------------
// Quêtes quotidiennes
// ---------------------------------------------------------------------------

class QuestDef(val id: String, val kind: String, val goal: Int, val title: String, val coins: Int)

object Quests {
    val pool = listOf(
        QuestDef("q_pet5", "PET", 5, "Caresse Nyxie 5 fois", 15),
        QuestDef("q_pet10", "PET", 10, "Caresse Nyxie 10 fois", 25),
        QuestDef("q_eat2", "EAT", 2, "Donne-lui 2 repas", 15),
        QuestDef("q_eat3", "EAT", 3, "Donne-lui 3 repas", 25),
        QuestDef("q_play2", "PLAY", 2, "Joue 2 fois avec elle", 15),
        QuestDef("q_play4", "PLAY", 4, "Joue 4 fois avec elle", 30),
        QuestDef("q_talk3", "TALK", 3, "Parle-lui 3 fois", 15),
        QuestDef("q_care2", "CARE", 2, "Prends soin d'elle 2 fois (bain, brossage)", 20),
        QuestDef("q_act1", "ACT", 1, "Termine une activité", 20),
        QuestDef("q_gift", "GIFT", 1, "Récupère ton cadeau", 15),
        QuestDef("q_buy", "BUY", 1, "Achète un objet à la boutique", 20),
    )
    val byId: Map<String, QuestDef> = pool.associateBy { it.id }

    /** Trois quêtes de types différents, les mêmes pour toute la journée. */
    fun forDay(day: String): List<QuestDef> {
        val rnd = Random(day.hashCode())
        val out = ArrayList<QuestDef>()
        for (q in pool.shuffled(rnd)) {
            if (out.none { it.kind == q.kind }) out.add(q)
            if (out.size == 3) break
        }
        return out
    }
}

fun todayStr(): String = java.time.LocalDate.now().toString()
fun yesterdayStr(): String = java.time.LocalDate.now().minusDays(1).toString()

fun GameState.withQuestDay(): GameState {
    val d = todayStr()
    return if (questDay == d) this else copy(questDay = d, questProg = emptyMap(), questDone = emptySet())
}

fun GameState.questTick(kind: String): GameState {
    val s = withQuestDay()
    var prog = s.questProg
    for (q in Quests.forDay(s.questDay)) {
        if (q.kind == kind) prog = prog + (q.id to min(q.goal, (prog[q.id] ?: 0) + 1))
    }
    return s.copy(questProg = prog)
}

/** Série en cours (0 si elle est interrompue). */
val GameState.activeStreak: Int
    get() = if (streakDay == todayStr() || streakDay == yesterdayStr()) streak else 0

const val MAX_LEVEL = 50

fun xpNeeded(level: Int): Int = min(50 * level, 600)

val GameState.mood: Float
    get() = (hunger * 0.35f + energy * 0.25f + affection * 0.40f).coerceIn(0f, 1f)

val GameState.moodLabel: String
    get() = when {
        sleeping -> "Endormie"
        hunger < 0.2f -> "Affamée"
        energy < 0.15f -> "Épuisée"
        affection < 0.2f -> "Triste"
        mood > 0.8f -> "Heureuse"
        mood > 0.6f -> "Contente"
        mood > 0.4f -> "Pensive"
        else -> "Boudeuse"
    }

fun stageFor(level: Int): String = when {
    level >= 50 -> "Légende de la nuit"
    level >= 40 -> "Dragon cosmique"
    level >= 30 -> "Reine des étoiles"
    level >= 20 -> "Gardienne lunaire"
    level >= 10 -> "Nyxie étoilée"
    level >= 5 -> "Nyxie rêveuse"
    else -> "Petite Nyxie"
}

private fun Float.c01(): Float = this.coerceIn(0f, 1f)

fun GameState.bump(h: Float = 0f, e: Float = 0f, a: Float = 0f): GameState =
    copy(hunger = (hunger + h).c01(), energy = (energy + e).c01(), affection = (affection + a).c01())

fun GameState.gainXp(amount: Int): GameState {
    var lvl = level
    var cur = xp + max(0, amount)
    var gems = this.gems
    while (lvl < MAX_LEVEL && cur >= xpNeeded(lvl)) {
        cur -= xpNeeded(lvl)
        lvl++
        gems += 1
    }
    if (lvl >= MAX_LEVEL) cur = min(cur, xpNeeded(MAX_LEVEL) - 1)
    return copy(level = lvl, xp = cur, gems = gems)
}

fun GameState.log(kind: String, at: Long): GameState =
    questTick(kind).eventTick().copy(
        interactions = (listOf(Interaction(kind, at)) + interactions).take(12),
        totalInteractions = totalInteractions + 1,
    )

fun GameState.unlock(id: String): GameState =
    if (id in memories) this else copy(memories = memories + id)

fun GameState.addItem(id: String, n: Int = 1): GameState =
    copy(inventory = inventory + (id to ((inventory[id] ?: 0) + n)))

fun GameState.takeItem(id: String): GameState {
    val left = (inventory[id] ?: 0) - 1
    return copy(inventory = if (left <= 0) inventory - id else inventory + (id to left))
}

fun decay(s: GameState, dtMs: Long): GameState {
    if (dtMs <= 0L) return s
    val h = min(dtMs, 12L * 3_600_000L) / 3_600_000f
    return if (s.sleeping) {
        s.copy(
            hunger = (s.hunger - 0.05f * h).c01(),
            energy = (s.energy + 0.50f * h).c01(),
            affection = (s.affection - 0.02f * h).c01(),
        )
    } else {
        s.copy(
            hunger = (s.hunger - 0.15f * h).c01(),
            energy = (s.energy - 0.10f * h).c01(),
            affection = (s.affection - 0.09f * h).c01(),
        )
    }
}

const val GIFT_COOLDOWN_MS = 8L * 3_600_000L

fun ago(now: Long, at: Long): String {
    val m = ((now - at) / 60_000L).coerceAtLeast(0L)
    return when {
        m < 1L -> "à l'instant"
        m < 60L -> "il y a $m min"
        m < 1440L -> "il y a ${m / 60L} h"
        else -> "il y a ${m / 1440L} j"
    }
}

fun interactionText(kind: String): String = when (kind) {
    "PET" -> "Tu l'as caressée"
    "EAT" -> "Elle a mangé"
    "PLAY" -> "Vous avez joué"
    "TALK" -> "Vous avez discuté"
    "GIFT" -> "Cadeau ouvert"
    "ACT" -> "Activité terminée"
    "CARE" -> "Tu as pris soin d'elle"
    "SLEEP" -> "Elle a fait un somme"
    else -> "Moment partagé"
}

fun remainingText(ms: Long): String {
    val totalMin = (ms / 60_000L).coerceAtLeast(0L)
    val h = totalMin / 60L
    val m = totalMin % 60L
    return if (h > 0L) "${h} h ${m} min" else "${max(1L, m)} min"
}

// ---------------------------------------------------------------------------
// Dialogue : tout est local, aucune IA distante
// ---------------------------------------------------------------------------

private fun <T> pick(list: List<T>): T = list[Random.nextInt(list.size)]

fun petLines(s: GameState) = listOf(
    "Hihii ! J'adore quand tu me caresses ! ♥",
    "Encore un peu, c'est tellement doux…",
    "Ça chatouille, mais j'aime ça !",
    "Mmmh… je me sens toute légère.",
    "Tu es la meilleure personne du monde !",
)

fun eatLines(item: Item) = listOf(
    "Miam ! ${item.name}, c'est délicieux !",
    "Nom nom nom… merci !",
    "Mmh, j'en reprendrais bien un autre !",
)

fun playLines() = listOf(
    "On joue ! On joue ! Attrape-moi !",
    "Youhou ! C'est trop amusant !",
    "Encore une partie, s'il te plaît !",
)

fun talkLines(s: GameState): List<String> = when {
    s.hunger < 0.3f -> listOf("Mon ventre gargouille un peu…", "Tu aurais quelque chose de bon à manger ?")
    s.energy < 0.25f -> listOf("Je suis un peu fatiguée…", "Un petit dodo me ferait du bien.")
    s.affection < 0.3f -> listOf("Tu m'as manqué…", "Un câlin, s'il te plaît ?")
    else -> listOf(
        "Nyxie est heureuse de te voir !",
        "Regarde, la lune est magnifique ce soir.",
        "Tu sais, j'aime beaucoup nos petits moments.",
        "Raconte-moi ta journée !",
        "Je me demande ce qu'il y a au-delà des étoiles…",
    )
}

fun idleLines(s: GameState): List<String> = when {
    s.hunger < 0.25f -> listOf("Mon ventre fait des bruits bizarres…")
    s.energy < 0.2f -> listOf("*bâille* Je tombe de sommeil…")
    s.affection < 0.25f -> listOf("Tu es là ? J'aimerais un câlin…")
    else -> listOf("Hihi, je suis bien avec toi.", "Il fait doux ici…", "Tu veux jouer un peu ?")
}

fun replyTo(msg: String, s: GameState): String {
    val m = msg.lowercase()
    fun has(vararg k: String) = k.any { m.contains(it) }
    return when {
        has("bonjour", "salut", "coucou", "hello", "bonsoir") ->
            pick(listOf("Coucou ! Ravie de te retrouver !", "Salut toi ! ♥", "Bonjour ! Tu m'as manqué !"))
        has("comment vas", "ça va", "ca va", "la forme") ->
            "Je me sens ${s.moodLabel.lowercase()} aujourd'hui. Et toi ?"
        has("faim", "manger", "mange", "miam") ->
            if (s.hunger < 0.4f) "Oh oui, j'ai un petit creux. Tu me donnes quelque chose ?"
            else "Non, je suis rassasiée, merci de demander ♥"
        has("fatigu", "dors", "dodo", "sommeil", "nuit") ->
            if (s.energy < 0.4f) "Oui, je tombe de fatigue… Mettons-nous au calme."
            else "Je suis en pleine forme, mais je dormirai avec toi si tu veux !"
        has("aime", "adore", "câlin", "calin", "bisou") ->
            pick(listOf("Moi aussi je t'adore ! ♥", "Tu me rends tellement heureuse…", "Câlin géant ! ♥"))
        has("jou", "jeu") ->
            if (s.energy < 0.2f) "J'aimerais bien, mais je suis épuisée…" else "Oh oui ! Allons dans l'onglet Jeux !"
        has("nom", "appelle") -> "Je m'appelle ${s.name}, ton compagnon magique !"
        has("merci") -> "Avec plaisir ! ♥"
        has("lune", "étoile", "etoile", "ciel") ->
            "La lune me donne de la force. Tu la vois, par la fenêtre ?"
        has("triste", "pas bien", "mal ", "déprim") ->
            "Je suis là, tout contre toi. Veux-tu un câlin ?"
        has("blague") -> "Pourquoi les dragons aiment la nuit ? Parce que les étoiles sont leurs braises ! Hihi !"
        m.trim().endsWith("?") ->
            pick(listOf("Hmm, bonne question… Je ne sais pas trop !", "Je réfléchis… Et toi, qu'en penses-tu ?", "Oh, curieux ! Dis-m'en plus."))
        else -> pick(talkLines(s))
    }
}

// ---------------------------------------------------------------------------
// Sauvegarde locale
// ---------------------------------------------------------------------------

object Store {
    private const val FILE = "nyxie_save_v2"

    fun load(c: Context): GameState {
        val sp = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        if (!sp.contains("name")) return GameState()
        val d = GameState()
        fun mapOfStr(raw: String?): Map<String, Int> =
            (raw ?: "").split(",").mapNotNull {
                val p = it.split(":")
                if (p.size == 2) p[0] to (p[1].toIntOrNull() ?: 0) else null
            }.filter { it.second > 0 }.toMap()
        fun setOfStr(raw: String?): Set<String> =
            (raw ?: "").split(",").filter { it.isNotBlank() }.toSet()
        val inter = (sp.getString("interactions", "") ?: "").split(";").mapNotNull {
            val p = it.split("|")
            if (p.size == 2) Interaction(p[0], p[1].toLongOrNull() ?: 0L) else null
        }
        return GameState(
            name = sp.getString("name", d.name) ?: d.name,
            level = sp.getInt("level", d.level),
            xp = sp.getInt("xp", d.xp),
            coins = sp.getInt("coins", d.coins),
            gems = sp.getInt("gems", d.gems),
            hunger = sp.getFloat("hunger", d.hunger),
            energy = sp.getFloat("energy", d.energy),
            affection = sp.getFloat("affection", d.affection),
            sleeping = sp.getBoolean("sleeping", false),
            inventory = mapOfStr(sp.getString("inventory", null)),
            owned = setOfStr(sp.getString("owned", null)) + setOf("acc_none", "theme_violet"),
            accessory = sp.getString("accessory", d.accessory) ?: d.accessory,
            theme = sp.getString("theme", d.theme) ?: d.theme,
            accFace = sp.getString("accFace", d.accFace) ?: d.accFace,
            accNeck = sp.getString("accNeck", d.accNeck) ?: d.accNeck,
            accAura = sp.getString("accAura", d.accAura) ?: d.accAura,
            ambiance = sp.getString("ambiance", d.ambiance) ?: d.ambiance,
            soundsOn = sp.getBoolean("soundsOn", true),
            notifOn = sp.getBoolean("notifOn", true),
            musicOn = sp.getBoolean("musicOn", true),
            voiceOn = sp.getBoolean("voiceOn", false),
            animationsOn = sp.getBoolean("animationsOn", true),
            lastSeen = sp.getLong("lastSeen", 0L),
            lastGift = sp.getLong("lastGift", 0L),
            totalInteractions = sp.getInt("totalInteractions", 0),
            interactions = inter,
            activityId = sp.getString("activityId", null)?.takeIf { it.isNotEmpty() },
            activityStart = sp.getLong("activityStart", 0L),
            bestStars = sp.getInt("bestStars", 0),
            bestMemory = sp.getInt("bestMemory", 0),
            bestFireflies = sp.getInt("bestFireflies", 0),
            bestBubbles = sp.getInt("bestBubbles", 0),
            bestHide = sp.getInt("bestHide", 0),
            memories = setOfStr(sp.getString("memories", null)),
            questDay = sp.getString("questDay", "") ?: "",
            questProg = mapOfStr(sp.getString("questProg", null)),
            questDone = setOfStr(sp.getString("questDone", null)),
            streak = sp.getInt("streak", 0),
            streakDay = sp.getString("streakDay", "") ?: "",
            evId = sp.getString("evId", "") ?: "",
            evCount = sp.getInt("evCount", 0),
            evClaimed = setOfStr(sp.getString("evClaimed", null)),
            evDayKey = sp.getString("evDayKey", "") ?: "",
            evDayGain = sp.getInt("evDayGain", 0),
        )
    }

    fun save(c: Context, s: GameState) {
        c.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putString("name", s.name)
            .putInt("level", s.level)
            .putInt("xp", s.xp)
            .putInt("coins", s.coins)
            .putInt("gems", s.gems)
            .putFloat("hunger", s.hunger)
            .putFloat("energy", s.energy)
            .putFloat("affection", s.affection)
            .putBoolean("sleeping", s.sleeping)
            .putString("inventory", s.inventory.entries.joinToString(",") { "${it.key}:${it.value}" })
            .putString("owned", s.owned.joinToString(","))
            .putString("accessory", s.accessory)
            .putString("theme", s.theme)
            .putString("accFace", s.accFace)
            .putString("accNeck", s.accNeck)
            .putString("accAura", s.accAura)
            .putString("ambiance", s.ambiance)
            .putBoolean("soundsOn", s.soundsOn)
            .putBoolean("notifOn", s.notifOn)
            .putBoolean("musicOn", s.musicOn)
            .putBoolean("voiceOn", s.voiceOn)
            .putBoolean("animationsOn", s.animationsOn)
            .putLong("lastSeen", s.lastSeen)
            .putLong("lastGift", s.lastGift)
            .putInt("totalInteractions", s.totalInteractions)
            .putString("interactions", s.interactions.joinToString(";") { "${it.kind}|${it.at}" })
            .putString("activityId", s.activityId ?: "")
            .putLong("activityStart", s.activityStart)
            .putInt("bestStars", s.bestStars)
            .putInt("bestMemory", s.bestMemory)
            .putInt("bestFireflies", s.bestFireflies)
            .putInt("bestBubbles", s.bestBubbles)
            .putInt("bestHide", s.bestHide)
            .putString("memories", s.memories.joinToString(","))
            .putString("questDay", s.questDay)
            .putString("questProg", s.questProg.entries.joinToString(",") { "${it.key}:${it.value}" })
            .putString("questDone", s.questDone.joinToString(","))
            .putInt("streak", s.streak)
            .putString("streakDay", s.streakDay)
            .putString("evId", s.evId)
            .putInt("evCount", s.evCount)
            .putString("evClaimed", s.evClaimed.joinToString(","))
            .putString("evDayKey", s.evDayKey)
            .putInt("evDayGain", s.evDayGain)
            .apply()
    }

    fun clear(c: Context) {
        c.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().clear().apply()
    }
}
