package com.lumina.nyxie

import androidx.compose.foundation.Canvas
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.height
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.ui.unit.Dp
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.random.Random

// ---------------------------------------------------------------------------
// Jeu 3 : Attrape-lucioles
// Les lucioles se promènent en clignotant : on ne peut les attraper que lorsqu'elles brillent.
// ---------------------------------------------------------------------------

private class Firefly(
    val id: Int, var x: Float, var y: Float, var vx: Float, var vy: Float,
    val phase: Float, val golden: Boolean, var life: Float,
) {
    fun lit(t: Float): Float = (0.5f + 0.5f * sin(t * 2.6f + phase)).let { it * it }
}

@Composable
fun FireflyGame(accent: Color, onFinish: (Int) -> Unit, onQuit: () -> Unit) {
    val flies = remember { mutableStateListOf<Firefly>() }
    var clock by remember { mutableFloatStateOf(0f) }
    var timeLeft by remember { mutableFloatStateOf(25f) }
    var score by remember { mutableIntStateOf(0) }
    var over by remember { mutableStateOf(false) }
    var missed by remember { mutableIntStateOf(0) }

    LaunchedEffect(Unit) {
        var last = 0L
        var spawn = 0f
        var nextId = 0
        while (timeLeft > 0f) {
            withFrameNanos { nanos ->
                if (last == 0L) last = nanos
                val dt = ((nanos - last) / 1_000_000_000f).coerceIn(0f, 0.05f)
                last = nanos
                timeLeft -= dt
                clock += dt
                spawn -= dt
                val prog = ((25f - timeLeft) / 25f).coerceIn(0f, 1f)
                val cap = 4 + (prog * 6f).toInt()
                if (spawn <= 0f && flies.size < cap) {
                    spawn = 0.5f + Random.nextFloat() * 0.5f
                    val fromLeft = Random.nextBoolean()
                    flies.add(
                        Firefly(
                            nextId++, if (fromLeft) -0.04f else 1.04f, 0.15f + Random.nextFloat() * 0.7f,
                            (if (fromLeft) 1f else -1f) * (0.07f + Random.nextFloat() * 0.07f + 0.06f * prog),
                            (Random.nextFloat() - 0.5f) * 0.06f,
                            Random.nextFloat() * 6.28f, Random.nextInt(7) == 0, 0f,
                        ),
                    )
                }
                var i = 0
                while (i < flies.size) {
                    val f = flies[i]
                    f.life += dt
                    f.x += f.vx * dt
                    f.y += (f.vy + 0.05f * sin(f.life * 1.7f + f.phase)) * dt
                    if (f.x < -0.1f || f.x > 1.1f || f.y < -0.1f || f.y > 1.1f) flies.removeAt(i) else i++
                }
            }
        }
        over = true
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF050B1E), Color(0xFF12304A), Color(0xFF0E3B2C))), RoundedCornerShape(16.dp)),
    ) {
        Canvas(
            Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures { off ->
                        if (over) return@detectTapGestures
                        val w = size.width.toFloat()
                        val h = size.height.toFloat()
                        var best = -1
                        var bestD = Float.MAX_VALUE
                        for (i in flies.indices) {
                            val f = flies[i]
                            val d = hypot(off.x - f.x * w, off.y - f.y * h)
                            if (d < bestD) { bestD = d; best = i }
                        }
                        if (best >= 0 && bestD < 70f) {
                            val f = flies[best]
                            if (f.lit(clock) > 0.35f) {
                                score += if (f.golden) 4 else 1
                                flies.removeAt(best)
                            } else missed++
                        } else missed++
                    }
                },
        ) {
            // herbes
            for (k in 0 until 14) {
                val gx = size.width * (k + 0.5f) / 14f
                drawLine(Color(0xFF1B6B46).copy(alpha = 0.55f), Offset(gx, size.height), Offset(gx + 8f * sin(clock + k), size.height * 0.88f), strokeWidth = 5f)
            }
            for (f in flies) {
                val c = Offset(f.x * size.width, f.y * size.height)
                val l = f.lit(clock)
                val col = if (f.golden) Color(0xFFFFC857) else Color(0xFFE4FF8A)
                drawCircle(col.copy(alpha = 0.18f * l), 40f, c)
                drawCircle(col.copy(alpha = 0.35f * l), 22f, c)
                drawCircle(col.copy(alpha = 0.25f + 0.75f * l), if (f.golden) 9f else 7f, c)
                if (l > 0.35f) drawCircle(Color.White.copy(alpha = 0.6f), 11f, c, style = Stroke(width = 1.5f))
            }
        }
        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("🪲 $score", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text("${timeLeft.coerceAtLeast(0f).toInt()} s", color = Color.White, fontSize = 18.sp)
            Text("Quitter", color = Color(0xFFB9A8DD), fontSize = 14.sp, modifier = Modifier.clickable { onQuit() })
        }
        if (over) {
            ResultOverlay("Terminé !", "Tu as attrapé $score points de lucioles.", accent) { onFinish(score) }
        }
    }
}

// ---------------------------------------------------------------------------
// Jeu 4 : Bulles magiques
// Des bulles de 3 couleurs montent : enchaîne la même couleur pour faire grimper le combo.
// ---------------------------------------------------------------------------

private class Bubble(val id: Int, val x: Float, var y: Float, val v: Float, val color: Int, val r: Float)

private val BUBBLE_COLORS = listOf(Color(0xFF7FD6FF), Color(0xFFFF8FD0), Color(0xFFB7F07A))

@Composable
fun BubbleGame(accent: Color, onFinish: (Int) -> Unit, onQuit: () -> Unit) {
    val bubbles = remember { mutableStateListOf<Bubble>() }
    var clock by remember { mutableFloatStateOf(0f) }
    var timeLeft by remember { mutableFloatStateOf(25f) }
    var score by remember { mutableIntStateOf(0) }
    var combo by remember { mutableIntStateOf(0) }
    var lastColor by remember { mutableIntStateOf(-1) }
    var over by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        var last = 0L
        var spawn = 0f
        var nextId = 0
        while (timeLeft > 0f) {
            withFrameNanos { nanos ->
                if (last == 0L) last = nanos
                val dt = ((nanos - last) / 1_000_000_000f).coerceIn(0f, 0.05f)
                last = nanos
                timeLeft -= dt
                clock += dt
                spawn -= dt
                val prog = ((25f - timeLeft) / 25f).coerceIn(0f, 1f)
                val cap = 5 + (prog * 6f).toInt()
                if (spawn <= 0f && bubbles.size < cap) {
                    spawn = (0.45f + Random.nextFloat() * 0.35f) * (1f - 0.4f * prog)
                    bubbles.add(
                        Bubble(
                            nextId++, 0.08f + Random.nextFloat() * 0.84f, 1.08f,
                            0.16f + Random.nextFloat() * 0.14f + 0.08f * prog,
                            Random.nextInt(3), 30f + Random.nextFloat() * 22f,
                        ),
                    )
                }
                var i = 0
                while (i < bubbles.size) {
                    val b = bubbles[i]
                    b.y -= b.v * dt
                    if (b.y < -0.1f) {
                        bubbles.removeAt(i)
                        combo = 0
                        lastColor = -1
                    } else i++
                }
            }
        }
        over = true
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF1B0F4A), Color(0xFF3A2A8A), Color(0xFF5A3AA0))), RoundedCornerShape(16.dp)),
    ) {
        Canvas(
            Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures { off ->
                        if (over) return@detectTapGestures
                        val w = size.width.toFloat()
                        val h = size.height.toFloat()
                        var best = -1
                        var bestD = Float.MAX_VALUE
                        for (i in bubbles.indices) {
                            val b = bubbles[i]
                            val d = hypot(off.x - b.x * w, off.y - b.y * h) - b.r
                            if (d < bestD) { bestD = d; best = i }
                        }
                        if (best >= 0 && bestD < 18f) {
                            val b = bubbles[best]
                            combo = if (b.color == lastColor) combo + 1 else 1
                            lastColor = b.color
                            score += minOf(combo, 5)
                            bubbles.removeAt(best)
                        } else {
                            combo = 0
                            lastColor = -1
                        }
                    }
                },
        ) {
            for (b in bubbles) {
                val c = Offset(b.x * size.width + 8f * sin(clock * 2f + b.id), b.y * size.height)
                val col = BUBBLE_COLORS[b.color]
                drawCircle(col.copy(alpha = 0.28f), b.r, c)
                drawCircle(Color.White.copy(alpha = 0.8f), b.r, c, style = Stroke(width = 2.5f))
                drawCircle(col.copy(alpha = 0.95f), b.r, c, style = Stroke(width = 5f))
                drawCircle(Color.White.copy(alpha = 0.85f), b.r * 0.2f, Offset(c.x - b.r * 0.38f, c.y - b.r * 0.38f))
            }
        }
        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("🫧 $score", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text(if (combo >= 2) "Combo x${minOf(combo, 5)} !" else "${timeLeft.coerceAtLeast(0f).toInt()} s",
                color = if (combo >= 2) Color(0xFFFFE27A) else Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text("Quitter", color = Color(0xFFB9A8DD), fontSize = 14.sp, modifier = Modifier.clickable { onQuit() })
        }
        if (over) {
            ResultOverlay("Terminé !", "Tu as éclaté $score points de bulles.", accent) { onFinish(score) }
        }
    }
}

// ---------------------------------------------------------------------------
// Jeu 5 : Cache-cache
// Nyxie se cache sous un champignon, les champignons se mélangent : retrouve-la !
// ---------------------------------------------------------------------------

@Composable
fun HideGame(accent: Color, onFinish: (Int) -> Unit, onQuit: () -> Unit) {
    val rounds = 8
    var round by remember { mutableIntStateOf(0) }
    var score by remember { mutableIntStateOf(0) }
    var phase by remember { mutableIntStateOf(0) }      // 0 : montre  1 : mélange  2 : choisis  3 : résultat
    var target by remember { mutableIntStateOf(0) }
    var picked by remember { mutableIntStateOf(-1) }
    var over by remember { mutableStateOf(false) }
    val n = (3 + round / 2).coerceAtMost(6)
    val slots = remember { mutableStateListOf(0, 1, 2, 3, 4, 5) }
    val swapMs = (420 - round * 30).coerceAtLeast(190)

    LaunchedEffect(round) {
        if (round >= rounds) {
            over = true
            return@LaunchedEffect
        }
        picked = -1
        for (i in 0 until 6) slots[i] = i
        target = Random.nextInt(n)
        phase = 0
        kotlinx.coroutines.delay(1000)
        phase = 1
        val swaps = 3 + round
        repeat(swaps) {
            val a = Random.nextInt(n)
            var b = Random.nextInt(n)
            if (b == a) b = (a + 1) % n
            val t = slots[a]; slots[a] = slots[b]; slots[b] = t
            kotlinx.coroutines.delay(swapMs.toLong() + 90L)
        }
        phase = 2
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF0E1F3A), Color(0xFF1C5A4A), Color(0xFF2B7A52))), RoundedCornerShape(16.dp)),
    ) {
        BoxWithConstraints(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
            val cupW: Dp = maxWidth / n
            val size = if (cupW < 92.dp) cupW else 92.dp
            for (id in 0 until n) {
                val x by animateDpAsState(cupW * slots[id] + (cupW - size) / 2, tween(swapMs), label = "x")
                val revealed = phase == 0 || phase == 3
                val lift by animateDpAsState(if (revealed && (id == target || phase == 3)) (-size * 0.45f) else 0.dp, tween(250), label = "lift")
                Box(
                    Modifier
                        .offset(x = x, y = maxHeight / 2 - size / 2)
                        .size(size)
                        .clickable(enabled = phase == 2) {
                            picked = id
                            if (id == target) score++
                            phase = 3
                        },
                    contentAlignment = Alignment.Center,
                ) {
                    if (id == target) {
                        // Nyxie rétrécit jusqu'à disparaître complètement quand elle est cachée,
                        // puis regrandit quand elle est révélée. Dessinée AVANT le champignon : il passe devant.
                        val shrink by androidx.compose.animation.core.animateFloatAsState(
                            if (revealed) 1f else 0f, tween(320), label = "shrink",
                        )
                        if (shrink > 0.01f) {
                            NyxieAvatar(
                                Modifier
                                    .size(size * 0.7f)
                                    .align(Alignment.BottomCenter)
                                    .graphicsLayer { scaleX = shrink; scaleY = shrink; alpha = shrink }
                                    .clip(androidx.compose.foundation.shape.CircleShape),
                            )
                        }
                    }
                    Text("🍄", fontSize = (size.value * 0.62f).sp, modifier = Modifier.offset(y = lift))
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("🍄 $score / $rounds", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text(
                when (phase) { 0 -> "Regarde bien !"; 1 -> "Suis-la…"; 2 -> "Où est-elle ?"; else -> if (picked == target) "Trouvée !" else "Raté !" },
                color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
            )
            Text("Quitter", color = Color(0xFFB9A8DD), fontSize = 14.sp, modifier = Modifier.clickable { onQuit() })
        }
        if (phase == 3 && !over) {
            LaunchedEffect(round) {
                kotlinx.coroutines.delay(1100)
                round++
            }
        }
        if (over) {
            ResultOverlay("Terminé !", "Tu m'as trouvée $score fois sur $rounds.", accent) { onFinish(score) }
        }
    }
}
