package com.lumina.nyxie

import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Animations des jouets, dessinées dans les coordonnées de la scène (1672 × 941) pendant que Nyxie joue.
 * Chaque jouet a sa propre petite animation ; `u` = secondes depuis le début, `a` = fondu (0..1).
 */
const val TOY_FX_DUR = 3.2f

private fun hs(i: Int, k: Int): Float {
    val v = sin(i * 12.9898f + k * 78.233f) * 43758.547f
    return v - floor(v)
}

private fun fadeOf(u: Float): Float = (min(u / 0.3f, 1f) * min((TOY_FX_DUR - u) / 0.4f, 1f)).coerceIn(0f, 1f)

private fun DrawScope.glowBall(x: Float, y: Float, r: Float, c1: Color, c2: Color, a: Float) {
    drawCircle(
        Brush.radialGradient(listOf(c1.copy(alpha = 0.55f * a), Color.Transparent), center = Offset(x, y), radius = r * 2.6f),
        r * 2.6f, Offset(x, y),
    )
    drawCircle(
        Brush.radialGradient(
            listOf(Color.White.copy(alpha = a), c1.copy(alpha = a), c2.copy(alpha = a)),
            center = Offset(x - r * 0.3f, y - r * 0.3f), radius = r * 1.3f,
        ),
        r, Offset(x, y),
    )
}

private fun DrawScope.starShape(x: Float, y: Float, r: Float, c: Color) {
    val p = Path()
    for (i in 0 until 10) {
        val ang = -1.5708f + i * 0.62832f
        val rr = if (i % 2 == 0) r else r * 0.45f
        val px = x + cos(ang) * rr
        val py = y + sin(ang) * rr
        if (i == 0) p.moveTo(px, py) else p.lineTo(px, py)
    }
    p.close()
    drawPath(p, c)
}

private fun DrawScope.noteShape(x: Float, y: Float, c: Color) {
    rotate(-20f, Offset(x, y)) { drawOval(c, Offset(x - 11f, y - 8f), Size(22f, 16f)) }
    drawLine(c, Offset(x + 9f, y - 3f), Offset(x + 9f, y - 40f), strokeWidth = 3.4f, cap = StrokeCap.Round)
    drawLine(c, Offset(x + 9f, y - 40f), Offset(x + 24f, y - 28f), strokeWidth = 3.4f, cap = StrokeCap.Round)
}

private fun DrawScope.kite(kx: Float, ky: Float, ang: Float, u: Float, a: Float, rainbow: Boolean) {
    val string = Path()
    string.moveTo(900f, 690f)
    string.quadraticBezierTo(1010f, 560f, kx, ky + 70f)
    drawPath(string, Color(0xFFFFFFFF).copy(alpha = 0.7f * a), style = Stroke(width = 2.5f))
    rotate(ang, Offset(kx, ky)) {
        val body = Path()
        body.moveTo(kx, ky - 70f)
        body.lineTo(kx + 48f, ky)
        body.lineTo(kx, ky + 80f)
        body.lineTo(kx - 48f, ky)
        body.close()
        drawPath(body, (if (rainbow) Color(0xFFFFD36B) else Color(0xFFFF7A9C)).copy(alpha = a))
        val left = Path()
        left.moveTo(kx, ky - 70f); left.lineTo(kx - 48f, ky); left.lineTo(kx, ky + 80f); left.close()
        drawPath(left, (if (rainbow) Color(0xFF7FD6FF) else Color(0xFFFFB3C6)).copy(alpha = a))
        drawLine(Color.White.copy(alpha = 0.8f * a), Offset(kx, ky - 70f), Offset(kx, ky + 80f), strokeWidth = 2.5f)
        drawLine(Color.White.copy(alpha = 0.8f * a), Offset(kx - 48f, ky), Offset(kx + 48f, ky), strokeWidth = 2.5f)
        val cols = if (rainbow) {
            listOf(0xFFFF5A5A, 0xFFFFA03C, 0xFFFFE04A, 0xFF58D86A, 0xFF4CA8FF, 0xFFA070FF)
        } else {
            listOf(0xFFFFFFFF)
        }
        for ((idx, c) in cols.withIndex()) {
            val tail = Path()
            val off = (idx - cols.size / 2f) * 6f
            tail.moveTo(kx + off, ky + 80f)
            for (k in 1..8) {
                val yy = ky + 80f + k * 17f
                tail.lineTo(kx + off + sin(u * 5f + k * 0.9f) * 14f, yy)
            }
            drawPath(tail, Color(c).copy(alpha = 0.9f * a), style = Stroke(width = if (rainbow) 5f else 3f, cap = StrokeCap.Round))
        }
    }
}

internal fun DrawScope.drawToyFx(id: String, uRaw: Float, loop: Boolean) {
    val u = if (loop) uRaw % TOY_FX_DUR else uRaw
    if (u < 0f || u > TOY_FX_DUR) return
    val a = fadeOf(u)
    if (a <= 0.01f) return
    when (id) {
        "feather" -> {
            val x = 836f + sin(u * 2.6f) * 170f
            val y = 400f + cos(u * 1.7f) * 40f
            rotate(sin(u * 2.6f) * 28f, Offset(x, y)) {
                val quill = Path()
                quill.moveTo(x, y + 90f)
                quill.quadraticBezierTo(x + 14f, y, x, y - 90f)
                drawPath(quill, Color(0xFFFFF3C4).copy(alpha = a), style = Stroke(width = 5f, cap = StrokeCap.Round))
                for (k in 0..7) {
                    val yy = y + 70f - k * 20f
                    val l = 34f - abs(k - 3) * 3f
                    drawLine(Color(0xFFD7B6FF).copy(alpha = 0.9f * a), Offset(x + 3f, yy), Offset(x - l, yy - 18f), strokeWidth = 4f, cap = StrokeCap.Round)
                    drawLine(Color(0xFFD7B6FF).copy(alpha = 0.9f * a), Offset(x + 3f, yy), Offset(x + l, yy - 18f), strokeWidth = 4f, cap = StrokeCap.Round)
                }
            }
        }
        "ball" -> {
            glowBall(836f + sin(u * 2.2f) * 240f, 700f - abs(sin(u * 5f)) * 210f, 34f, Color(0xFFB77CFF), Color(0xFF6B2FD0), a)
        }
        "goldball" -> {
            for (k in 5 downTo 1) {
                val uu = u - k * 0.06f
                val tx = 836f + sin(uu * 2.6f) * 250f
                val ty = 700f - abs(sin(uu * 5.4f)) * 230f
                starShape(tx, ty, 10f, Color(0xFFFFE9A0).copy(alpha = (0.55f - k * 0.09f).coerceAtLeast(0f) * a))
            }
            glowBall(836f + sin(u * 2.6f) * 250f, 700f - abs(sin(u * 5.4f)) * 230f, 34f, Color(0xFFFFD34D), Color(0xFFB8761A), a)
        }
        "plush" -> {
            val px = 730f
            val py = 690f + sin(u * 4f) * 8f
            rotate(sin(u * 3f) * 8f, Offset(px, py)) {
                val fur = Color(0xFFE8C9A0).copy(alpha = a)
                val dark = Color(0xFFB88B5E).copy(alpha = a)
                drawCircle(fur, 24f, Offset(px - 46f, py - 54f))
                drawCircle(fur, 24f, Offset(px + 46f, py - 54f))
                drawCircle(dark, 12f, Offset(px - 46f, py - 54f))
                drawCircle(dark, 12f, Offset(px + 46f, py - 54f))
                drawCircle(fur, 66f, Offset(px, py))
                drawCircle(Color(0xFFF6E3C6).copy(alpha = a), 28f, Offset(px, py + 16f))
                drawOval(Color(0xFF4A2F55).copy(alpha = a), Offset(px - 8f, py + 5f), Size(16f, 11f))
                drawCircle(Color(0xFF4A2F55).copy(alpha = a), 6f, Offset(px - 24f, py - 14f))
                drawCircle(Color(0xFF4A2F55).copy(alpha = a), 6f, Offset(px + 24f, py - 14f))
                val moon = Path()
                moon.moveTo(px + 26f, py + 50f)
                moon.quadraticBezierTo(px + 56f, py + 54f, px + 54f, py + 20f)
                moon.quadraticBezierTo(px + 42f, py + 42f, px + 26f, py + 50f)
                drawPath(moon, Color(0xFFFFE08A).copy(alpha = a))
            }
        }
        "kite" -> kite(1130f + sin(u * 1.8f) * 70f, 250f + cos(u * 2.3f) * 40f, sin(u * 1.8f) * 15f, u, a, false)
        "rainbowkite" -> kite(1130f + sin(u * 2.1f) * 80f, 240f + cos(u * 2.6f) * 45f, sin(u * 2.1f) * 18f, u, a, true)
        "musicbox" -> {
            val bx = 700f
            val by = 735f
            drawRoundRect(Color(0xFF8A5A3A).copy(alpha = a), Offset(bx - 70f, by - 10f), Size(140f, 56f), CornerRadius(10f))
            drawRoundRect(Color(0xFFC89060).copy(alpha = a), Offset(bx - 70f, by - 10f), Size(140f, 14f), CornerRadius(8f))
            val lid = Path()
            lid.moveTo(bx - 70f, by - 10f); lid.lineTo(bx - 56f, by - 68f); lid.lineTo(bx + 56f, by - 68f); lid.lineTo(bx + 70f, by - 10f); lid.close()
            drawPath(lid, Color(0xFFA06C44).copy(alpha = a))
            val sx = abs(cos(u * 3f)) * 12f + 3f
            drawOval(Color(0xFFFFB3D9).copy(alpha = a), Offset(bx - sx, by - 46f), Size(sx * 2f, 28f))
            drawCircle(Color(0xFFFFE0C4).copy(alpha = a), 7f, Offset(bx, by - 54f))
            for (i in 0 until 5) {
                val ph = (u * 0.5f + hs(i, 31)) % 1f
                noteShape(bx + 20f + hs(i, 32) * 90f + sin(u * 2f + i) * 14f, by - 70f - ph * 220f,
                    (if (i % 2 == 0) Color(0xFFFFE08A) else Color(0xFFB6A4FF)).copy(alpha = a * (1f - ph)))
            }
        }
        "yarn" -> {
            val yx = 700f + sin(u * 1.7f) * 200f
            val yy = 722f
            val thread = Path()
            thread.moveTo(560f, 745f)
            for (k in 1..12) {
                val tx = 560f + (yx - 560f) * k / 12f
                thread.lineTo(tx, 745f - sin(k * 0.8f + u * 3f) * 7f)
            }
            drawPath(thread, Color(0xFFFF8FB8).copy(alpha = 0.9f * a), style = Stroke(width = 4f, cap = StrokeCap.Round))
            rotate(yx * 1.2f, Offset(yx, yy)) {
                drawCircle(Color(0xFFFF6FA0).copy(alpha = a), 38f, Offset(yx, yy))
                for (k in -2..2) {
                    drawArc(
                        Color(0xFFFFC2D8).copy(alpha = a), 200f + k * 10f, 140f, false,
                        Offset(yx - 38f + k * 4f, yy - 38f), Size(76f, 76f), style = Stroke(width = 3f),
                    )
                }
            }
        }
        "bubbles" -> {
            drawLine(Color(0xFFCFA8FF).copy(alpha = a), Offset(690f, 770f), Offset(700f, 710f), strokeWidth = 5f, cap = StrokeCap.Round)
            drawCircle(Color(0xFFCFA8FF).copy(alpha = a), 15f, Offset(700f, 700f), style = Stroke(width = 4f))
            for (i in 0 until 9) {
                val ph = (u * 0.34f + hs(i, 41)) % 1f
                val x = 700f + ph * (160f + hs(i, 42) * 320f) + sin(u * 2f + i) * 18f
                val y = 700f - ph * (260f + hs(i, 43) * 160f)
                val r = 14f + hs(i, 44) * 24f
                val al = a * min(1f, ph * 6f) * (1f - ph * 0.5f)
                drawCircle(Color(0xFFBFE9FF).copy(alpha = 0.22f * al), r, Offset(x, y))
                drawCircle(Color(0xFFE6F6FF).copy(alpha = 0.9f * al), r, Offset(x, y), style = Stroke(width = 2.5f))
                drawCircle(Color.White.copy(alpha = 0.9f * al), r * 0.22f, Offset(x - r * 0.35f, y - r * 0.38f))
            }
        }
        "blocks" -> {
            val spots = listOf(Triple(970f, 740f, 0xFFFF6B6B), Triple(1038f, 740f, 0xFF4CA8FF), Triple(1106f, 740f, 0xFFFFD84A), Triple(1004f, 676f, 0xFF58D86A))
            for ((i, sp) in spots.withIndex()) {
                val t0 = 0.2f + i * 0.55f
                if (u < t0) continue
                val k = ((u - t0) / 0.35f).coerceIn(0f, 1f)
                val dy = -(1f - k) * (1f - k) * 320f
                val x = sp.first
                val y = sp.second + dy
                drawRoundRect(Color(sp.third).copy(alpha = a), Offset(x - 31f, y - 31f), Size(62f, 62f), CornerRadius(8f))
                drawRoundRect(Color.White.copy(alpha = 0.7f * a), Offset(x - 31f, y - 31f), Size(62f, 62f), CornerRadius(8f), style = Stroke(width = 3f))
                drawCircle(Color.White.copy(alpha = 0.85f * a), 9f, Offset(x, y))
            }
        }
        "puppet" -> {
            val px = 640f
            val py = 560f
            val sw = sin(u * 5f)
            drawLine(Color.White.copy(alpha = 0.6f * a), Offset(px, 250f), Offset(px, py - 40f), strokeWidth = 2f)
            drawLine(Color.White.copy(alpha = 0.6f * a), Offset(px - 40f + sw * 12f, 250f), Offset(px - 40f + sw * 30f, py + 10f), strokeWidth = 2f)
            drawLine(Color.White.copy(alpha = 0.6f * a), Offset(px + 40f - sw * 12f, 250f), Offset(px + 40f - sw * 30f, py + 10f), strokeWidth = 2f)
            drawCircle(Color(0xFFFFD9B0).copy(alpha = a), 26f, Offset(px, py - 60f))
            drawRoundRect(Color(0xFF7A5CFF).copy(alpha = a), Offset(px - 22f, py - 34f), Size(44f, 70f), CornerRadius(10f))
            drawLine(Color(0xFFFFB347).copy(alpha = a), Offset(px - 20f, py - 24f), Offset(px - 46f - sw * 14f, py + 10f), strokeWidth = 9f, cap = StrokeCap.Round)
            drawLine(Color(0xFFFFB347).copy(alpha = a), Offset(px + 20f, py - 24f), Offset(px + 46f - sw * 14f, py + 10f), strokeWidth = 9f, cap = StrokeCap.Round)
            drawLine(Color(0xFF4A2F8F).copy(alpha = a), Offset(px - 10f, py + 34f), Offset(px - 18f + sw * 16f, py + 90f), strokeWidth = 10f, cap = StrokeCap.Round)
            drawLine(Color(0xFF4A2F8F).copy(alpha = a), Offset(px + 10f, py + 34f), Offset(px + 18f - sw * 16f, py + 90f), strokeWidth = 10f, cap = StrokeCap.Round)
            drawCircle(Color(0xFF3A2250).copy(alpha = a), 3.5f, Offset(px - 9f, py - 64f))
            drawCircle(Color(0xFF3A2250).copy(alpha = a), 3.5f, Offset(px + 9f, py - 64f))
        }
        "drum" -> {
            val dx = 836f
            val dy = 735f
            drawRoundRect(Color(0xFFD84A4A).copy(alpha = a), Offset(dx - 84f, dy), Size(168f, 64f), CornerRadius(6f))
            drawOval(Color(0xFFF3E6D0).copy(alpha = a), Offset(dx - 84f, dy - 20f), Size(168f, 40f))
            for (k in 0..4) {
                drawLine(Color(0xFFFFE0A0).copy(alpha = 0.8f * a), Offset(dx - 70f + k * 35f, dy + 4f), Offset(dx - 52f + k * 35f, dy + 60f), strokeWidth = 3f)
            }
            val hit = sin(u * 12f)
            val l = max(0f, hit)
            val r = max(0f, -hit)
            drawLine(Color(0xFFF2D8A8).copy(alpha = a), Offset(dx - 120f, dy - 90f), Offset(dx - 40f, dy - 4f + (1f - l) * -30f), strokeWidth = 8f, cap = StrokeCap.Round)
            drawLine(Color(0xFFF2D8A8).copy(alpha = a), Offset(dx + 120f, dy - 90f), Offset(dx + 40f, dy - 4f + (1f - r) * -30f), strokeWidth = 8f, cap = StrokeCap.Round)
            val ring = (u * 6f) % 1f
            drawOval(Color.White.copy(alpha = 0.5f * a * (1f - ring)), Offset(dx - 84f - ring * 60f, dy - 20f - ring * 16f), Size(168f + ring * 120f, 40f + ring * 32f), style = Stroke(width = 3f))
        }
        "lantern" -> {
            val pivot = Offset(1060f, 120f)
            val ang = sin(u * 2f) * 12f
            drawCircle(
                Brush.radialGradient(listOf(Color(0xFFFFB347).copy(alpha = 0.35f * a), Color.Transparent), center = Offset(1060f, 330f), radius = 420f),
                420f, Offset(1060f, 330f),
            )
            rotate(ang, pivot) {
                drawLine(Color(0xFFFFE9B0).copy(alpha = a), pivot, Offset(1060f, 250f), strokeWidth = 3f)
                drawRoundRect(Color(0xFF8A4A1A).copy(alpha = a), Offset(1030f, 240f), Size(60f, 14f), CornerRadius(5f))
                drawRoundRect(Color(0xFFFFB347).copy(alpha = a), Offset(1034f, 254f), Size(52f, 80f), CornerRadius(14f))
                drawRoundRect(Color(0xFFFFE9A0).copy(alpha = 0.9f * a), Offset(1044f, 266f), Size(32f, 56f), CornerRadius(12f))
                drawRoundRect(Color(0xFF8A4A1A).copy(alpha = a), Offset(1030f, 332f), Size(60f, 14f), CornerRadius(5f))
            }
        }
        "telescope" -> {
            val tx = 1050f
            val ty = 650f
            drawLine(Color(0xFF6A4A2A).copy(alpha = a), Offset(tx, ty + 10f), Offset(tx - 50f, ty + 110f), strokeWidth = 8f, cap = StrokeCap.Round)
            drawLine(Color(0xFF6A4A2A).copy(alpha = a), Offset(tx, ty + 10f), Offset(tx + 50f, ty + 110f), strokeWidth = 8f, cap = StrokeCap.Round)
            val ang = -38f + sin(u * 1.6f) * 6f
            rotate(ang, Offset(tx, ty)) {
                drawRoundRect(Color(0xFFD9A441).copy(alpha = a), Offset(tx - 20f, ty - 26f), Size(150f, 52f), CornerRadius(8f))
                drawRoundRect(Color(0xFFB8801F).copy(alpha = a), Offset(tx + 90f, ty - 32f), Size(60f, 64f), CornerRadius(8f))
                drawRoundRect(Color(0xFFFFE9A0).copy(alpha = 0.7f * a), Offset(tx - 10f, ty - 20f), Size(120f, 8f), CornerRadius(4f))
            }
            for (i in 0 until 8) {
                val tw = 0.5f + 0.5f * sin(u * 4f + i * 1.7f)
                starShape(1000f + hs(i, 51) * 420f, 130f + hs(i, 52) * 300f, 8f + hs(i, 53) * 8f, Color(0xFFFFF3B0).copy(alpha = tw * a))
            }
        }
        "discoball" -> {
            val cx = 836f
            val cy = 130f
            drawLine(Color.White.copy(alpha = 0.7f * a), Offset(cx, 0f), Offset(cx, cy - 56f), strokeWidth = 3f)
            drawCircle(
                Brush.radialGradient(listOf(Color.White.copy(alpha = a), Color(0xFFB8B8D8).copy(alpha = a), Color(0xFF6A6A90).copy(alpha = a)), center = Offset(cx - 18f, cy - 18f), radius = 80f),
                58f, Offset(cx, cy),
            )
            for (k in -2..2) {
                drawLine(Color.White.copy(alpha = 0.35f * a), Offset(cx - 56f, cy + k * 20f), Offset(cx + 56f, cy + k * 20f), strokeWidth = 1.6f)
            }
            for (k in -2..2) {
                val xx = cx + k * 20f + sin(u * 3f) * 6f
                drawLine(Color.White.copy(alpha = 0.35f * a), Offset(xx, cy - 56f), Offset(xx, cy + 56f), strokeWidth = 1.6f)
            }
            val cols = listOf(0xFFFF5AA5, 0xFF5AD8FF, 0xFFFFE04A, 0xFF8A5CFF, 0xFF58D86A)
            for (i in 0 until 16) {
                val x = ((hs(i, 61) * 1672f) + u * (60f + hs(i, 62) * 90f)) % 1672f
                val y = 240f + hs(i, 63) * 560f + sin(u * 2f + i) * 30f
                drawCircle(Color(cols[i % cols.size]).copy(alpha = 0.32f * a), 30f, Offset(x, y))
            }
        }
        else -> {
            for (i in 0 until 8) {
                val ph = (u * 0.5f + hs(i, 71)) % 1f
                starShape(600f + hs(i, 72) * 500f, 700f - ph * 380f, 10f + hs(i, 73) * 10f, Color(0xFFFFEBB0).copy(alpha = a * (1f - ph)))
            }
        }
    }
}
