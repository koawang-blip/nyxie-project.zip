package com.lumina.nyxie

import kotlin.math.ceil

// ---------------------------------------------------------------------------
// Packs thématiques : lots d'objets de personnalisation à prix réduit (pièces ou gemmes).
// Le prix tient compte des objets déjà possédés : on ne paie jamais deux fois le même objet.
// ---------------------------------------------------------------------------

class Pack(
    val id: String,
    val name: String,
    val glyph: String,
    val desc: String,
    val itemIds: List<String>,
    val useGems: Boolean = false,
)

const val PACK_DISCOUNT = 0.70   // on paie 70 % de la valeur des objets manquants (30 % d'économie)

object Packs {
    val all = listOf(
        Pack("pk_forest", "Pack Forêt féerique", "🌿", "Champignons, feuilles et lucioles : un coin de forêt enchantée.",
            listOf("acc_leafcrown", "acc_mushroom", "acc_garland", "amb_fireflies", "theme_mint")),
        Pack("pk_cosmos", "Pack Cosmos", "🌌", "Étoiles, comètes et bleu profond pour voyager dans la nuit.",
            listOf("acc_headband", "acc_cheekstars", "acc_starcollar", "amb_meteor", "theme_indigo")),
        Pack("pk_sweet", "Pack Douceur", "🌸", "Rose, cœurs et pétales : tout en tendresse.",
            listOf("acc_bow", "acc_heartcheeks", "acc_ruffle", "amb_petals", "theme_rose", "aura_hearts")),
        Pack("pk_cat", "Pack Petit chat", "🐱", "Oreilles, moustaches et clochette pour un air espiègle.",
            listOf("acc_catears", "acc_whiskers", "acc_belltie", "acc_glitter", "theme_coral")),
        Pack("pk_adventure", "Pack Aventurière", "🧭", "Béret, bandana et monocle : prête pour l'exploration.",
            listOf("acc_beret", "acc_bandana", "acc_monocle", "acc_scarf", "amb_sunset", "theme_orange")),
        Pack("pk_winter", "Pack Hiver enchanté", "❄️", "Bonnet, écharpe et neige légère pour les soirées givrées.",
            listOf("acc_nightcap", "acc_scarf", "acc_party", "amb_snow", "theme_silver", "acc_pearls")),
        Pack("pk_chic", "Pack Élégance", "🎩", "Nœud papillon, perles et lunettes : le grand style.",
            listOf("acc_bowtie", "acc_pearls", "acc_glasses", "acc_sunglasses", "acc_monocle", "amb_twilight")),
        Pack("pk_royal", "Pack Royal (gemmes)", "👑", "Les cinq trésors rares en un seul lot, payé en gemmes.",
            listOf("acc_halo", "acc_crown", "acc_moontiara", "aura_stars", "aura_sparks"), useGems = true),
    )

    fun byId(id: String) = all.firstOrNull { it.id == id }

    fun items(p: Pack): List<Item> = p.itemIds.mapNotNull { Catalog.byId[it] }

    fun missing(p: Pack, s: GameState): List<Item> = items(p).filter { it.id !in s.owned }

    /** Valeur normale (au prix de la boutique) des objets manquants. */
    fun fullValue(p: Pack, s: GameState): Int = missing(p, s).sumOf { it.price }

    /** Prix du pack pour ce joueur. */
    fun price(p: Pack, s: GameState): Int = ceil(fullValue(p, s) * PACK_DISCOUNT).toInt()
}
