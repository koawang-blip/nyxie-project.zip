package com.lumina.nyxie

import android.app.Application
import android.content.Context
import android.media.AudioManager
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool
import android.media.ToneGenerator
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

data class ChatMsg(val fromUser: Boolean, val text: String, val at: Long)

class GameViewModel(app: Application) : AndroidViewModel(app) {

    var state by mutableStateOf(GameState())
        private set
    var screen by mutableStateOf(Screen.HOME)
    var introActive by mutableStateOf(false)
    var shooting by mutableStateOf(false)
    var photoFrame by mutableStateOf(0)
    var lastPhoto by mutableStateOf<android.net.Uri?>(null)
    var reaction by mutableStateOf(Reaction.NONE)
        private set
    var speech by mutableStateOf<String?>(null)
        private set
    var toast by mutableStateOf<String?>(null)
        private set
    var now by mutableStateOf(System.currentTimeMillis())
        private set
    val chat = mutableStateListOf<ChatMsg>()

    private var reactionJob: Job? = null
    private var speechJob: Job? = null
    private var toastJob: Job? = null
    private var dirty = false
    private var idleTicks = 0
    private var tone: ToneGenerator? = null
    private var pool: SoundPool? = null
    private var music: MediaPlayer? = null
    private val sfxIds = HashMap<String, Int>()
    private var lastPlayed = 0
    // Doivent être déclarés AVANT init (welcomeBack les utilise au démarrage)
    private val picker = LinePicker()
    var ticCmd by mutableStateOf<TicCmd?>(null)
        private set
    private var ticSeq = 0L

    // Guide de découverte (3 écrans) et voix : déclarés avant init
    var sleepTimerEnd by mutableStateOf(0L)
        private set
    private var sleepJob: kotlinx.coroutines.Job? = null
    private var fadeJob: kotlinx.coroutines.Job? = null
    var guideActive by mutableStateOf(false)
    private var tts: android.speech.tts.TextToSpeech? = null
    private var ttsReady = false

    // Sauvegarde / restauration : actions branchées par l'activité (sélecteur de fichiers)
    var exportAction: (() -> Unit)? = null
    var importAction: (() -> Unit)? = null

    fun backupJson(): String {
        Store.save(getApplication(), state)
        return Backup.export(getApplication())
    }

    /** Remplace la progression par celle du fichier ; renvoie true si la restauration a réussi. */
    fun restoreFrom(json: String): Boolean {
        val name = Backup.check(json)
        if (name == null || !Backup.restore(getApplication(), json)) {
            showToast("Ce fichier n'est pas une sauvegarde Nyxie valide.")
            return false
        }
        val loaded = Store.load(getApplication())
        state = loaded.copy(lastSeen = System.currentTimeMillis())
        Store.save(getApplication(), state)
        screen = Screen.HOME
        showToast("Sauvegarde restaurée : $name est de retour ! 💜")
        sfx("levelup")
        return true
    }

    init {
        val loaded = Store.load(getApplication())
        val t = System.currentTimeMillis()
        val first = loaded.lastSeen == 0L
        // Cinématique : uniquement au tout premier lancement (état « déjà vue » conservé à part de la sauvegarde).
        val fl = getApplication<Application>().getSharedPreferences("nyxie_flags", Context.MODE_PRIVATE)
        if (!fl.getBoolean("intro_seen", false)) {
            if (first && hasIntroVideo()) introActive = true else fl.edit().putBoolean("intro_seen", true).apply()
        }
        if (!fl.getBoolean("guide_seen", false)) {
            if (first) guideActive = true else fl.edit().putBoolean("guide_seen", true).apply()
        }
        var s = if (first) loaded else decay(loaded, t - loaded.lastSeen)
        s = s.copy(lastSeen = t)
        if (s.born == 0L) s = s.copy(born = t)
        state = s.withQuestDay()
        now = t
        if (first) {
            say("Coucou ! Moi c'est ${s.name}. Prends soin de moi, d'accord ?", 6000)
        } else {
            say(
                when {
                    s.sleeping -> "Zzz…"
                    s.hunger < 0.3f -> "Te revoilà ! J'ai un peu faim…"
                    else -> "Ravie de te retrouver !"
                },
                5000,
            )
        }
        if (!first && !s.sleeping) welcomeBack(t - loaded.lastSeen)
        if (!first) startEvents()
        if (!first) checkBirthday()
        viewModelScope.launch {
            var n = 0
            while (true) {
                delay(1000)
                tickOnce()
                n++
                if (n % 5 == 0) saveNow()
            }
        }
    }

    // -----------------------------------------------------------------------
    // Infrastructure
    // -----------------------------------------------------------------------

    private fun update(block: (GameState) -> GameState) {
        val before = state.withQuestDay()
        var after = block(before)
        if (after.level >= 5) after = after.unlock("lvl5")
        if (after.level >= 10) after = after.unlock("lvl10")
        val newly = Achievements.all.filter { it.id !in after.medals && it.test(after) }
        if (newly.isNotEmpty()) {
            after = after.copy(medals = after.medals + newly.map { it.id }, coins = after.coins + 15 * newly.size)
            showToast("🏅 Succès : ${newly.first().name}" + (if (newly.size > 1) " (+${newly.size - 1})" else "") + " ! +${15 * newly.size} pièces")
            sfx("sparkle", 0.8f)
        }
        state = after
        dirty = true
        for (q in Quests.forDay(after.questDay)) {
            if ((before.questProg[q.id] ?: 0) < q.goal && (after.questProg[q.id] ?: 0) >= q.goal) {
                showToast("Quête terminée : ${q.title} ✔ (va la réclamer dans « Quêtes »)")
                sfx("sparkle", 0.6f)
            }
        }
        if (after.level > before.level) {
            showToast("Niveau ${after.level} ! +${after.level - before.level} gemme")
            sayLine(Lines.LEVEL_UP, 4500, n = after.level, anim = false)
            sfx("levelup")
        }
    }

    /** Événements : récompenses de l'événement terminé rangées d'office, puis bonus de première visite. */
    private fun startEvents() {
        val st = state
        if (st.evId.isNotEmpty() && Events.active()?.id != st.evId) {
            val ended = Events.byId(st.evId)
            update { cur ->
                var n = cur
                ended?.rewards?.forEach { r -> if (r.id !in n.evClaimed && n.evCount >= r.at) n = n.withEventReward(r) }
                n.copy(evId = "", evCount = 0, evClaimed = emptySet(), evDayKey = "", evDayGain = 0)
            }
            showToast("${ended?.name ?: "L'événement"} est terminé : tes récompenses sont dans ton sac. À bientôt !")
        }
        val e = Events.active() ?: return
        val before = state.let { if (it.evId == e.id) it.evCount else 0 }
        update { it.eventDay() }
        val gained = state.evCount - before
        if (gained > 0) showToast("${e.glyph} ${e.name} : +$gained ${e.tokenName} ! Récompenses dans « Quêtes ».")
    }

    fun claimEventReward(rewardId: String) {
        val e = Events.active() ?: return
        val r = e.rewards.firstOrNull { it.id == rewardId } ?: return
        val s = state.eventDay()
        if (s.evId != e.id || r.id in s.evClaimed || s.evCount < r.at) return
        update { it.eventDay().withEventReward(r) }
        react(Reaction.GIFT, 3200)
        sayLine(Lines.EVENT_REWARD, 4500, anim = false)
        showToast("${r.glyph} Récompense : ${r.label}")
        sfx("sparkle")
    }

    /** Accueil après une absence : plus elle est longue, plus Nyxie est touchée (et gâtée). */
    private fun welcomeBack(awayMs: Long) {
        val min = awayMs / 60_000L
        when {
            min < 30 -> return
            min < 180 -> {
                update { it.bump(a = 0.03f).gainXp(2) }
                react(Reaction.PET, 2600)
                sayLine(Lines.REUNION_SHORT, 5000, anim = false)
                sfx("chirp")
            }
            min < 720 -> {
                val c = 15
                update { it.copy(coins = it.coins + c).bump(a = 0.05f).gainXp(5) }
                react(Reaction.GIFT, 3200)
                say(picker.pick(Lines.REUNION_LONG).text + " +$c pièces pour toi.", 6000)
                showToast("Bon retour ! +$c pièces")
                sfx("meow2")
            }
            else -> {
                val c = 40
                say("Hmpf… tu étais où ? J'ai attendu longtemps…", 3000)
                react(Reaction.NONE, 100)
                sfx("sad")
                viewModelScope.launch {
                    delay(3200)
                    update { it.copy(coins = it.coins + c, gems = it.gems + 1).bump(a = 0.08f).gainXp(10) }
                    react(Reaction.GIFT, 3500)
                    say("Mais je t'aime trop pour bouder ! +$c pièces et 1 gemme pour nous deux ♥", 6000)
                    showToast("Gros câlin de retrouvailles ! +$c pièces, +1 gemme")
                    sfx("sparkle")
                    sfx("meow", 0.9f)
                }
            }
        }
    }

    /** Réclame la récompense d'une quête terminée ; la première de la journée fait avancer la série. */
    fun claimQuest(id: String) {
        val q = Quests.byId[id] ?: return
        val s = state.withQuestDay()
        if (id in s.questDone || (s.questProg[id] ?: 0) < q.goal) return
        val today = todayStr()
        update {
            var n = it.copy(questDone = it.questDone + id, coins = it.coins + q.coins).gainXp(10)
            if (n.streakDay != today) {
                n = n.copy(streak = if (n.streakDay == yesterdayStr()) n.streak + 1 else 1, streakDay = today)
            }
            n
        }
        showToast("+${q.coins} pièces ! Série : ${state.activeStreak} jour(s) 🔥")
        sfx("coin")
        dropSticker(0.4f)
    }

    /** Coffre du jour : disponible quand les 3 quêtes sont réclamées ; plus la série est longue, plus il est généreux. */
    fun claimChest() {
        val s = state.withQuestDay()
        val quests = Quests.forDay(s.questDay)
        if ("bonus" in s.questDone || !quests.all { it.id in s.questDone }) return
        val gems = 1 + min(s.activeStreak / 3, 3)
        val coins = 30 + 5 * min(s.activeStreak, 10)
        update { it.copy(questDone = it.questDone + "bonus", coins = it.coins + coins, gems = it.gems + gems).gainXp(25) }
        react(Reaction.GIFT, 3200)
        say("Le coffre du jour ! +$coins pièces et +$gems gemme(s) !", 4500)
        showToast("Coffre du jour : +$coins pièces, +$gems gemme(s)")
        sfx("levelup", 0.8f)
        sfx("meow2", 0.8f)
        dropSticker(1f)
    }

    fun saveNow() {
        Store.save(getApplication(), state)
        dirty = false
    }

    override fun onCleared() {
        saveNow()
        tone?.release()
        try { tts?.shutdown() } catch (e: Exception) { }
        pool?.release()
        try { music?.release() } catch (e: Exception) { }
        super.onCleared()
    }

    /** Dit une phrase de la banque (sans répétition) et déclenche l'animation associée si elle est libre. */
    fun sayLine(bank: List<Line>, ms: Long = 4200, n: Int? = null, anim: Boolean = true) {
        val line = picker.pick(bank)
        val text = if (n != null) line.text.replace("{n}", n.toString()) else line.text
        say(text, ms)
        if (anim && line.tic != Tic.NONE && reaction == Reaction.NONE && !state.sleeping) {
            ticCmd = TicCmd(line.tic, ++ticSeq)
        }
    }

    fun say(text: String, ms: Long = 4200) {
        speech = text
        speak(text)
        speechJob?.cancel()
        speechJob = viewModelScope.launch {
            delay(ms)
            speech = null
        }
    }

    private fun react(r: Reaction, ms: Long) {
        reaction = r
        reactionJob?.cancel()
        reactionJob = viewModelScope.launch {
            delay(ms)
            reaction = Reaction.NONE
        }
    }

    fun showToast(text: String) {
        toast = text
        toastJob?.cancel()
        toastJob = viewModelScope.launch {
            delay(2600)
            toast = null
        }
    }

    /** Musique d'ambiance en boucle (res/raw/music_lullaby.wav), à faible volume. */
    fun musicStart(force: Boolean = false) {
        if ((!state.musicOn && !force) || introActive) return
        try {
            if (music == null) {
                music = MediaPlayer.create(getApplication<Application>(), R.raw.music_lullaby)?.apply {
                    isLooping = true
                    setVolume(0.28f, 0.28f)
                }
            }
            music?.start()
        } catch (e: Exception) {
        }
    }

    fun musicPause() {
        try {
            music?.pause()
        } catch (e: Exception) {
        }
    }

    private fun checkBirthday() {
        val b = state.bornDate()
        val today = java.time.LocalDate.now()
        if (today.year > b.year && today == b.withYear(today.year) && state.bdayYear != today.year) {
            val years = today.year - b.year
            update { it.copy(coins = it.coins + 60, gems = it.gems + 2, bdayYear = today.year) }
            react(Reaction.GIFT, 4000)
            sayLine(Lines.BIRTHDAY, 6000)
            showToast("🎂 Joyeux anniversaire ! $years an${if (years > 1) "s" else ""} ensemble : +60 pièces et +2 gemmes")
            sfx("levelup")
        }
    }

    /** Tirage d'un autocollant (avec une chance donnée) ; le message arrive juste après les autres. */
    fun dropSticker(chance: Float) {
        if (Random.nextFloat() > chance) return
        val st = Stickers.roll()
        val had = (state.stickers[st.id] ?: 0) > 0
        update {
            var n = it.copy(stickers = it.stickers + (st.id to ((it.stickers[st.id] ?: 0) + 1)))
            if (had) n = n.copy(coins = n.coins + STICKER_DUPLICATE_COINS)
            n
        }
        viewModelScope.launch {
            delay(1800)
            showToast(
                if (had) "🃏 ${st.glyph} ${st.name} (doublon) : +$STICKER_DUPLICATE_COINS pièces"
                else "🃏 Nouvel autocollant ${st.rarity.label.lowercase()} : ${st.glyph} ${st.name} ! (Galerie > Autocollants)",
            )
            sfx("sparkle", 0.6f)
        }
    }

    fun photoSaved() {
        update { it.copy(counts = it.counts + ("PHOTO" to ((it.counts["PHOTO"] ?: 0) + 1))) }
    }

    /** Minuteur de sommeil : berceuse pendant N minutes, puis fondu et Nyxie s'endort. */
    fun startSleepTimer(minutes: Int) {
        sleepJob?.cancel()
        fadeJob?.cancel()
        sleepTimerEnd = System.currentTimeMillis() + minutes * 60_000L
        musicStart(force = true)
        sayLine(Lines.SLEEP_TIMER, 4500)
        showToast("Berceuse pendant $minutes min, puis Nyxie s'endort.")
        sleepJob = viewModelScope.launch {
            delay(minutes * 60_000L)
            fadeOutMusic()
            if (!state.sleeping) update { it.copy(sleeping = true, activityId = null) }
            sleepTimerEnd = 0L
        }
    }

    fun cancelSleepTimer() {
        sleepJob?.cancel()
        sleepTimerEnd = 0L
        if (!state.musicOn) musicPause()
    }

    private fun fadeOutMusic() {
        fadeJob?.cancel()
        fadeJob = viewModelScope.launch {
            var v = 0.28f
            while (v > 0.01f) {
                try { music?.setVolume(v, v) } catch (e: Exception) { }
                v -= 0.02f
                delay(400)
            }
            try { music?.pause(); music?.setVolume(0.28f, 0.28f) } catch (e: Exception) { }
        }
    }

    fun finishGuide() {
        getApplication<Application>().getSharedPreferences("nyxie_flags", Context.MODE_PRIVATE)
            .edit().putBoolean("guide_seen", true).apply()
        guideActive = false
    }

    fun replayGuide() {
        screen = Screen.HOME
        guideActive = true
    }

    fun setVoice(on: Boolean) {
        update { it.copy(voiceOn = on) }
        if (on) {
            ensureTts()
            say("Maintenant, je parle à voix haute !", 3000)
        } else {
            try { tts?.stop() } catch (e: Exception) { }
        }
    }

    private fun ensureTts() {
        if (tts != null) return
        try {
            tts = android.speech.tts.TextToSpeech(getApplication()) { status ->
                if (status == android.speech.tts.TextToSpeech.SUCCESS) {
                    val r = tts?.setLanguage(java.util.Locale.FRANCE)
                    ttsReady = r != android.speech.tts.TextToSpeech.LANG_MISSING_DATA &&
                        r != android.speech.tts.TextToSpeech.LANG_NOT_SUPPORTED
                    tts?.setPitch(1.25f)
                    tts?.setSpeechRate(0.95f)
                }
            }
        } catch (e: Exception) {
            tts = null
        }
    }

    private fun speak(text: String) {
        if (!state.voiceOn || !state.soundsOn || state.sleeping) return
        ensureTts()
        if (!ttsReady) return
        val clean = text.filter { it.isLetterOrDigit() || it in " .,!?'’…-+:;()" }.trim()
        if (clean.isNotEmpty()) {
            try { tts?.speak(clean, android.speech.tts.TextToSpeech.QUEUE_FLUSH, null, "nyxie") } catch (e: Exception) { }
        }
    }

    fun setMusic(on: Boolean) {
        update { it.copy(musicOn = on) }
        if (on) musicStart() else musicPause()
    }

    private fun hasIntroVideo(): Boolean {
        val app = getApplication<Application>()
        return app.resources.getIdentifier("nyxie_intro", "raw", app.packageName) != 0
    }

    /** Fin (ou saut) de l'introduction : on enregistre qu'elle a été vue et on ouvre la chambre. */
    fun finishIntro() {
        if (!introActive) return
        getApplication<Application>().getSharedPreferences("nyxie_flags", Context.MODE_PRIVATE)
            .edit().putBoolean("intro_seen", true).apply()
        introActive = false
        musicStart()
    }

    /** Paramètres > Revoir l'introduction : ne touche à aucune donnée de jeu. */
    fun replayIntro() {
        if (!hasIntroVideo()) {
            showToast("L'introduction n'est pas disponible.")
            return
        }
        musicPause()
        screen = Screen.HOME
        introActive = true
    }

    fun playShutter() = sfx("shutter")

    /** Joue un bruitage de Nyxie (fichiers res/raw/snd_*.wav). */
    private fun sfx(name: String, volume: Float = 1f) {
        if (!state.soundsOn) return
        try {
            if (pool == null) {
                val sp = SoundPool.Builder()
                    .setMaxStreams(4)
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build(),
                    )
                    .build()
                pool = sp
                val app = getApplication<Application>()
                for (n in listOf("purr", "meow", "meow2", "munch", "chirp", "giggle", "splash", "brush",
                    "yawn", "sad", "sparkle", "coin", "levelup", "shutter")) {
                    val rid = app.resources.getIdentifier("snd_$n", "raw", app.packageName)
                    if (rid != 0) sfxIds[n] = sp.load(app, rid, 1)
                }
            }
            val id = sfxIds[name] ?: return
            lastPlayed = pool?.play(id, volume, volume, 1, 0, 1f) ?: 0
        } catch (e: Exception) {
            // Pas de son disponible : on ignore.
        }
    }

    private fun beep(kind: Int) {
        if (!state.soundsOn) return
        try {
            if (tone == null) tone = ToneGenerator(AudioManager.STREAM_MUSIC, 45)
            val code = when (kind) {
                1 -> ToneGenerator.TONE_PROP_ACK
                2 -> ToneGenerator.TONE_PROP_BEEP
                3 -> ToneGenerator.TONE_PROP_PROMPT
                else -> ToneGenerator.TONE_PROP_BEEP2
            }
            tone?.startTone(code, 140)
        } catch (e: Exception) {
            // Pas de son disponible : on ignore.
        }
    }

    private fun tickOnce() {
        val t = System.currentTimeMillis()
        now = t
        var s = decay(state, t - state.lastSeen).copy(lastSeen = t)
        if (s.sleeping && s.energy >= 0.99f) {
            s = s.copy(sleeping = false)
            sayLine(Lines.WOKE_RESTED, 5000)
        }
        state = s
        dirty = true
        // Fin d'activité
        val a = s.activityId?.let { Catalog.activityById[it] }
        if (a != null && t >= s.activityStart + a.durationSec * 1000L) {
            finishActivity(false)
        }
        // Petite phrase spontanée de temps en temps
        idleTicks++
        if (idleTicks >= 45 && speech == null && !state.sleeping && reaction == Reaction.NONE) {
            idleTicks = 0
            sayLine(Lines.idleBank(state), 4200)
        }
    }

    private fun sleepingGate(): Boolean {
        if (state.sleeping) {
            say("Chut… ${state.name} dort. Touche-la pour la réveiller.", 3500)
            return true
        }
        return false
    }

    // -----------------------------------------------------------------------
    // Actions principales
    // -----------------------------------------------------------------------

    fun tapNyxie() {
        if (state.sleeping) wake() else pet()
    }

    fun pet() {
        if (sleepingGate()) return
        val s = state
        val gain = if (s.affection > 0.95f) 0.01f else 0.08f
        update { it.bump(a = gain).gainXp(3).log("PET", System.currentTimeMillis()).unlock("first_pet") }
        react(Reaction.PET, 2400)
        sayLine(Lines.PET, 3500, anim = false)
        sfx("purr", 0.9f)
    }

    fun feed(itemId: String) {
        val item = Catalog.byId[itemId] ?: return
        if (sleepingGate()) return
        val s = state
        if ((s.inventory[itemId] ?: 0) <= 0) {
            showToast("Tu n'as plus de ${item.name}.")
            return
        }
        if (item.kind == ItemKind.FOOD && s.hunger > 0.97f) {
            sayLine(Lines.EAT_FULL, 3000)
            return
        }
        update {
            it.takeItem(itemId)
                .bump(h = item.hunger, e = item.energy, a = item.affection)
                .gainXp(item.xp)
                .log("EAT", System.currentTimeMillis())
                .unlock("first_meal")
        }
        react(if (item.kind == ItemKind.TONIC) Reaction.GIFT else Reaction.EAT, 2800)
        if (Random.nextInt(3) == 0) say(eatLines(item).first(), 3800) else sayLine(Lines.EAT, 3800, anim = false)
        sfx(if (item.kind == ItemKind.TONIC) "splash" else "munch")
        if (item.kind == ItemKind.TONIC) sfx("sparkle", 0.6f)
    }

    fun play(toyId: String? = null) {
        if (sleepingGate()) return
        val s = state
        if (s.energy < 0.15f) {
            sayLine(Lines.TOO_TIRED, 3800)
            return
        }
        val toy = toyId?.let { Catalog.byId[it] }
        val aff = 0.08f + (toy?.affection ?: 0f)
        val en = -0.08f + (toy?.energy ?: 0f)
        update {
            it.bump(e = en, a = aff).gainXp(6).copy(coins = it.coins + Random.nextInt(2, 5))
                .log("PLAY", System.currentTimeMillis())
        }
        react(Reaction.PLAY, 2800)
        sayLine(Lines.PLAY, 3500, anim = false)
        sfx("giggle")
    }

    fun useItem(itemId: String) {
        val item = Catalog.byId[itemId] ?: return
        when (item.kind) {
            ItemKind.FOOD, ItemKind.TONIC -> feed(itemId)
            ItemKind.TOY -> play(itemId)
            else -> {}
        }
    }

    fun talk() {
        if (sleepingGate()) return
        val line = picker.pick(Lines.talkBank(state)).text
        update { it.bump(a = 0.02f).gainXp(2).log("TALK", System.currentTimeMillis()) }
        react(Reaction.TALK, 2800)
        say(line, 4500)
        chat.add(ChatMsg(false, line, System.currentTimeMillis()))
        sfx(if (Random.nextInt(3) == 0) "meow" else "chirp")
    }

    fun send(text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        chat.add(ChatMsg(true, t, System.currentTimeMillis()))
        if (state.sleeping) {
            chat.add(ChatMsg(false, "Zzz… zzz…", System.currentTimeMillis()))
            return
        }
        val answer = replyTo(t, state)
        update { it.bump(a = 0.01f).gainXp(2).log("TALK", System.currentTimeMillis()) }
        viewModelScope.launch {
            delay(600)
            chat.add(ChatMsg(false, answer, System.currentTimeMillis()))
            say(answer, 4500)
            react(Reaction.TALK, 2800)
            sfx("chirp")
        }
    }

    fun careBath() {
        if (sleepingGate()) return
        update { it.bump(h = -0.03f, a = 0.12f).gainXp(6).log("CARE", System.currentTimeMillis()) }
        react(Reaction.PET, 2800)
        sayLine(Lines.BATH, 4000, anim = false)
        sfx("splash")
    }

    fun careBrush() {
        if (sleepingGate()) return
        update { it.bump(a = 0.08f).gainXp(4).log("CARE", System.currentTimeMillis()) }
        react(Reaction.PET, 2400)
        sayLine(Lines.BRUSH, 3800, anim = false)
        sfx("brush")
        sfx("purr", 0.6f)
    }

    fun toggleSleep() {
        val s = state
        if (s.sleeping) {
            wake()
        } else if (s.energy > 0.9f) {
            sayLine(Lines.NOT_SLEEPY, 3000)
        } else {
            update { it.copy(sleeping = true, activityId = null).log("SLEEP", System.currentTimeMillis()) }
            reaction = Reaction.NONE
            sayLine(Lines.GOING_TO_BED, 3000, anim = false)
            sfx("yawn")
            showToast("${s.name} s'endort. Son énergie remonte pendant son sommeil.")
        }
    }

    fun wake() {
        if (!state.sleeping) return
        update { it.copy(sleeping = false) }
        sayLine(Lines.WAKE, 4000)
        sfx("yawn", 0.8f)
    }

    // -----------------------------------------------------------------------
    // Activités
    // -----------------------------------------------------------------------

    fun startActivity(id: String) {
        if (sleepingGate()) return
        val a = Catalog.activityById[id] ?: return
        if (state.activityId != null) {
            showToast("Une activité est déjà en cours.")
            return
        }
        if (a.energyDelta < 0f && state.energy < 0.15f) {
            say("Je suis trop fatiguée pour ça…", 3500)
            return
        }
        update { it.copy(activityId = id, activityStart = System.currentTimeMillis()) }
        react(Reaction.ACTIVITY, 3200)
        say(a.line, 4500)
        sfx("meow2")
    }

    fun finishActivity(early: Boolean) {
        val s = state
        val a = s.activityId?.let { Catalog.activityById[it] } ?: return
        val total = a.durationSec * 1000f
        val progress = ((System.currentTimeMillis() - s.activityStart) / total).coerceIn(0f, 1f)
        val f = if (early) progress * 0.5f else 1f
        val coins = (a.coins * f).toInt()
        update {
            it.copy(activityId = null, activityStart = 0L)
                .bump(e = a.energyDelta * f, a = a.affection * f)
                .gainXp((a.xp * f).toInt())
                .copy(coins = it.coins + coins)
                .log("ACT", System.currentTimeMillis())
        }
        react(Reaction.PET, 2400)
        if (early) say("On s'arrête déjà ? D'accord…", 4000) else sayLine(Lines.ACTIVITY_DONE, 4000, n = coins, anim = false)
        if (!early) sfx("sparkle")
    }

    // -----------------------------------------------------------------------
    // Cadeau, boutique, style
    // -----------------------------------------------------------------------

    fun giftReady(): Boolean = now - state.lastGift >= GIFT_COOLDOWN_MS

    fun giftRemainingMs(): Long = max(0L, GIFT_COOLDOWN_MS - (now - state.lastGift))

    fun claimGift() {
        if (!giftReady()) {
            showToast("Prochain cadeau dans ${remainingText(giftRemainingMs())}.")
            say("Reviens plus tard, j'en prépare un autre !", 3500)
            return
        }
        dropSticker(0.6f)
        val roll = Random.nextInt(100)
        val t = System.currentTimeMillis()
        var message: String
        when {
            roll < 45 -> {
                val c = Random.nextInt(30, 61)
                update { it.copy(coins = it.coins + c, lastGift = t).gainXp(8).log("GIFT", t).unlock("gift") }
                message = "Un cadeau ! +$c pièces !"
            }
            roll < 75 -> {
                val food = Catalog.items.filter { it.kind == ItemKind.FOOD && it.price <= 70 }.random()
                update { it.addItem(food.id).copy(lastGift = t).gainXp(8).log("GIFT", t).unlock("gift") }
                message = "Un cadeau ! ${food.glyph} ${food.name} !"
            }
            roll < 90 -> {
                val g = Random.nextInt(1, 3)
                update { it.copy(gems = it.gems + g, lastGift = t).gainXp(8).log("GIFT", t).unlock("gift") }
                message = "Un cadeau ! +$g gemme !"
            }
            else -> {
                update { it.addItem("nectar").copy(lastGift = t).gainXp(8).log("GIFT", t).unlock("gift") }
                message = "Un cadeau ! 🍯 Nectar des rêves !"
            }
        }
        react(Reaction.GIFT, 3400)
        say(message, 4500)
        showToast(message)
        sfx("sparkle")
        sfx("meow2", 0.8f)
    }

    fun buy(itemId: String) {
        val item = Catalog.byId[itemId] ?: return
        val s = state
        val permanent = item.kind == ItemKind.TOY || item.kind == ItemKind.ACCESSORY ||
            item.kind == ItemKind.THEME || item.kind == ItemKind.AMBIANCE
        if (permanent) {
            val has = if (item.kind == ItemKind.TOY) (s.inventory[itemId] ?: 0) > 0 else itemId in s.owned
            if (has) {
                showToast("Tu possèdes déjà cet objet.")
                return
            }
        }
        val money = if (item.useGems) s.gems else s.coins
        if (money < item.price) {
            showToast(if (item.useGems) "Pas assez de gemmes." else "Pas assez de pièces.")
            return
        }
        update {
            var n = if (item.useGems) it.copy(gems = it.gems - item.price) else it.copy(coins = it.coins - item.price)
            n = when (item.kind) {
                ItemKind.ACCESSORY, ItemKind.THEME, ItemKind.AMBIANCE -> n.copy(owned = n.owned + itemId)
                else -> n.addItem(itemId)
            }
            n.questTick("BUY")
        }
        showToast("Acheté : ${item.glyph} ${item.name}")
        sfx("coin")
    }

    fun buyPack(packId: String) {
        val pack = Packs.byId(packId) ?: return
        val s = state
        val missing = Packs.missing(pack, s)
        if (missing.isEmpty()) {
            showToast("Tu possèdes déjà tout ce pack.")
            return
        }
        val price = Packs.price(pack, s)
        val money = if (pack.useGems) s.gems else s.coins
        if (money < price) {
            showToast(if (pack.useGems) "Pas assez de gemmes." else "Pas assez de pièces.")
            return
        }
        update {
            var n = if (pack.useGems) it.copy(gems = it.gems - price) else it.copy(coins = it.coins - price)
            n = n.copy(owned = n.owned + missing.map { m -> m.id })
            n.questTick("BUY")
        }
        showToast("${pack.glyph} ${pack.name} : ${missing.size} objet${if (missing.size > 1) "s" else ""} ajouté${if (missing.size > 1) "s" else ""} !")
        sfx("coin")
        sfx("sparkle", 0.7f)
        sayLine(Lines.EQUIP, 3000, anim = false)
    }

    /** Équipe d'un coup tous les objets possédés d'un pack (un par emplacement, l'ambiance et le thème compris). */
    fun equipPack(packId: String) {
        val pack = Packs.byId(packId) ?: return
        update { st ->
            var n = st
            for (item in Packs.items(pack)) {
                if (item.id !in n.owned) continue
                n = when (item.kind) {
                    ItemKind.ACCESSORY -> n.withWorn(item.slot, item.id)
                    ItemKind.THEME -> n.copy(theme = item.id)
                    ItemKind.AMBIANCE -> n.copy(ambiance = item.id)
                    else -> n
                }
            }
            n
        }
        sayLine(Lines.EQUIP, 2800, anim = false)
        sfx("meow")
        react(Reaction.PET, 1800)
    }

    fun equip(itemId: String) {
        val item = Catalog.byId[itemId] ?: return
        if (itemId !in state.owned) return
        when (item.kind) {
            ItemKind.ACCESSORY -> update { it.withWorn(item.slot, itemId) }
            ItemKind.THEME -> update { it.copy(theme = itemId) }
            ItemKind.AMBIANCE -> update { it.copy(ambiance = itemId) }
            else -> return
        }
        sayLine(Lines.EQUIP, 2800, anim = false)
        sfx("meow")
        react(Reaction.PET, 1800)
    }

    /** Retire l'objet porté dans un emplacement (head, face, neck, aura) ou l'ambiance (amb). */
    fun unequip(slot: String) {
        if (slot == "amb") update { it.copy(ambiance = "amb_none") } else update { it.withWorn(slot, "acc_none") }
    }


    // -----------------------------------------------------------------------
    // Mini-jeux
    // -----------------------------------------------------------------------

    fun finishStars(score: Int) {
        dropSticker(0.35f)
        val coins = score / 2 + 2
        update {
            it.bump(e = -0.10f, a = 0.05f).gainXp(score * 2 + 5)
                .copy(coins = it.coins + coins, bestStars = max(it.bestStars, score))
                .log("PLAY", System.currentTimeMillis()).unlock("first_game")
        }
        react(Reaction.PLAY, 3000)
        val bank = when { score >= 35 -> Lines.STARS_GOOD; score >= 15 -> Lines.STARS_OK; else -> Lines.STARS_LOW }
        say(picker.pick(bank).text.replace("{n}", score.toString()) + " +$coins pièces", 4800)
        sfx("giggle")
        sfx("sparkle", 0.7f)
    }

    fun finishFireflies(score: Int) {
        dropSticker(0.35f)
        val coins = score / 2 + 3
        update {
            it.bump(e = -0.08f, a = 0.05f).gainXp(score * 2 + 6)
                .copy(coins = it.coins + coins, bestFireflies = max(it.bestFireflies, score))
                .log("PLAY", System.currentTimeMillis()).unlock("first_game")
        }
        react(Reaction.PLAY, 3000)
        val bank = when { score >= 22 -> Lines.FIREFLY_GOOD; score >= 9 -> Lines.FIREFLY_OK; else -> Lines.FIREFLY_LOW }
        say(picker.pick(bank).text.replace("{n}", score.toString()) + " +$coins pièces", 4800)
        sfx("giggle")
        sfx("sparkle", 0.7f)
    }

    fun finishBubbles(score: Int) {
        dropSticker(0.35f)
        val coins = score / 3 + 3
        update {
            it.bump(e = -0.07f, a = 0.06f).gainXp(score + 8)
                .copy(coins = it.coins + coins, bestBubbles = max(it.bestBubbles, score))
                .log("PLAY", System.currentTimeMillis()).unlock("first_game")
        }
        react(Reaction.PLAY, 3000)
        val bank = when { score >= 45 -> Lines.BUBBLE_GOOD; score >= 20 -> Lines.BUBBLE_OK; else -> Lines.BUBBLE_LOW }
        say(picker.pick(bank).text.replace("{n}", score.toString()) + " +$coins pièces", 4800)
        sfx("giggle")
        sfx("splash", 0.7f)
    }

    fun finishHide(score: Int) {
        dropSticker(0.35f)
        val coins = score * 4 + 3
        update {
            it.bump(e = -0.05f, a = 0.07f).gainXp(score * 3 + 8)
                .copy(coins = it.coins + coins, bestHide = max(it.bestHide, score))
                .log("PLAY", System.currentTimeMillis()).unlock("first_game")
        }
        react(Reaction.PLAY, 3000)
        val bank = when { score >= 7 -> Lines.HIDE_GOOD; score >= 4 -> Lines.HIDE_OK; else -> Lines.HIDE_LOW }
        say(picker.pick(bank).text.replace("{n}", score.toString()) + " +$coins pièces", 4800)
        sfx("giggle")
        sfx("sparkle", 0.7f)
    }

    fun finishMemory(moves: Int) {
        dropSticker(0.35f)
        val coins = max(5, 40 - moves * 2)
        update {
            it.bump(e = -0.06f, a = 0.06f).gainXp(20)
                .copy(coins = it.coins + coins, bestMemory = if (it.bestMemory == 0) moves else min(it.bestMemory, moves))
                .log("PLAY", System.currentTimeMillis()).unlock("first_game")
        }
        react(Reaction.PLAY, 3000)
        val bank = when { moves <= 12 -> Lines.MEMORY_GOOD; moves <= 22 -> Lines.MEMORY_OK; else -> Lines.MEMORY_LONG }
        say(picker.pick(bank).text.replace("{n}", moves.toString()) + " +$coins pièces", 4800)
        sfx("giggle")
        sfx("sparkle", 0.7f)
    }

    // -----------------------------------------------------------------------
    // Paramètres
    // -----------------------------------------------------------------------

    fun rename(newName: String) {
        val n = newName.trim().take(14)
        if (n.isEmpty()) {
            showToast("Choisis un nom d'au moins une lettre.")
            return
        }
        update { it.copy(name = n) }
        say("$n… j'adore mon nom !", 3500)
        showToast("Nouveau nom enregistré.")
    }

    fun setNotifications(on: Boolean) {
        update { it.copy(notifOn = on) }
        saveNow()
        if (on) Notifier.schedule(getApplication(), state, reset = true) else Notifier.cancel(getApplication())
        showToast(if (on) "Nyxie pourra te faire signe." else "Notifications désactivées.")
    }

    fun setSounds(on: Boolean) {
        update { it.copy(soundsOn = on) }
        if (on) sfx("meow")
    }

    fun setAnimations(on: Boolean) = update { it.copy(animationsOn = on) }

    fun resetAll() {
        Store.clear(getApplication())
        chat.clear()
        state = GameState(lastSeen = System.currentTimeMillis())
        dirty = true
        screen = Screen.HOME
        say("Coucou ! On recommence ensemble ?", 5000)
        showToast("Progression réinitialisée.")
    }
}
