package com.lumina.nyxie

import android.content.Context
import org.json.JSONObject

/**
 * Sauvegarde / restauration de la progression dans un fichier .json choisi par la personne
 * (aucun réseau, aucune permission : on passe par le sélecteur de fichiers du système).
 */
object Backup {
    private const val FILE = "nyxie_save_v2"
    private const val MAGIC = "nyxie-backup"

    fun export(c: Context): String {
        val sp = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        val prefs = JSONObject()
        for ((k, v) in sp.all) {
            val o = JSONObject()
            when (v) {
                is String -> { o.put("t", "s"); o.put("v", v) }
                is Int -> { o.put("t", "i"); o.put("v", v) }
                is Long -> { o.put("t", "l"); o.put("v", v) }
                is Float -> { o.put("t", "f"); o.put("v", v.toDouble()) }
                is Boolean -> { o.put("t", "b"); o.put("v", v) }
                else -> continue
            }
            prefs.put(k, o)
        }
        return JSONObject()
            .put("app", MAGIC)
            .put("format", 1)
            .put("savedAt", System.currentTimeMillis())
            .put("prefs", prefs)
            .toString(1)
    }

    /** Vérifie le fichier ; renvoie le nom du personnage si valide, sinon null. */
    fun check(json: String): String? = try {
        val root = JSONObject(json)
        if (root.optString("app") != MAGIC) null
        else root.getJSONObject("prefs").getJSONObject("name").getString("v")
    } catch (e: Exception) {
        null
    }

    fun restore(c: Context, json: String): Boolean {
        if (check(json) == null) return false
        return try {
            val prefs = JSONObject(json).getJSONObject("prefs")
            val ed = c.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().clear()
            val keys = prefs.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                val o = prefs.getJSONObject(k)
                when (o.getString("t")) {
                    "s" -> ed.putString(k, o.getString("v"))
                    "i" -> ed.putInt(k, o.getInt("v"))
                    "l" -> ed.putLong(k, o.getLong("v"))
                    "f" -> ed.putFloat(k, o.getDouble("v").toFloat())
                    "b" -> ed.putBoolean(k, o.getBoolean("v"))
                }
            }
            ed.commit()
        } catch (e: Exception) {
            false
        }
    }
}
