package com.lumina.nyxie

import kotlin.random.Random

// ---------------------------------------------------------------------------
// Album d'autocollants : on en gagne au fil du jeu (coffre du jour, cadeaux, quêtes, mini-jeux).
// Les doublons sont convertis en pièces. Aucun achat, aucune monnaie réelle.
// ---------------------------------------------------------------------------

class Sticker(val id: String, val glyph: String, val name: String, val rarity: Rarity)

object Stickers {
    private fun c(id: String, g: String, n: String) = Sticker(id, g, n, Rarity.COMMON)
    private fun r(id: String, g: String, n: String) = Sticker(id, g, n, Rarity.RARE)
    private fun e(id: String, g: String, n: String) = Sticker(id, g, n, Rarity.EPIC)
    private fun l(id: String, g: String, n: String) = Sticker(id, g, n, Rarity.LEGENDARY)

    val all = listOf(
        c("st_moon", "🌙", "Croissant de lune"), c("st_star", "⭐", "Petite étoile"), c("st_cloud", "☁️", "Nuage doux"),
        c("st_leaf", "🍃", "Feuille du soir"), c("st_mush", "🍄", "Champignon rigolo"), c("st_cookie", "🍪", "Biscuit croustillant"),
        c("st_flower", "🌼", "Pâquerette"), c("st_drop", "💧", "Goutte de rosée"), c("st_note", "🎵", "Note de berceuse"),
        c("st_candle", "🕯️", "Bougie tremblante"), c("st_book", "📖", "Vieux grimoire"), c("st_shell", "🐚", "Coquillage"),
        c("st_cat", "🐈‍⬛", "Chat de la nuit"), c("st_owl", "🦉", "Hibou rêveur"), c("st_bat", "🦇", "Chauve-souris amie"),
        c("st_apple", "🍎", "Pomme rouge"),
        r("st_firefly", "🪲", "Luciole dorée"), r("st_rainbow", "🌈", "Arc-en-ciel"), r("st_butterfly", "🦋", "Papillon de nuit"),
        r("st_kite", "🪁", "Cerf-volant"), r("st_telescope", "🔭", "Télescope"), r("st_lantern", "🏮", "Lanterne magique"),
        r("st_bubbles", "🫧", "Bulle arc-en-ciel"), r("st_fox", "🦊", "Renard curieux"), r("st_unicorn", "🦄", "Licorne timide"),
        e("st_comet", "☄️", "Comète"), e("st_crystal", "🔮", "Boule de cristal"), e("st_sparkle", "✨", "Éclat de magie"),
        e("st_castle", "🏰", "Château dans les nuages"), e("st_dragon", "🐉", "Petit dragon"),
        l("st_galaxy", "🌌", "Galaxie secrète"), l("st_crown", "👑", "Couronne légendaire"),
    )

    val byId = all.associateBy { it.id }

    /** Tirage pondéré par rareté : 62 % commun, 26 % rare, 10 % épique, 2 % légendaire. */
    fun roll(): Sticker {
        val x = Random.nextInt(100)
        val rar = when {
            x < 62 -> Rarity.COMMON
            x < 88 -> Rarity.RARE
            x < 98 -> Rarity.EPIC
            else -> Rarity.LEGENDARY
        }
        return all.filter { it.rarity == rar }.random()
    }
}

const val STICKER_DUPLICATE_COINS = 8
