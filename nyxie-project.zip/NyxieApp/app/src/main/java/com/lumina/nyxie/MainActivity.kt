package com.lumina.nyxie

import android.content.ActivityNotFoundException
import android.content.Intent
import android.Manifest
import android.content.pm.PackageManager
import android.content.ContentValues
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.PixelCopy
import android.os.Bundle
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.res.imageResource
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {

    private val vm: GameViewModel by viewModels()

    private val micLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val text = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
            if (!text.isNullOrBlank()) {
                vm.screen = Screen.CHAT
                vm.send(text)
            }
        }

    private val exportLauncher =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
            if (uri != null) {
                try {
                    contentResolver.openOutputStream(uri)!!.use { it.write(vm.backupJson().toByteArray(Charsets.UTF_8)) }
                    vm.showToast("Sauvegarde enregistrée ✅ Garde bien ce fichier !")
                } catch (e: Exception) {
                    vm.showToast("Impossible d'enregistrer la sauvegarde.")
                }
            }
        }

    private val importLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                try {
                    val txt = contentResolver.openInputStream(uri)!!.use { String(it.readBytes(), Charsets.UTF_8) }
                    vm.restoreFrom(txt)
                } catch (e: Exception) {
                    vm.showToast("Impossible de lire ce fichier.")
                }
            }
        }

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT < 33) return
        val sp = getSharedPreferences("nyxie_notif", MODE_PRIVATE)
        if (sp.getBoolean("asked", false)) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            sp.edit().putBoolean("asked", true).apply()
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    /** Capture ce qui est affiché (le mode photo masque l'interface) et l'enregistre dans Images/Nyxie. */
    private fun capturePhoto() {
        val view = window.decorView
        if (view.width <= 0 || view.height <= 0) return
        val bmp = Bitmap.createBitmap(view.width, view.height, Bitmap.Config.ARGB_8888)
        try {
            PixelCopy.request(window, bmp, { res ->
                if (res == PixelCopy.SUCCESS) savePhoto(bmp) else vm.showToast("Impossible de prendre la photo.")
            }, Handler(Looper.getMainLooper()))
        } catch (e: Exception) {
            vm.showToast("Impossible de prendre la photo.")
        }
    }

    /** Enregistre uniquement le cadre du souvenir affiché (même dossier que les photos). */
    private fun saveRegion(r: android.graphics.Rect) {
        if (r.width() <= 0 || r.height() <= 0) return
        val bmp = Bitmap.createBitmap(r.width(), r.height(), Bitmap.Config.ARGB_8888)
        try {
            PixelCopy.request(window, r, bmp, { res ->
                if (res == PixelCopy.SUCCESS) savePhoto(bmp) else vm.showToast("Impossible d'enregistrer le souvenir.")
            }, Handler(Looper.getMainLooper()))
        } catch (e: Exception) {
            vm.showToast("Impossible d'enregistrer le souvenir.")
        }
    }

    private fun savePhoto(bmp: Bitmap) {
        val name = "Nyxie_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".jpg"
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val cv = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, name)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                    put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Nyxie")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv) ?: error("insert")
                contentResolver.openOutputStream(uri)!!.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
                cv.clear()
                cv.put(MediaStore.Images.Media.IS_PENDING, 0)
                contentResolver.update(uri, cv, null, null)
                vm.lastPhoto = uri
                vm.addPhoto(uri.toString(), name)
                vm.photoSaved()
                vm.showToast("Photo enregistrée dans Galerie > Nyxie 📸")
            } else {
                val dir = getExternalFilesDir(Environment.DIRECTORY_PICTURES) ?: error("dir")
                val f = File(dir, name)
                f.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
                vm.addPhoto(Uri.fromFile(f).toString(), name)
                vm.photoSaved()
                vm.showToast("Photo enregistrée dans les fichiers de l'application 📸")
            }
        } catch (e: Exception) {
            vm.showToast("Enregistrement de la photo impossible.")
        }
    }

    /** Copie une photo de la liste dans Téléchargements/Nyxie (Android 10 et plus). */
    private fun downloadPhoto(p: PhotoEntry) {
        try {
            if (Build.VERSION.SDK_INT < 29) {
                vm.showToast("Le téléchargement demande Android 10 ou plus : la photo reste dans les fichiers de l'application.")
                return
            }
            val src = Uri.parse(p.uri)
            val cv = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, p.name)
                put(MediaStore.Downloads.MIME_TYPE, "image/jpeg")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Nyxie")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val dst = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv) ?: error("insert")
            contentResolver.openInputStream(src)!!.use { i -> contentResolver.openOutputStream(dst)!!.use { o -> i.copyTo(o) } }
            cv.clear()
            cv.put(MediaStore.Downloads.IS_PENDING, 0)
            contentResolver.update(dst, cv, null, null)
            vm.showToast("Téléchargée dans Téléchargements > Nyxie ⬇️")
        } catch (e: Exception) {
            vm.showToast("Téléchargement impossible (photo introuvable ?).")
        }
    }

    private fun shareEntry(p: PhotoEntry) {
        if (p.uri.startsWith("file:")) {
            vm.showToast("Partage disponible à partir d'Android 10.")
            return
        }
        vm.lastPhoto = Uri.parse(p.uri)
        sharePhoto()
    }

    private fun sharePhoto() {
        val uri: Uri = vm.lastPhoto ?: return
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "image/jpeg"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(send, "Partager la photo"))
    }

    private fun startMic() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.FRANCE.toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Parle à ${vm.state.name}…")
        }
        try {
            micLauncher.launch(intent)
        } catch (e: ActivityNotFoundException) {
            vm.showToast("La saisie vocale n'est pas disponible sur cet appareil.")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.systemBars())

        askNotificationPermission()
        vm.saveRegionAction = { r -> saveRegion(r) }
        vm.downloadAction = { p -> downloadPhoto(p) }
        vm.sharePhotoAction = { p -> shareEntry(p) }
        vm.shareAction = { if (vm.lastPhoto != null) sharePhoto() else vm.showToast("Télécharge d'abord le souvenir.") }
        vm.exportAction = {
            exportLauncher.launch("Nyxie_sauvegarde_" + SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date()) + ".json")
        }
        vm.importAction = { importLauncher.launch(arrayOf("application/json", "text/plain", "application/octet-stream", "*/*")) }

        setContent {
            val assets = Assets(
                scene = ImageBitmap.imageResource(R.drawable.nyxie_pet_scene),
                lidL = ImageBitmap.imageResource(R.drawable.nyxie_lid_l),
                lidR = ImageBitmap.imageResource(R.drawable.nyxie_lid_r),
                mouthCover = ImageBitmap.imageResource(R.drawable.nyxie_mouth_cover),
            )
            val keep = remember { assets }
            MaterialTheme(colorScheme = darkColorScheme()) {
                CompositionLocalProvider(LocalAssets provides keep) {
                    NyxieApp(vm, onMic = { startMic() }, onCapture = { capturePhoto() }, onShare = { sharePhoto() })
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        Notifier.cancel(this)
        vm.musicStart()
    }

    override fun onStop() {
        vm.saveNow()
        Notifier.schedule(this, vm.state, reset = true)
        NyxieWidget.refresh(this)
        if (vm.sleepTimerEnd == 0L) vm.musicPause()
        super.onStop()
    }

    override fun onDestroy() {
        vm.exportAction = null
        vm.saveRegionAction = null
        vm.downloadAction = null
        vm.sharePhotoAction = null
        vm.shareAction = null
        vm.importAction = null
        super.onDestroy()
    }
}
