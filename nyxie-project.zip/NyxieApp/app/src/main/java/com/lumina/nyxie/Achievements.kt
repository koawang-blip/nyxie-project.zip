package com.lumina.nyxie

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.ChronoUnit

// ---------------------------------------------------------------------------
// Succès (médailles) : conditions calculées à partir de l'état, récompense unique de 15 pièces.
// ---------------------------------------------------------------------------

class Achievement(val id: String, val glyph: String, val name: String, val desc: String, val test: (GameState) -> Boolean)

fun GameState.count(kind: String): Int = counts[kind] ?: 0

fun GameState.bornDate(): LocalDate =
    Instant.ofEpochMilli(if (born > 0L) born else System.currentTimeMillis()).atZone(ZoneId.systemDefault()).toLocalDate()

fun GameState.daysTogether(): Int =
    ChronoUnit.DAYS.between(bornDate(), LocalDate.now()).toInt().coerceAtLeast(0)

/** Jours restants avant le prochain anniversaire de Nyxie (0 = aujourd'hui). */
fun GameState.daysToBirthday(): Int {
    val b = bornDate()
    val today = LocalDate.now()
    var next = b.withYear(today.year)
    if (next.isBefore(today)) next = b.withYear(today.year + 1)
    return ChronoUnit.DAYS.between(today, next).toInt()
}

object Achievements {
    val all = listOf(
        Achievement("hello", "👋", "Premiers pas", "Faire sa première action avec Nyxie.") { it.totalInteractions >= 1 },
        Achievement("feed25", "🍓", "Gourmande", "Nourrir Nyxie 25 fois.") { it.count("EAT") >= 25 },
        Achievement("pet50", "💜", "Câlins à gogo", "La caresser 50 fois.") { it.count("PET") >= 50 },
        Achievement("care20", "🫧", "Chouchoutée", "Prendre soin d'elle 20 fois (bain, brossage).") { it.count("CARE") >= 20 },
        Achievement("talk30", "💬", "Grande discussion", "Discuter 30 fois.") { it.count("TALK") >= 30 },
        Achievement("play20", "🎮", "Joueuse", "Jouer 20 parties.") { it.count("PLAY") >= 20 },
        Achievement("lvl10", "⭐", "Niveau 10", "Atteindre le niveau 10.") { it.level >= 10 },
        Achievement("lvl25", "🌟", "Niveau 25", "Atteindre le niveau 25.") { it.level >= 25 },
        Achievement("lvl50", "👑", "Légende de la nuit", "Atteindre le niveau maximum.") { it.level >= MAX_LEVEL },
        Achievement("streak3", "🔥", "Série de 3", "3 jours de suite avec une quête.") { it.activeStreak >= 3 },
        Achievement("streak7", "🔥", "Série de 7", "7 jours de suite avec une quête.") { it.activeStreak >= 7 },
        Achievement("collector", "🎁", "Collectionneuse", "Posséder 20 objets de personnalisation.") { it.owned.size >= 20 },
        Achievement("stars40", "☄️", "Pluie d'étoiles", "40 points aux étoiles filantes.") { it.bestStars >= 40 },
        Achievement("fire25", "🪲", "Reine des lucioles", "25 points à l'Attrape-lucioles.") { it.bestFireflies >= 25 },
        Achievement("bubble50", "🫧", "Maîtresse des bulles", "50 points aux Bulles magiques.") { it.bestBubbles >= 50 },
        Achievement("hide8", "🍄", "Impossible à cacher", "Trouver Nyxie 8 fois sur 8 au Cache-cache.") { it.bestHide >= 8 },
        Achievement("mem10", "🔮", "Mémoire d'or", "Finir la Mémoire lunaire en 10 coups ou moins.") { it.bestMemory in 1..10 },
        Achievement("event", "✨", "Nuit des lucioles", "Récolter 10 lucioles pendant l'événement.") { it.evCount >= 10 },
        Achievement("photo", "📸", "Photographe", "Prendre une photo en mode photo.") { it.count("PHOTO") >= 1 },
        Achievement("week", "📅", "Une semaine ensemble", "7 jours depuis la rencontre.") { it.daysTogether() >= 7 },
        Achievement("month", "🎂", "Un mois ensemble", "30 jours depuis la rencontre.") { it.daysTogether() >= 30 },
    )
}
