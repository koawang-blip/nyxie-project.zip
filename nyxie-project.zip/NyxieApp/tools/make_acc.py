"""Génère les dessins vectoriels des accessoires (chemins SVG en coordonnées de l'image).
Sortie : acc.json (aperçu navigateur) et AccArt.kt (utilisé par l'application)."""
import json, math, sys

def argb(hexcol, a=1.0):
    h = hexcol.lstrip('#'); r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    return (int(round(a * 255)) << 24) | (r << 16) | (g << 8) | b

class Path:
    def __init__(s, tx=0.0, ty=0.0, rot=0.0, sc=1.0):
        s.tx, s.ty, s.c, s.s, s.sc = tx, ty, math.cos(rot), math.sin(rot), sc
        s.cmd, s.ys = [], []
    def _p(s, x, y):
        X = (x * s.c - y * s.s) * s.sc + s.tx; Y = (x * s.s + y * s.c) * s.sc + s.ty
        s.ys.append(Y); return f"{X:.1f} {Y:.1f}"
    def M(s, x, y): s.cmd.append("M " + s._p(x, y)); return s
    def L(s, x, y): s.cmd.append("L " + s._p(x, y)); return s
    def Q(s, a, b, x, y): s.cmd.append("Q " + s._p(a, b) + " " + s._p(x, y)); return s
    def C(s, a, b, c, d, x, y): s.cmd.append("C " + s._p(a, b) + " " + s._p(c, d) + " " + s._p(x, y)); return s
    def Z(s): s.cmd.append("Z"); return s
    def d(s): return " ".join(s.cmd)
    def y0(s): return min(s.ys)
    def y1(s): return max(s.ys)

K = 0.5523
def ell(cx, cy, rx, ry, **tf):
    p = Path(**tf)
    p.M(cx + rx, cy).C(cx + rx, cy + K * ry, cx + K * rx, cy + ry, cx, cy + ry)
    p.C(cx - K * rx, cy + ry, cx - rx, cy + K * ry, cx - rx, cy)
    p.C(cx - rx, cy - K * ry, cx - K * rx, cy - ry, cx, cy - ry)
    p.C(cx + K * rx, cy - ry, cx + rx, cy - K * ry, cx + rx, cy).Z()
    return p
def poly(pts, close=True, **tf):
    p = Path(**tf); p.M(*pts[0])
    for q in pts[1:]: p.L(*q)
    if close: p.Z()
    return p
def star(cx, cy, r, r2, n=5, rot=-math.pi / 2, **tf):
    pts = []
    for i in range(2 * n):
        a = rot + i * math.pi / n; rr = r if i % 2 == 0 else r2
        pts.append((cx + math.cos(a) * rr, cy + math.sin(a) * rr))
    return poly(pts, **tf)
def sparkle(cx, cy, r, **tf):
    p = Path(**tf); k = 0.14 * r
    p.M(cx, cy - r).Q(cx + k, cy - k, cx + r, cy).Q(cx + k, cy + k, cx, cy + r)
    p.Q(cx - k, cy + k, cx - r, cy).Q(cx - k, cy - k, cx, cy - r).Z()
    return p

def layer(p, fill=None, fill2=None, stroke=None, sw=0.0, fa=1.0, f2a=1.0, sa=1.0):
    L = dict(d=p.d(), fill=argb(fill, fa) if fill else 0, fill2=argb(fill2, f2a) if fill2 else 0,
             gy0=round(p.y0(), 1), gy1=round(p.y1(), 1),
             stroke=argb(stroke, sa) if stroke else 0, sw=sw)
    return L

ART = {}
def art(id_, layers, bob=0.0): ART[id_] = dict(layers=layers, bob=bob)

# ---------------------------------------------------------------- TÊTE
def witch():
    tf = dict(tx=790, ty=294, rot=-0.10)
    ls = [layer(ell(0, 0, 108, 22, **tf), '#6a38b8', '#3a1670', '#22104a', 3)]
    c = Path(**tf).M(-64, -4).C(-56, -60, -6, -108, 38, -146).C(46, -100, 58, -46, 64, -4).Q(0, 10, -64, -4).Z()
    ls.append(layer(c, '#6c3bbd', '#3f1c80', '#24104d', 3))
    b = Path(**tf).M(-63, -12).Q(0, 6, 63, -12).L(59, -32).Q(0, -14, -59, -32).Z()
    ls.append(layer(b, '#ffe58a', '#e0a21c', '#8a5a10', 2))
    ls.append(layer(star(0, -20, 11, 5, **tf), '#fff3b0', None, '#a06a10', 2))
    for x, y, r in [(-22, -70, 7), (14, -96, 6), (-36, -42, 5), (30, -60, 4)]:
        ls.append(layer(sparkle(x, y, r, **tf), '#ffe9a8'))
    art('acc_witch', ls)
witch()

def halo():
    r = ell(792, 238, 82, 17)
    art('acc_halo', [layer(r, stroke='#ffd75a', sw=22, sa=0.14), layer(r, stroke='#ffd75a', sw=13, sa=0.30),
                     layer(r, stroke='#fff2b0', sw=6)], bob=5)
halo()

def flowercrown():
    pts = [(668, 352), (700, 322), (745, 300), (790, 292), (838, 297), (885, 312), (925, 338)]
    pal = [('#ff9ec7', '#c4457f', '#fff0a0'), ('#ffffff', '#c9b6d9', '#ffd24d'),
           ('#c9a8ff', '#7f55c9', '#fff0a0'), ('#ffb3a0', '#c8604d', '#fff0a0')]
    ls = []
    for i in range(len(pts) - 1):
        mx, my = (pts[i][0] + pts[i + 1][0]) / 2, (pts[i][1] + pts[i + 1][1]) / 2 + 9
        ls.append(layer(ell(mx, my, 13, 6, rot=0.5 if i % 2 else -0.5, tx=0, ty=0), '#78d68a', None, '#3f9a55', 1.5))
    for i, (x, y) in enumerate(pts):
        pet, edge, cen = pal[i % 4]; r = 19 if i % 2 == 0 else 16
        for k in range(5):
            a = k * 2 * math.pi / 5 - math.pi / 2
            ls.append(layer(ell(x + math.cos(a) * r * 0.62, y + math.sin(a) * r * 0.62, r * 0.5, r * 0.36, rot=a, tx=0, ty=0)
                            if False else _rot_ell(x + math.cos(a) * r * 0.62, y + math.sin(a) * r * 0.62, r * 0.5, r * 0.36, a),
                            pet, None, edge, 1.5))
        ls.append(layer(ell(x, y, r * 0.3, r * 0.3), cen, None, '#c8923a', 1.2))
    art('acc_flowercrown', ls)
def _rot_ell(cx, cy, rx, ry, rot):
    p = Path(tx=cx, ty=cy, rot=rot)
    p.M(rx, 0).C(rx, K * ry, K * rx, ry, 0, ry).C(-K * rx, ry, -rx, K * ry, -rx, 0)
    p.C(-rx, -K * ry, -K * rx, -ry, 0, -ry).C(K * rx, -ry, rx, -K * ry, rx, 0).Z()
    return p
flowercrown()

def party():
    tf = dict(tx=802, ty=292, rot=0.12)
    ls = []
    cone = poly([(-50, 0), (0, -124), (50, 0)], **tf)
    ls.append(layer(cone, '#ff8ad0', '#8b4dff', '#4a1f99', 3))
    w = lambda y: 50 * (1 + y / 124)
    for h in (-24, -54, -84):
        ls.append(layer(poly([(-w(h), h), (w(h), h), (w(h - 13), h - 13), (-w(h - 13), h - 13)], **tf), '#ffe27a', None, None, 0, fa=0.9))
    for x, y in [(-14, -14), (18, -40), (-8, -70), (10, -100)]:
        ls.append(layer(ell(x, y, 3.2, 3.2, **tf), '#ffffff', fa=0.85))
    ls.append(layer(ell(0, 3, 54, 10, **tf), '#ffd24d', '#e0a21c', '#8a5a10', 2))
    ls.append(layer(ell(0, -127, 13, 13, **tf), '#fff6c8', '#ffe27a', '#d9b24a', 2))
    art('acc_party', ls)
party()

def headband():
    base = Path().M(692, 334).Q(790, 262, 894, 322)
    hi = Path().M(696, 329).Q(790, 257, 890, 317)
    st = star(868, 304, 22, 9.5, rot=-math.pi / 2 + 0.2)
    art('acc_headband', [layer(base, stroke='#b83a7a', sw=18), layer(base, stroke='#ff8fcf', sw=12),
                         layer(hi, stroke='#ffffff', sw=3, sa=0.55),
                         layer(st, '#fff0a0', '#e8a822', '#a06a10', 2.5), layer(sparkle(818, 281, 9), '#fff3b0'),
                         layer(sparkle(742, 296, 7), '#fff3b0')])
headband()

# ---------------------------------------------------------------- VISAGE
LENS_L = (714, 476, 72, 62, -0.10)
LENS_R = (928, 433, 64, 60, -0.17)
def lens(c, **kw):
    cx, cy, rx, ry, rot = c
    return _rot_ell(cx, cy, rx, ry, rot)
def glasses():
    ls = []
    for c in (LENS_L, LENS_R):
        ls.append(layer(lens(c), '#bfe4ff', None, None, 0, fa=0.13))
    for c in (LENS_L, LENS_R):
        ls.append(layer(lens(c), None, None, '#e0a93a', 6))
    for c in (LENS_L, LENS_R):
        cx, cy = c[0], c[1]
        ls.append(layer(Path().M(cx - 44, cy - 24).Q(cx - 24, cy - 44, cx + 2, cy - 48), stroke='#ffffff', sw=4, sa=0.65))
    ls.append(layer(Path().M(783, 468).Q(826, 438, 866, 436), stroke='#e0a93a', sw=6))
    ls.append(layer(Path().M(643, 474).L(618, 462), stroke='#e0a93a', sw=5))
    ls.append(layer(Path().M(992, 426).L(1016, 414), stroke='#e0a93a', sw=5))
    art('acc_glasses', ls)
glasses()

def sunglasses():
    ls = []
    for c in (LENS_L, LENS_R):
        ls.append(layer(lens(c), '#3a2468', '#0b0618', '#14082c', 7, fa=0.93, f2a=0.95))
    for c in (LENS_L, LENS_R):
        cx, cy = c[0], c[1]
        ls.append(layer(poly([(cx - 46, cy - 20), (cx - 20, cy - 44), (cx - 4, cy - 40), (cx - 34, cy - 6)]), '#ffffff', fa=0.22))
    ls.append(layer(Path().M(783, 466).Q(826, 436, 866, 434), stroke='#14082c', sw=8))
    ls.append(layer(Path().M(643, 474).L(616, 460), stroke='#14082c', sw=6))
    ls.append(layer(Path().M(992, 426).L(1018, 412), stroke='#14082c', sw=6))
    art('acc_sunglasses', ls)
sunglasses()

def cheekstars():
    ls = []
    for x, y, r in [(704, 540, 15), (924, 494, 14)]:
        ls.append(layer(star(x, y, r, r * 0.45), '#ffb3e0', '#ff5fb0', '#d03d8d', 1.5))
    for x, y, r in [(684, 524, 6), (946, 480, 6), (726, 556, 5), (902, 510, 5)]:
        ls.append(layer(sparkle(x, y, r), '#ffffff'))
    art('acc_cheekstars', ls)
cheekstars()

# ---------------------------------------------------------------- COU
NECK0, NECK1, NECK2, NECK3 = (742, 576), (772, 618), (840, 622), (874, 558)
NECKQ0, NECKQ1, NECKQ2 = (744, 576), (806, 640), (872, 558)
def bez(p0, p1, p2, p3, t):
    u = 1 - t
    return (u**3 * p0[0] + 3 * u * u * t * p1[0] + 3 * u * t * t * p2[0] + t**3 * p3[0],
            u**3 * p0[1] + 3 * u * u * t * p1[1] + 3 * u * t * t * p2[1] + t**3 * p3[1])
def scarf():
    P0, P1, P2, P3 = NECK0, NECK1, NECK2, NECK3
    band = Path().M(*P0).C(*P1, *P2, *P3)
    ls = [layer(band, stroke='#7a1830', sw=32), layer(band, stroke='#b8304f', sw=26)]
    for k in range(6):
        t0, t1 = 0.10 + k * 0.145, 0.10 + k * 0.145 + 0.06
        a, b = bez(P0, P1, P2, P3, t0), bez(P0, P1, P2, P3, t1)
        dx, dy = b[0] - a[0], b[1] - a[1]; n = math.hypot(dx, dy); nx, ny = -dy / n, dx / n
        h = 12
        ls.append(layer(poly([(a[0] + nx * h, a[1] + ny * h), (b[0] + nx * h, b[1] + ny * h),
                              (b[0] - nx * h, b[1] - ny * h), (a[0] - nx * h, a[1] - ny * h)]), '#ffe8ee', fa=0.9))
    ls.append(layer(band, stroke='#ffffff', sw=3, sa=0.25))
    tail = Path().M(760, 606).C(757, 628, 753, 650, 748, 672).L(776, 676).C(778, 652, 783, 630, 792, 612).Z()
    ls.append(layer(tail, '#c93b57', '#a02a45', '#6b1328', 2))
    xl = lambda y: 760 - 12 * (y - 606) / 66; xr = lambda y: 792 - 16 * (y - 612) / 64
    for y in (632, 654):
        ls.append(layer(poly([(xl(y), y), (xr(y), y), (xr(y + 11), y + 11), (xl(y + 11), y + 11)]), '#ffe8ee', fa=0.9))
    ls.append(layer(_rot_ell(858, 586, 20, 16, -0.2), '#9f2540', '#7a1830', '#4d0d1e', 2))
    art('acc_scarf', ls)
scarf()

def bowtie():
    tf = dict(tx=806, ty=598, rot=-0.08)
    ls = []
    for s in (-1, 1):
        w = Path(**tf).M(s * 5, 0).L(s * 44, -23).Q(s * 55, 0, s * 44, 23).Z()
        ls.append(layer(w, '#8a4dff', '#4a1db0', '#2a0f66', 2.5))
        ls.append(layer(Path(**tf).M(s * 13, 0).L(s * 40, -12), stroke='#d2bcff', sw=1.8, sa=0.7))
        ls.append(layer(Path(**tf).M(s * 13, 0).L(s * 40, 12), stroke='#d2bcff', sw=1.8, sa=0.7))
    ls.append(layer(ell(0, 0, 10, 13, **tf), '#b08cff', '#7a4de0', '#2a0f66', 2))
    art('acc_bowtie', ls)
bowtie()

def pearls():
    P0, P1, P2 = NECKQ0, NECKQ1, NECKQ2
    q = lambda t: ((1 - t)**2 * P0[0] + 2 * (1 - t) * t * P1[0] + t * t * P2[0],
                   (1 - t)**2 * P0[1] + 2 * (1 - t) * t * P1[1] + t * t * P2[1])
    ls = [layer(Path().M(*P0).Q(*P1, *P2), stroke='#cdbab4', sw=2)]
    for i in range(11):
        x, y = q(i / 10)
        ls.append(layer(ell(x, y, 7.6, 7.6), '#fffaf4', '#eadfd6', '#c9b6ae', 1.4))
        ls.append(layer(ell(x - 2.6, y - 2.6, 2.4, 2.4), '#ffffff'))
    art('acc_pearls', ls)
pearls()

# ---------------------------------------------------------------- NOUVEAUX (3.10)
def heart(cx, cy, s, **tf):
    p = Path(**tf)
    p.M(cx, cy + s * 0.9).C(cx - s * 1.3, cy + s * 0.1, cx - s * 0.8, cy - s * 0.9, cx, cy - s * 0.3)
    p.C(cx + s * 0.8, cy - s * 0.9, cx + s * 1.3, cy + s * 0.1, cx, cy + s * 0.9).Z()
    return p

def catears():
    ls = []
    for pts, inner in [([(702, 342), (690, 238), (780, 296)], [(712, 324), (704, 264), (758, 301)]),
                       ([(888, 332), (900, 232), (812, 288)], [(878, 315), (886, 259), (832, 292)])]:
        ls.append(layer(poly(pts), '#5a3aa6', '#33196e', '#1e0c46', 3))
        ls.append(layer(poly(inner), '#ffb3d9', '#ff7fbf'))
    art('acc_catears', ls)
catears()

def nightcap():
    tf = dict(tx=790, ty=290, rot=-0.06)
    ls = [layer(ell(0, 0, 106, 21, **tf), '#fff4e0', '#e9d8bd', '#a78d63', 2.5)]
    body = Path(**tf).M(-92, -6).C(-80, -70, -20, -100, 30, -90).C(90, -80, 130, -30, 150, 40).C(158, 62, 140, 72, 128, 56)
    body.C(110, 20, 90, -14, 70, -10).L(92, -4).Q(0, 14, -92, -6).Z()
    ls.append(layer(body, '#6e7bff', '#3a40b8', '#20237a', 3))
    for x, y, r in [(-30, -50, 8), (20, -68, 6), (86, -38, 7), (120, 4, 5)]:
        ls.append(layer(star(x, y, r, r * 0.42, **tf), '#fff0a0', None, '#c89a2a', 1.5))
    ls.append(layer(ell(138, 66, 17, 17, **tf), '#ffffff', '#e8e2ff', '#a8a0d0', 2))
    art('acc_nightcap', ls)
nightcap()

def moontiara():
    base = Path().M(698, 332).Q(790, 266, 890, 322)
    cres = Path().M(804, 232).C(768, 228, 752, 286, 806, 296).C(778, 276, 780, 246, 804, 232).Z()
    art('acc_moontiara', [layer(base, stroke='#a8741a', sw=10), layer(base, stroke='#ffe08a', sw=6),
                          layer(cres, '#fff6c0', '#f1b432', '#a8741a', 2.5),
                          layer(sparkle(836, 252, 11), '#ffffff'), layer(sparkle(740, 288, 8), '#fff3b0'),
                          layer(ell(716, 322, 6, 6), '#7be0ff', None, '#2f8ab0', 1.5),
                          layer(ell(866, 306, 6, 6), '#ff8fcf', None, '#b0377e', 1.5)])
moontiara()

def mushroomhat():
    tf = dict(tx=806, ty=322, rot=-0.13, sc=0.86)
    ls = []
    cap = Path(**tf).M(-96, 4).C(-96, -70, -40, -108, 0, -108).C(44, -108, 98, -70, 98, 4).Q(0, 22, -96, 4).Z()
    ls.append(layer(cap, '#ff6f7d', '#c8233f', '#6e0f22', 3))
    for x, y, r in [(-52, -38, 13), (6, -70, 15), (56, -34, 12), (-14, -26, 8), (34, -78, 7)]:
        ls.append(layer(ell(x, y, r, r * 0.8, **tf), '#fff8f0', fa=0.95))
    art('acc_mushroom', ls)
mushroomhat()

def monocle():
    ring = _rot_ell(928, 433, 66, 62, -0.17)
    chain = Path().M(985, 478).Q(1016, 520, 1004, 580)
    ls = [layer(ring, '#bfe4ff', None, None, 0, fa=0.14), layer(ring, None, None, '#e0a93a', 7),
          layer(Path().M(890, 396).Q(915, 380, 940, 380), stroke='#ffffff', sw=4, sa=0.65),
          layer(chain, stroke='#e0a93a', sw=3)]
    for t in range(5):
        x, y = bez((985, 478), (1010, 505), (1012, 540), (1004, 580), t / 4)
        ls.append(layer(ell(x, y, 3.5, 3.5), '#ffe08a', None, '#a8741a', 1))
    art('acc_monocle', ls)
monocle()

def heartglasses():
    L, R = heart(714, 478, 62), heart(928, 435, 57)
    ls = [layer(L, '#ff9ed2', None, None, 0, fa=0.35), layer(R, '#ff9ed2', None, None, 0, fa=0.35),
          layer(L, None, None, '#ff4fa3', 6), layer(R, None, None, '#ff4fa3', 6),
          layer(Path().M(776, 470).Q(826, 436, 874, 436), stroke='#ff4fa3', sw=6),
          layer(Path().M(646, 470).L(618, 458), stroke='#ff4fa3', sw=5),
          layer(Path().M(990, 428).L(1016, 414), stroke='#ff4fa3', sw=5),
          layer(sparkle(690, 452, 8), '#ffffff'), layer(sparkle(908, 412, 7), '#ffffff')]
    art('acc_heartglasses', ls)
heartglasses()

def freckles():
    ls = []
    for x, y in [(690, 528), (706, 520), (704, 540), (722, 532), (722, 550), (906, 482), (922, 474), (920, 496), (938, 488)]:
        ls.append(layer(ell(x, y, 5.2, 4.4), '#c2457a', None, None, 0, fa=0.9))
    art('acc_freckles', ls)
freckles()

def medallion():
    P0, P1, P2 = NECKQ0, NECKQ1, NECKQ2
    chain = Path().M(*P0).Q(*P1, *P2)
    g = ell(805, 632, 17, 17)
    ls = [layer(chain, stroke='#a8741a', sw=5), layer(chain, stroke='#ffe08a', sw=2.5),
          layer(g, '#fff6c0', '#f1b432', '#a8741a', 2.5), layer(ell(805, 632, 8, 8), '#9be0ff', '#4aa0e0', '#2a6a9a', 1.5),
          layer(sparkle(800, 628, 5), '#ffffff')]
    art('acc_medallion', ls)
medallion()

def belltie():
    P0, P1, P2, P3 = NECK0, NECK1, NECK2, NECK3
    band = Path().M(*P0).C(*P1, *P2, *P3)
    ls = [layer(band, stroke='#0f5a52', sw=20), layer(band, stroke='#2fbfa8', sw=14),
          layer(band, stroke='#ffffff', sw=2, sa=0.4),
          layer(ell(806, 628, 15, 15), '#ffe9a0', '#e8a822', '#8a5a10', 2.5),
          layer(Path().M(792, 630).L(820, 630), stroke='#8a5a10', sw=2),
          layer(ell(806, 637, 3, 3), '#8a5a10')]
    art('acc_belltie', ls)
belltie()

def garland():
    P0, P1, P2 = NECKQ0, NECKQ1, NECKQ2
    q = lambda t: ((1 - t)**2 * P0[0] + 2 * (1 - t) * t * P1[0] + t * t * P2[0],
                   (1 - t)**2 * P0[1] + 2 * (1 - t) * t * P1[1] + t * t * P2[1])
    ls = [layer(Path().M(*P0).Q(*P1, *P2), stroke='#3f9a55', sw=4)]
    cols = [('#ffb3d0', '#c4457f'), ('#ffffff', '#c9b6d9'), ('#c9a8ff', '#7f55c9'), ('#ffd68a', '#c8923a')]
    for i in range(8):
        x, y = q(i / 7); pet, edge = cols[i % 4]
        for k in range(5):
            a = k * 2 * math.pi / 5 - math.pi / 2
            ls.append(layer(_rot_ell(x + math.cos(a) * 6, y + math.sin(a) * 6, 5, 3.6, a), pet, None, edge, 1.2))
        ls.append(layer(ell(x, y, 3.2, 3.2), '#fff0a0', None, '#c8923a', 1))
    art('acc_garland', ls)
garland()

def fireflycrown():
    pts = [(668, 352), (700, 322), (745, 300), (790, 292), (838, 297), (885, 312), (925, 338)]
    ls = [layer(Path().M(*pts[0]).Q(700, 300, 790, 288).Q(880, 296, 925, 338), stroke='#3a7a3a', sw=7)]
    for i, (x, y) in enumerate(pts):
        d = -1 if i % 2 else 1
        ls.append(layer(_rot_ell(x + 6 * d, y - 12, 15, 6.5, -0.7 * d), '#7fe08a', '#2f9a4a', '#1f6a34', 1.5))
    for x, y in [(700, 316), (790, 286), (885, 306), (745, 296), (838, 291)]:
        ls.append(layer(ell(x, y, 17, 17), '#e4ff8a', fa=0.20))
        ls.append(layer(ell(x, y, 9, 9), '#f4ffa8', fa=0.40))
        ls.append(layer(ell(x, y, 4.2, 4.2), '#ffffff', None, '#d8e860', 1))
    art('acc_fireflycrown', ls, bob=3)
fireflycrown()

# ---------------------------------------------------------------- NOUVEAUX (3.11)
def beret():
    tf = dict(tx=770, ty=318, rot=-0.16)
    body = Path(**tf).M(-98, 6).C(-110, -52, -50, -86, 8, -84).C(66, -82, 118, -50, 112, 8).Q(6, 24, -98, 6).Z()
    ls = [layer(body, '#d6456a', '#8e1d3f', '#560c24', 3),
          layer(Path(**tf).M(-80, -8).Q(0, -62, 90, -26), stroke='#ffffff', sw=3, sa=0.3),
          layer(Path(**tf).M(6, -84).L(10, -102), stroke='#560c24', sw=5),
          layer(ell(10, -104, 6, 6, **tf), '#8e1d3f', None, '#560c24', 2)]
    art('acc_beret', ls)
beret()

def bunnyears():
    ls = []
    for tf, rot in [(dict(tx=736, ty=318, rot=-0.22), -0.22), (dict(tx=860, ty=306, rot=0.2), 0.2)]:
        ear = Path(**tf).M(-20, 0).C(-30, -70, -22, -140, 0, -150).C(24, -140, 30, -70, 20, 0).Z()
        ls.append(layer(ear, '#fff4fb', '#dcc6f0', '#8a6bb0', 3))
        inner = Path(**tf).M(-9, -6).C(-15, -60, -10, -112, 0, -122).C(10, -112, 15, -60, 9, -6).Z()
        ls.append(layer(inner, '#ffb3d9', '#ff86c0'))
    art('acc_bunnyears', ls, bob=2)
bunnyears()

def leafcrown():
    pts = [(668, 352), (702, 321), (746, 300), (790, 292), (836, 297), (882, 312), (924, 338)]
    ls = [layer(Path().M(668, 352).Q(790, 262, 926, 340), stroke='#5a3b1c', sw=6)]
    for i, (x, y) in enumerate(pts):
        for s in (-1, 1):
            ls.append(layer(_rot_ell(x + s * 9, y - 6 - (i % 2) * 4, 17, 7, -0.6 * s - 0.3), '#7bd88a', '#3f9a55', '#276b3a', 1.6))
    for x, y in [(746, 296), (836, 293), (924, 336)]:
        ls.append(layer(ell(x, y, 6, 6), '#ff8fb2', None, '#b03a60', 1.4))
    art('acc_leafcrown', ls)
leafcrown()

def glitter():
    ls = []
    for x, y, r in [(690, 530, 8), (716, 548, 6), (742, 534, 5), (906, 486, 8), (934, 500, 6), (958, 486, 5), (676, 510, 5), (962, 462, 5)]:
        ls.append(layer(sparkle(x, y, r), '#fff7c2'))
        ls.append(layer(ell(x, y, r * 0.35, r * 0.35), '#ffffff'))
    art('acc_glitter', ls, bob=1)
glitter()

def heartcheeks():
    ls = [layer(heart(704, 540, 15), '#ff6fae', '#e0307f', '#a81f5e', 1.5),
          layer(heart(924, 494, 14), '#ff6fae', '#e0307f', '#a81f5e', 1.5),
          layer(ell(698, 534, 3.2, 3.2), '#ffffff', fa=0.7), layer(ell(918, 488, 3.2, 3.2), '#ffffff', fa=0.7)]
    art('acc_heartcheeks', ls)
heartcheeks()

def whiskers():
    ls = []
    for (x0, y0, d) in [(724, 546, -1), (904, 500, 1)]:
        for k, dy in enumerate((-12, 0, 12)):
            ls.append(layer(Path().M(x0, y0 + dy * 0.4).Q(x0 + d * 30, y0 + dy - 6, x0 + d * 58, y0 + dy * 1.4), stroke='#4a2a7a', sw=3, sa=0.85))
    art('acc_whiskers', ls)
whiskers()

def bandana():
    tf = dict(tx=806, ty=588, rot=-0.08)
    tri = Path(**tf).M(-72, -6).Q(0, 24, 72, -6).L(12, 70).Q(0, 78, -12, 70).Z()
    ls = [layer(tri, '#ff7a45', '#d9461f', '#8a2a0e', 3)]
    for x, y in [(-40, 6), (-12, 24), (16, 20), (40, 4), (0, 48), (-4, 4)]:
        ls.append(layer(ell(x, y, 4, 4, **tf), '#fff3d6', fa=0.9))
    ls.append(layer(Path(**tf).M(-72, -6).Q(0, 24, 72, -6), stroke='#8a2a0e', sw=3))
    art('acc_bandana', ls)
bandana()

def heartnecklace():
    C0, C1, C2, C3 = (745, 575), (775, 612), (840, 616), (874, 556)
    band = Path().M(*C0).C(*C1, *C2, *C3)
    ls = [layer(band, stroke='#1d0f33', sw=24), layer(band, stroke='#3a2158', sw=19),
          layer(band, stroke='#ffffff', sw=2, sa=0.18)]
    for t in (0.06, 0.18, 0.30, 0.42, 0.62, 0.74, 0.86):
        x, y = bez(C0, C1, C2, C3, t)
        ls.append(layer(ell(x, y, 5.2, 4.2), '#ff9fd8', '#e05ab0', '#8a2a70', 1))
    gx, gy = 803, 603
    ls.append(layer(ell(gx, gy + 3, 8, 11), '#d9a6ff', '#9b4ae0', '#5a1fa0', 1.8))
    ls.append(layer(Path().M(gx, gy + 14).L(gx, gy + 24), stroke='#7a6a9a', sw=3))
    H = heart(gx, 648, 24)
    ls.append(layer(H, '#f08cff', '#9a36d8', '#5a1a9a', 2.5))
    ls.append(layer(heart(gx - 3, 643, 13), '#ffd6ff', fa=0.75))
    ls.append(layer(sparkle(gx - 8, 637, 8), '#ffffff'))
    art('acc_heartnecklace', ls)
heartnecklace()

def starcollar():
    P0, P1, P2 = NECKQ0, NECKQ1, NECKQ2
    chain = Path().M(*P0).Q(*P1, *P2)
    ls = [layer(chain, stroke='#2b1a6e', sw=9), layer(chain, stroke='#7a5cff', sw=5),
          layer(star(804, 626, 24, 10, rot=-math.pi / 2), '#fff0a0', '#f1b432', '#a8741a', 2.5),
          layer(sparkle(812, 616, 6), '#ffffff')]
    art('acc_starcollar', ls)
starcollar()

def ruffle():
    ls = []
    P0, P1, P2 = NECKQ0, NECKQ1, NECKQ2
    q = lambda t: ((1 - t)**2 * P0[0] + 2 * (1 - t) * t * P1[0] + t * t * P2[0],
                   (1 - t)**2 * P0[1] + 2 * (1 - t) * t * P1[1] + t * t * P2[1])
    ls.append(layer(Path().M(*P0).Q(*P1, *P2), stroke='#e9d8ff', sw=16))
    for i in range(11):
        x, y = q(i / 10)
        ls.append(layer(ell(x, y + 6, 11, 13), '#ffffff', '#efe3ff', '#b79ddb', 1.6))
    art('acc_ruffle', ls)
ruffle()

# ---------------------------------------------------------------- sortie
json.dump(ART, open(sys.argv[1] + '/acc.json', 'w'))
def lit(v):
    return f"0x{v & 0xFFFFFFFF:08X}" + ("L" if v >= 0x80000000 else "")
lines = ["package com.lumina.nyxie", "", "// Fichier généré par tools/make_acc.py : ne pas modifier à la main.", "",
         "class ArtLayer(", "    val d: String, val fill: Long = 0L, val fill2: Long = 0L,",
         "    val gy0: Float = 0f, val gy1: Float = 0f, val stroke: Long = 0L, val sw: Float = 0f,", ")", "",
         "class AccArt(val layers: List<ArtLayer>, val bob: Float = 0f)", "", "object AccArtData {",
         "    val art: Map<String, AccArt> = mapOf("]
for id_, a in ART.items():
    lines.append(f'        "{id_}" to AccArt(listOf(')
    for L in a['layers']:
        parts = [f'"{L["d"]}"']
        if L['fill']: parts.append(f"fill = {lit(L['fill'])}")
        if L['fill2']: parts.append(f"fill2 = {lit(L['fill2'])}")
        if L['fill2'] or L['fill']: parts.append(f"gy0 = {L['gy0']}f, gy1 = {L['gy1']}f")
        if L['stroke']: parts.append(f"stroke = {lit(L['stroke'])}, sw = {L['sw']}f")
        lines.append("            ArtLayer(" + ", ".join(parts) + "),")
    lines.append(f"        ), bob = {a['bob']}f),")
lines += ["    )", "}", ""]
open(sys.argv[1] + '/AccArt.kt', 'w').write("\n".join(lines))
print(len(ART), "accessoires,", sum(len(a['layers']) for a in ART.values()), "couches")
