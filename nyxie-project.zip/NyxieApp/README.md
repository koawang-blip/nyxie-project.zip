# Nyxie, compagnon virtuel (version 2)

Application Android en Jetpack Compose. Tout fonctionne sur le téléphone : aucune IA distante, aucun compte.

## Ce qui est réellement fonctionnel

- **Jauges** (faim, énergie, affection, humeur) qui évoluent avec le temps, même application fermée.
- **Nourrir** (choix de la nourriture dans le sac), **Caresser**, **Jouer**, **Parler**, **Activité** (4 activités chronométrées), **Cadeau** (un toutes les 8 h).
- **Visage animé en direct** : paupières qui se ferment et clignent, yeux rieurs, bouche qui s'ouvre, mâche, parle, sourit, boude, bâille, rougit, pleure quand elle est triste, dort avec des « Zzz ».
- **Particules** : cœurs, miettes, étincelles, larmes.
- **Discussion** locale avec réponses selon l'humeur et ce que tu écris, plus saisie vocale (micro).
- **Soins** : repas, bain de lune, brossage, dormir / réveiller.
- **Jeux** : Étoiles filantes et Mémoire lunaire, avec records, pièces et expérience.
- **Personnalisation** : accessoires (fleur, nœud, couronne) et thèmes de couleur, à acheter puis équiper.
- **Galerie** de 6 souvenirs à débloquer, **Inventaire et boutique**, **Évolution** par niveau, **Paramètres** (nom, sons, animations, réinitialisation).
- **Sauvegarde automatique.**

## Compiler

### Avec Android Studio
Ouvrir le dossier `NyxieApp`, attendre la synchronisation, puis Build > Build APK(s).
L'APK est dans `app/build/outputs/apk/debug/app-debug.apk`.

### Sans ordinateur, avec GitHub (depuis le téléphone)
1. Créer un dépôt GitHub vide.
2. Add file > Upload files : envoyer `nyxie-project.zip` (sans le dézipper) et valider.
3. Add file > Create new file : nommer `.github/workflows/build.yml` et coller le contenu du fichier `build.yml` fourni.
4. Onglet Actions > « Compiler Nyxie » > Run workflow.
5. Quand c'est vert, ouvrir l'exécution et télécharger l'artefact `Nyxie-APK`.

## Installer
Copier `app-debug.apk` sur le téléphone, l'ouvrir et autoriser l'installation.
Si l'ancienne version de Nyxie est installée avec une autre signature, la désinstaller d'abord.

## Rythme du jeu
Éveillée : faim -15 %/h, énergie -10 %/h, affection -9 %/h. Endormie : énergie +50 %/h.
Le niveau suivant demande 50 × niveau points d'expérience.

## Mise à jour 2.1
- Yeux fermés corrigés : les rustines de peau recouvrent maintenant tout l'œil d'origine (plus de cils fantômes),
  la ligne de paupière est effilée avec cils recourbés et ombre douce, et le clignement suit la vraie forme de l'œil.
- Clé de signature fixe (`app/debug.keystore`) : à partir de cette version, une nouvelle compilation
  s'installe par-dessus l'ancienne **sans perdre la progression**.
  Cette version-ci est signée avec une nouvelle clé : désinstaller l'ancienne Nyxie une seule fois avant de l'installer.

## Mise à jour 2.2 — boutique agrandie

- Nouveaux aliments, boissons, jouets (peluche, cerf-volant, boîte à musique…).
- Accessoires par emplacement : tête, visage, cou, et auras animées (étoiles, cœurs, bulles). On peut en porter un par emplacement.
- Ambiances animées (aurore, lucioles, pétales, neige, étoiles filantes…) et thèmes de couleur supplémentaires.
- Boutique à onglets (Inventaire > Boutique, et Personnalisation).
- Dessins des accessoires générés par `tools/make_acc.py` (sortie : `AccArt.kt`).

## Mise à jour 2.3

- Niveau maximum porté à 50 (XP par niveau plafonnée à 600), nouveaux rangs : Reine des étoiles (30), Dragon cosmique (40), Légende de la nuit (50).

## Mise à jour 2.4

- Cache de peau de la bouche agrandi : plus de traits sombres aux coins de la bouche d'origine.

## Mise à jour 2.5 — bruitages

- Sons de Nyxie (ronronnement, miaulement, croquement, rire, éclaboussures, bâillement, étincelles, pièces…) dans `res/raw/snd_*.wav`, joués selon les actions.
- Générés par `tools/make_sounds.py` (synthèse), remplaçables par de vrais enregistrements en gardant les mêmes noms de fichiers.
- Réglage : Paramètres > Sons de l'application.

## Mise à jour 2.6 — notifications

- Rappels doux de Nyxie (faim, ennui, fatigue) programmés quand on quitte l'appli, jamais entre 22 h et 8 h, 3 maximum sans retour.
- Réglage : Paramètres > Notifications de Nyxie. Permission demandée une fois (Android 13+).

## Mise à jour 2.7 — retour après absence

- Selon la durée d'absence (30 min, 3 h, 12 h) Nyxie réagit, boude un instant après 12 h, puis offre un cadeau de retrouvailles.

## Mise à jour 2.8 — quêtes quotidiennes

- Onglet « Quêtes » : 3 quêtes par jour, récompenses en pièces, série de jours consécutifs et coffre du jour.

## Mise à jour 2.9 — mode photo

- Onglet « Mode photo » : interface masquée, Nyxie en plein écran, 5 cadres, déclencheur avec bruit d'obturateur, enregistrement dans Images/Nyxie et bouton Partager.

## Mise à jour 3.0 — tics et humeurs

- Petits tics aléatoires selon l'humeur : curiosité, rire, clignement lent, bâillement, regard autour, secousse, fierté, bouderie.
- Légère inclinaison de la tête, et vers le doigt quand on touche Nyxie.

## Mise à jour 3.1 — widget

- Widget « Nyxie » pour l'écran d'accueil : visage, niveau, humeur et jauges faim / énergie / affection. Un tap ouvre l'application. Mis à jour à la fermeture de l'appli et toutes les 30 min.

## Mise à jour 3.2 — icône et musique

- Vraie icône d'application (adaptative) à l'effigie de Nyxie.
- Musique d'ambiance (berceuse en boucle, générée par `tools/make_music.py`), réglable dans Paramètres, mise en pause quand on quitte l'appli.

## Mise à jour 3.3

- La bulle de dialogue est déplacée au-dessus des boutons (à gauche) et rendue plus compacte pour ne plus cacher le visage.

## Mise à jour 3.4

- Bulle de dialogue remise en haut, plus petite et semi-transparente.

## Mise à jour 3.5

- Retrait des boutons de test (pièces / tout débloquer) des Paramètres.

## Mise à jour 3.6 — introduction

- Cinématique de premier lancement (`res/raw/nyxie_intro.mp4`, 10 s, 1280x720) : lecture automatique uniquement au tout premier démarrage, bouton « Passer », retour Android = passer, état « déjà vue » conservé à part de la sauvegarde.
- Paramètres > « Revoir l'introduction » : relance la vidéo sans toucher aux données.
- Si la vidéo est absente ou illisible, l'appli s'ouvre normalement.

## 3.7 – Nouvelles phrases (étape C)
- Nouveau fichier `Lines.kt` : ~230 phrases préprogrammées (faim, fatigue, affection, bonne humeur, calme, rêveries, matin/soir/nuit, espiègle, caresses, repas, bain, brossage, jeux, retrouvailles, réveil, coucher, accessoires, niveau, quêtes…).
- Anti-répétition : une phrase n'est pas redite tant que d'autres de la même catégorie n'ont pas été dites.
- Certaines phrases déclenchent une animation existante (bâillement, clignement lent, boudeuse, rire, fierté, regard curieux).
- Résultats des mini-jeux selon le score (réussite / moyen / faible).

## 3.8 – Pluie d'étoiles progressive (étape D)
- Le nombre maximum d'étoiles à l'écran passe progressivement de 6 à 14 pendant les 20 s, et l'apparition s'accélère jusqu'à -50 %.
- Seuils de phrases de fin ajustés (35 / 15 étoiles).

## 3.9 – Catalogue enrichi et fiche d'objet (étape E)
- `Item` : rareté (Commun/Rare/Épique/Légendaire, déduite du prix ou fixée), monnaie (pièces, gemmes, jetons d'événement, argent réel – réservé), disponibilité (toujours / événement / limitée), `eventId`, catégorie lisible. Les identifiants existants sont inchangés (sauvegardes compatibles).
- Boutique : touche un objet pour ouvrir sa fiche (aperçu porté par Nyxie pour accessoires, thèmes et ambiances, effets, prix et monnaie expliquée, ce que tu as). Acheter un objet de style passe par l'aperçu.

## 3.10 – Correctif démarrage + boutique élargie
- Correctif : plantage au lancement (le sélecteur de phrases était initialisé après le bloc de démarrage qui l'utilisait pour l'accueil de retour).
- Boutique : 102 objets (+52) : 14 nourritures, 7 boissons, 9 jouets, 4+3+3 accessoires (tête/visage/cou) dessinés, 4 ambiances, 8 thèmes de couleur. Audit : chaque objet a son dessin / son rendu / sa couleur, aucun identifiant en double.

## 3.11 – Premier événement : Nuit des lucioles (étape F) + accessoires
- Événement local (horloge de l'appareil, aucun réseau) du 20 au 26 nov. 2026 (une semaine) : lucioles gagnées (+3 à la première visite du jour, +1 par soin/partie, max 12/jour), carte dans « Quêtes », 5 paliers de récompenses (pièces, ambiance, couronne de lucioles, gemmes, thème Lueur), décor de lucioles à l'écran, phrases d'événement.
- Hors-ligne : tout fonctionne sans connexion. Après la fin : les récompenses atteintes mais non réclamées sont rangées automatiquement ; les objets obtenus restent à Nyxie ; la progression est remise à zéro. Ajouter un événement = une entrée dans Events.kt.
- Nouveaux accessoires : béret, oreilles de lapin, couronne de feuilles, paillettes, joues en cœur, moustaches, bandana, collier étoile, collerette + auras Pétales en tourbillon et Éclats dorés.

## 3.12 – Nuit des lucioles décalée + 2 nouveaux mini-jeux (étape G)
- L'événement dure maintenant du 20 au 26 novembre 2026 (modifiable dans `Events.kt`).
- Attrape-lucioles : 25 s, on ne peut attraper les lucioles que lorsqu'elles brillent ; les dorées valent 4 points ; de plus en plus de lucioles.
- Bulles magiques : 25 s, enchaîner la même couleur fait monter le combo (jusqu'à x5).
- Records enregistrés (sauvegardes compatibles), phrases de fin selon le score, quêtes « jouer » et lucioles d'événement comptabilisées.

## 3.13 – Sauvegarde et restauration
- Paramètres > Sauvegarder : écrit un fichier .json (via le sélecteur de fichiers du système, sans permission ni réseau). Restaurer : choisit un fichier, vérifie qu'il s'agit d'une sauvegarde Nyxie, remplace la progression.

## 3.14 – Guide de découverte, voix, Cache-cache
- Guide de découverte en 3 pages (premier lancement uniquement, puis Paramètres > Revoir le guide). Aucun mode « grands boutons » : l'application reste la même pour tous.
- Option « Nyxie parle à voix haute » (synthèse vocale du téléphone, désactivée par défaut).
- 5e mini-jeu : Cache-cache (8 manches, les champignons se mélangent de plus en plus vite). Tous les jeux sont dans l'écran « Jeux ».

## 3.15 – Correctifs
- Écran « Jeux » : défilement vertical (les nouveaux jeux étaient sous la ligne visible et inaccessibles sur un écran en paysage).
- Monnaies : uniquement pièces et gemmes. Les prix s'écrivent « 120 pièces » / « 5 gemmes » (plus d'emoji 💎/🪙 dans la boutique).

## 3.16 – Journal, succès, anniversaire, minuteur de sommeil
- Évolution : journal (jours ensemble, anniversaire, compteurs de repas / caresses / soins / jeux / discussions / siestes) et 21 succès (+15 pièces chacun, une seule fois).
- Anniversaire de Nyxie : date de rencontre enregistrée (les parties existantes commencent à aujourd'hui) ; chaque année, cadeau de 60 pièces et 2 gemmes.
- Paramètres > Minuteur de sommeil (15 / 30 / 60 min) : berceuse, fondu, Nyxie s'endort ; l'écran reste allumé pendant le minuteur.
